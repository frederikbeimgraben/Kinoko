import * as i0 from '@angular/core';
import { signal, InjectionToken, makeEnvironmentProviders, inject, Pipe, Input, HostBinding, ChangeDetectionStrategy, Component, viewChild, computed, effect, input, EventEmitter, HostListener, ViewChild, Output, TemplateRef, Directive, ContentChild, ContentChildren, ElementRef, output, Injectable } from '@angular/core';
import * as i1 from '@angular/forms';
import { NG_VALUE_ACCESSOR, FormsModule } from '@angular/forms';
import { NgTemplateOutlet } from '@angular/common';

/** Built-in DE/EN strings — the kit renders identically out of the box. */
const UI_KIT_DEFAULT_MESSAGES = {
    de: {
        'dialog.close': 'Schließen',
        loading: 'Wird geladen…',
        'datepicker.openCalendar': 'Kalender öffnen',
        'filter.button': 'Filter',
        'filter.apply': 'Anwenden',
        'filter.reset': 'Zurücksetzen',
        'diff.none': 'Keine Feldänderungen.',
        'diff.changed': 'Geändert',
        'diff.added': 'Hinzugefügt',
        'diff.removed': 'Entfernt',
    },
    en: {
        'dialog.close': 'Close',
        loading: 'Loading…',
        'datepicker.openCalendar': 'Open calendar',
        'filter.button': 'Filter',
        'filter.apply': 'Apply',
        'filter.reset': 'Reset',
        'diff.none': 'No field changes.',
        'diff.changed': 'Changed',
        'diff.added': 'Added',
        'diff.removed': 'Removed',
    },
};
const DEFAULT_LANG = 'de';
function detectLang() {
    if (typeof navigator === 'undefined')
        return DEFAULT_LANG;
    return navigator.language.slice(0, 2).toLowerCase() === 'en' ? 'en' : 'de';
}
function interpolate(text, params) {
    if (!params)
        return text;
    return text.replace(/\{(\w+)\}/g, (match, name) => name in params ? String(params[name]) : match);
}
/**
 * Default {@link UiKitIntl}: ships the built-in DE/EN catalogue. Language follows an
 * injected signal when given (so it tracks the host app's locale), otherwise an
 * internal signal seeded from the browser and settable via {@link setLang}.
 */
class DefaultUiKitIntl {
    constructor(options = {}) {
        this.internalLang = signal(detectLang(), ...(ngDevMode ? [{ debugName: "internalLang" }] : []));
        this.lang = options.lang ?? this.internalLang.asReadonly();
        this.messages = {
            de: { ...UI_KIT_DEFAULT_MESSAGES.de, ...(options.messages?.de ?? {}) },
            en: { ...UI_KIT_DEFAULT_MESSAGES.en, ...(options.messages?.en ?? {}) },
        };
    }
    /** Set the language. Only effective when no external `lang` signal was provided. */
    setLang(lang) {
        this.internalLang.set(lang);
    }
    translate(key, params) {
        const raw = this.messages[this.lang()][key] ?? this.messages[DEFAULT_LANG][key] ?? key;
        return interpolate(raw, params);
    }
}
/** DI token for the kit's i18n. Defaults to a built-in DE/EN {@link DefaultUiKitIntl}. */
const UI_KIT_INTL = new InjectionToken('UI_KIT_INTL', {
    providedIn: 'root',
    factory: () => new DefaultUiKitIntl(),
});
/** Build a {@link UiKitIntl} whose language tracks the given signal (e.g. an app locale). */
function uiKitIntlFromLang(lang, messages) {
    return new DefaultUiKitIntl({ lang, messages });
}
/**
 * Register the kit's i18n. Pass a ready {@link UiKitIntl} via `intl`, or `lang`/`messages`
 * to configure the default implementation. With no argument the built-in catalogue is used.
 */
function provideUiKit(options = {}) {
    return makeEnvironmentProviders([
        {
            provide: UI_KIT_INTL,
            useFactory: () => options.intl ?? new DefaultUiKitIntl(options),
        },
    ]);
}

/**
 * `{{ 'dialog.close' | uiKitT }}` — impure so a language switch propagates immediately
 * (the active language is a signal on the {@link UiKitIntl}).
 */
class UiKitTranslatePipe {
    constructor() {
        this.intl = inject(UI_KIT_INTL);
    }
    transform(key, params) {
        return this.intl.translate(key, params);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: UiKitTranslatePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "20.3.25", ngImport: i0, type: UiKitTranslatePipe, isStandalone: true, name: "uiKitT", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: UiKitTranslatePipe, decorators: [{
            type: Pipe,
            args: [{ name: 'uiKitT', standalone: true, pure: false }]
        }] });

const NEVER_VISIBLE = { visible: signal(false).asReadonly() };
/**
 * DI token feeding the loading overlay. Defaults to never-visible (no-op); the host app
 * provides one delegating to its own loading service, e.g.
 * `{ provide: UI_KIT_LOADING, useFactory: () => ({ visible: inject(LoadingService).visible }) }`.
 */
const UI_KIT_LOADING = new InjectionToken('UI_KIT_LOADING', {
    providedIn: 'root',
    factory: () => NEVER_VISIBLE,
});

/** Basis-Button des UI-Kits. Clean/minimal, CD-Tokens, a11y-Fokus. */
class ButtonComponent {
    constructor() {
        this.variant = 'primary';
        /** Frei wählbare Hintergrundfarbe (Hex); überschreibt die Variante (#flow). */
        this.color = null;
        this.size = 'md';
        this.type = 'button';
        this.disabled = false;
        this.loading = false;
        /** Quadratischer Icon-Button (gleiche Höhe/Breite) für einzelne Glyphs (✕ ↑ ↓). */
        this.iconOnly = false;
        /** Volle Breite des Containers (gestapelte Aktionen gleicher Breite). */
        this.block = false;
        /** Barrierefreier Name — Pflicht für Icon-Buttons ohne sichtbaren Text. */
        this.ariaLabel = '';
        /** Hover-Tooltip; bei Icon-Buttons fällt er automatisch auf `ariaLabel` zurück (#47). */
        this.title = '';
    }
    /** Tooltip-Text: explizit gesetzt, sonst für Icon-Buttons der `ariaLabel`. */
    tooltip() {
        return this.title || (this.iconOnly ? this.ariaLabel : '') || null;
    }
    /** Lesbare Textfarbe (schwarz/weiß) zur gewählten `color` per WCAG-Luminanz. */
    contrastColor() {
        const hex = (this.color ?? '').trim().replace('#', '');
        const full = hex.length === 3
            ? hex
                .split('')
                .map((c) => c + c)
                .join('')
            : hex;
        if (full.length !== 6)
            return '#ffffff';
        const channel = (i) => {
            const v = parseInt(full.slice(i, i + 2), 16) / 255;
            return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
        };
        const lum = 0.2126 * channel(0) + 0.7152 * channel(2) + 0.0722 * channel(4);
        return lum > 0.4 ? '#111111' : '#ffffff';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: ButtonComponent, isStandalone: true, selector: "app-button", inputs: { variant: "variant", color: "color", size: "size", type: "type", disabled: "disabled", loading: "loading", iconOnly: "iconOnly", block: "block", ariaLabel: "ariaLabel", title: "title" }, host: { properties: { "class.btn-block": "this.block" } }, ngImport: i0, template: "<button\n  [type]=\"type\"\n  [disabled]=\"disabled || loading\"\n  [attr.aria-busy]=\"loading ? 'true' : null\"\n  [attr.aria-label]=\"ariaLabel || null\"\n  [attr.title]=\"tooltip()\"\n  [class]=\"'btn btn--' + variant + ' btn--' + size + (iconOnly ? ' btn--icon' : '')\"\n  [class.btn--custom]=\"!!color\"\n  [style.background]=\"color || null\"\n  [style.color]=\"color ? contrastColor() : null\"\n>\n  @if (loading) {\n    <span class=\"btn__spinner\" aria-hidden=\"true\"></span>\n  }\n  <span class=\"btn__label\"><ng-content /></span>\n</button>\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}:host(.btn-block){display:flex}:host(.btn-block) .btn{width:100%}.btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);font-weight:var(--fw-semibold);line-height:1;border:var(--border-width) solid transparent;border-radius:var(--radius-md);cursor:pointer;white-space:nowrap;max-width:100%;min-width:0;transition:background-color var(--motion-fast) var(--ease-standard),color var(--motion-fast) var(--ease-standard),border-color var(--motion-fast) var(--ease-standard)}.btn:disabled{opacity:.55;cursor:not-allowed}.btn--sm{padding:var(--space-2) var(--space-3);font-size:var(--fs-sm)}.btn--md{padding:var(--space-3) var(--space-5);font-size:var(--fs-md)}.btn--lg{padding:var(--space-4) var(--space-6);font-size:var(--fs-lg)}.btn--icon{aspect-ratio:1;padding:var(--space-2);line-height:1}.btn--icon.btn--sm{padding:var(--space-1) var(--space-2)}.btn--primary{background:var(--color-primary);color:var(--color-on-primary)}.btn--primary:hover:not(:disabled){background:var(--color-primary-hover)}.btn--primary:active:not(:disabled){background:var(--color-primary-active)}.btn--secondary{background:var(--color-surface);color:var(--color-text);border-color:var(--color-border-strong)}.btn--secondary:hover:not(:disabled){background:var(--color-surface-sunken);border-color:var(--color-text-muted)}.btn--secondary:active:not(:disabled){background:var(--color-border)}.btn--ghost{background:transparent;color:var(--color-primary)}.btn--ghost:hover:not(:disabled){background:var(--color-primary-subtle)}.btn--ghost:active:not(:disabled){background:var(--color-primary-subtle);color:var(--color-primary-active)}.btn--danger{background:var(--color-surface);color:var(--color-danger);border-color:var(--color-danger)}.btn--danger:hover:not(:disabled){background:var(--color-danger-subtle)}.btn--danger:active:not(:disabled){background:var(--color-danger-subtle);filter:brightness(.94)}.btn--success{background:var(--color-success);color:var(--color-text-inverse)}.btn--success:hover:not(:disabled){filter:brightness(1.08)}.btn--success:active:not(:disabled){filter:brightness(.94)}.btn--custom:hover:not(:disabled){filter:brightness(1.08)}.btn--custom:active:not(:disabled){filter:brightness(.94)}.btn__label{overflow:hidden;text-overflow:ellipsis;min-width:0;max-width:100%;line-height:1.3}.btn__spinner{width:1em;height:1em;border:2px solid currentColor;border-right-color:transparent;border-radius:var(--radius-pill);animation:btn-spin .6s linear infinite}@keyframes btn-spin{to{transform:rotate(360deg)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-button', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<button\n  [type]=\"type\"\n  [disabled]=\"disabled || loading\"\n  [attr.aria-busy]=\"loading ? 'true' : null\"\n  [attr.aria-label]=\"ariaLabel || null\"\n  [attr.title]=\"tooltip()\"\n  [class]=\"'btn btn--' + variant + ' btn--' + size + (iconOnly ? ' btn--icon' : '')\"\n  [class.btn--custom]=\"!!color\"\n  [style.background]=\"color || null\"\n  [style.color]=\"color ? contrastColor() : null\"\n>\n  @if (loading) {\n    <span class=\"btn__spinner\" aria-hidden=\"true\"></span>\n  }\n  <span class=\"btn__label\"><ng-content /></span>\n</button>\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}:host(.btn-block){display:flex}:host(.btn-block) .btn{width:100%}.btn{display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);font-weight:var(--fw-semibold);line-height:1;border:var(--border-width) solid transparent;border-radius:var(--radius-md);cursor:pointer;white-space:nowrap;max-width:100%;min-width:0;transition:background-color var(--motion-fast) var(--ease-standard),color var(--motion-fast) var(--ease-standard),border-color var(--motion-fast) var(--ease-standard)}.btn:disabled{opacity:.55;cursor:not-allowed}.btn--sm{padding:var(--space-2) var(--space-3);font-size:var(--fs-sm)}.btn--md{padding:var(--space-3) var(--space-5);font-size:var(--fs-md)}.btn--lg{padding:var(--space-4) var(--space-6);font-size:var(--fs-lg)}.btn--icon{aspect-ratio:1;padding:var(--space-2);line-height:1}.btn--icon.btn--sm{padding:var(--space-1) var(--space-2)}.btn--primary{background:var(--color-primary);color:var(--color-on-primary)}.btn--primary:hover:not(:disabled){background:var(--color-primary-hover)}.btn--primary:active:not(:disabled){background:var(--color-primary-active)}.btn--secondary{background:var(--color-surface);color:var(--color-text);border-color:var(--color-border-strong)}.btn--secondary:hover:not(:disabled){background:var(--color-surface-sunken);border-color:var(--color-text-muted)}.btn--secondary:active:not(:disabled){background:var(--color-border)}.btn--ghost{background:transparent;color:var(--color-primary)}.btn--ghost:hover:not(:disabled){background:var(--color-primary-subtle)}.btn--ghost:active:not(:disabled){background:var(--color-primary-subtle);color:var(--color-primary-active)}.btn--danger{background:var(--color-surface);color:var(--color-danger);border-color:var(--color-danger)}.btn--danger:hover:not(:disabled){background:var(--color-danger-subtle)}.btn--danger:active:not(:disabled){background:var(--color-danger-subtle);filter:brightness(.94)}.btn--success{background:var(--color-success);color:var(--color-text-inverse)}.btn--success:hover:not(:disabled){filter:brightness(1.08)}.btn--success:active:not(:disabled){filter:brightness(.94)}.btn--custom:hover:not(:disabled){filter:brightness(1.08)}.btn--custom:active:not(:disabled){filter:brightness(.94)}.btn__label{overflow:hidden;text-overflow:ellipsis;min-width:0;max-width:100%;line-height:1.3}.btn__spinner{width:1em;height:1em;border:2px solid currentColor;border-right-color:transparent;border-radius:var(--radius-pill);animation:btn-spin .6s linear infinite}@keyframes btn-spin{to{transform:rotate(360deg)}}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], type: [{
                type: Input
            }], disabled: [{
                type: Input
            }], loading: [{
                type: Input
            }], iconOnly: [{
                type: Input
            }], block: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.btn-block']
            }], ariaLabel: [{
                type: Input
            }], title: [{
                type: Input
            }] } });

let nextId$7 = 0;
/** Textfeld mit Label/Hinweis/Fehler. ControlValueAccessor → Reactive Forms. */
class InputComponent {
    constructor() {
        this.label = '';
        this.type = 'text';
        this.placeholder = '';
        this.hint = '';
        this.error = '';
        this.required = false;
        this.id = `app-input-${nextId$7++}`;
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    get describedBy() {
        if (this.error)
            return `${this.id}-error`;
        if (this.hint)
            return `${this.id}-hint`;
        return null;
    }
    onInput(event) {
        const v = event.target.value;
        this.value.set(v);
        this.onChange(v);
    }
    writeValue(value) {
        this.value.set(value ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: InputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: InputComponent, isStandalone: true, selector: "app-input", inputs: { label: "label", type: "type", placeholder: "placeholder", hint: "hint", error: "error", required: "required", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: InputComponent, multi: true }], ngImport: i0, template: "<div class=\"flex flex-col gap-2\">\n  <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n    {{ label }}\n    @if (required) {\n      <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n    }\n  </label>\n  <input\n    class=\"field__control\"\n    [id]=\"id\"\n    [type]=\"type\"\n    [value]=\"value()\"\n    [disabled]=\"disabled()\"\n    [attr.placeholder]=\"placeholder || null\"\n    [attr.aria-invalid]=\"error ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy\"\n    [attr.required]=\"required ? '' : null\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onTouched()\"\n  />\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: [".field__control{height:var(--control-height);box-sizing:border-box;padding:0 var(--space-4);font-size:var(--fs-md);line-height:var(--lh-normal);color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.field__control:hover:not(:disabled){border-color:var(--color-text-muted)}.field__control:disabled{opacity:.6;cursor:not-allowed}.field__control[aria-invalid=true]{border-color:var(--color-danger)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: InputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: InputComponent, multi: true }], template: "<div class=\"flex flex-col gap-2\">\n  <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n    {{ label }}\n    @if (required) {\n      <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n    }\n  </label>\n  <input\n    class=\"field__control\"\n    [id]=\"id\"\n    [type]=\"type\"\n    [value]=\"value()\"\n    [disabled]=\"disabled()\"\n    [attr.placeholder]=\"placeholder || null\"\n    [attr.aria-invalid]=\"error ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy\"\n    [attr.required]=\"required ? '' : null\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onTouched()\"\n  />\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: [".field__control{height:var(--control-height);box-sizing:border-box;padding:0 var(--space-4);font-size:var(--fs-md);line-height:var(--lh-normal);color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.field__control:hover:not(:disabled){border-color:var(--color-text-muted)}.field__control:disabled{opacity:.6;cursor:not-allowed}.field__control[aria-invalid=true]{border-color:var(--color-danger)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], type: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], hint: [{
                type: Input
            }], error: [{
                type: Input
            }], required: [{
                type: Input
            }], id: [{
                type: Input
            }] } });

let nextId$6 = 0;
/**
 * Checkbox des UI-Kits. Boolescher Wert über `ControlValueAccessor`
 * (Reactive Forms + `ngModel`). Token-basiert (`accent-color` = CD-Primär),
 * sichtbarer Fokus-Ring (global `:focus-visible`), Label/`for`-Bindung für a11y.
 * Label-Text wird projiziert: `<app-checkbox [(ngModel)]="x">Text</app-checkbox>`.
 */
class CheckboxComponent {
    constructor() {
        this.id = `app-checkbox-${nextId$6++}`;
        this.hint = '';
        this.checked = signal(false, ...(ngDevMode ? [{ debugName: "checked" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    onToggle(event) {
        const v = event.target.checked;
        this.checked.set(v);
        this.onChange(v);
    }
    writeValue(value) {
        this.checked.set(!!value);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: CheckboxComponent, isStandalone: true, selector: "app-checkbox", inputs: { id: "id", hint: "hint" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: CheckboxComponent, multi: true }], ngImport: i0, template: "<label class=\"inline-flex items-center gap-2 cursor-pointer text-sm text-text\" [class.cbx--disabled]=\"disabled()\" [for]=\"id\">\n  <input\n    class=\"cbx__input\"\n    type=\"checkbox\"\n    [id]=\"id\"\n    [checked]=\"checked()\"\n    [disabled]=\"disabled()\"\n    [attr.aria-describedby]=\"hint ? id + '-hint' : null\"\n    (change)=\"onToggle($event)\"\n    (blur)=\"onTouched()\"\n  />\n  <span class=\"cbx__label\"><ng-content /></span>\n</label>\n@if (hint) {\n  <p class=\"cbx__hint\" [id]=\"id + '-hint'\">{{ hint }}</p>\n}\n", styles: [":host{display:inline-flex;flex-direction:column;gap:var(--space-1)}.cbx--disabled{cursor:not-allowed;opacity:.6}.cbx__input{flex:none;width:1.1rem;height:1.1rem;margin:0;accent-color:var(--color-primary);cursor:inherit}.cbx__label{line-height:var(--lh-normal)}.cbx__hint{font-size:var(--fs-xs);color:var(--color-text-muted);padding-left:calc(1.1rem + var(--space-2))}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-checkbox', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: CheckboxComponent, multi: true }], template: "<label class=\"inline-flex items-center gap-2 cursor-pointer text-sm text-text\" [class.cbx--disabled]=\"disabled()\" [for]=\"id\">\n  <input\n    class=\"cbx__input\"\n    type=\"checkbox\"\n    [id]=\"id\"\n    [checked]=\"checked()\"\n    [disabled]=\"disabled()\"\n    [attr.aria-describedby]=\"hint ? id + '-hint' : null\"\n    (change)=\"onToggle($event)\"\n    (blur)=\"onTouched()\"\n  />\n  <span class=\"cbx__label\"><ng-content /></span>\n</label>\n@if (hint) {\n  <p class=\"cbx__hint\" [id]=\"id + '-hint'\">{{ hint }}</p>\n}\n", styles: [":host{display:inline-flex;flex-direction:column;gap:var(--space-1)}.cbx--disabled{cursor:not-allowed;opacity:.6}.cbx__input{flex:none;width:1.1rem;height:1.1rem;margin:0;accent-color:var(--color-primary);cursor:inherit}.cbx__label{line-height:var(--lh-normal)}.cbx__hint{font-size:var(--fs-xs);color:var(--color-text-muted);padding-left:calc(1.1rem + var(--space-2))}\n"] }]
        }], propDecorators: { id: [{
                type: Input
            }], hint: [{
                type: Input
            }] } });

let nextId$5 = 0;
/**
 * Dropdown des UI-Kits (#77). Ersetzt Freitext-Felder mit eingeschränkten
 * Optionen (Gremium, Budget, Status/Typ, Rollen). `ControlValueAccessor` →
 * Reactive Forms + `ngModel`. Token-basiert, eingebettetes Chevron, sichtbarer
 * Fokus-Ring, Label/`for`-Bindung + `aria-describedby` (a11y), Dark/Light.
 */
class SelectComponent {
    constructor() {
        this.label = '';
        /** Barrierefreier Name, wenn kein sichtbares Label gesetzt ist. */
        this.ariaLabel = '';
        this.placeholder = '';
        this.hint = '';
        this.error = '';
        this.required = false;
        this.options = [];
        this.id = `app-select-${nextId$5++}`;
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    get describedBy() {
        if (this.error)
            return `${this.id}-error`;
        if (this.hint)
            return `${this.id}-hint`;
        return null;
    }
    onSelect(event) {
        const v = event.target.value;
        this.value.set(v);
        this.onChange(v);
    }
    writeValue(value) {
        this.value.set(value ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: SelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: SelectComponent, isStandalone: true, selector: "app-select", inputs: { label: "label", ariaLabel: "ariaLabel", placeholder: "placeholder", hint: "hint", error: "error", required: "required", options: "options", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: SelectComponent, multi: true }], ngImport: i0, template: "<div class=\"flex flex-col gap-2\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <select\n    class=\"sel__control\"\n    [id]=\"id\"\n    [disabled]=\"disabled()\"\n    [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n    [attr.aria-invalid]=\"error ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy\"\n    [attr.required]=\"required ? '' : null\"\n    (change)=\"onSelect($event)\"\n    (blur)=\"onTouched()\"\n  >\n    <!-- Auswahl per [selected] je Option (nicht [value] am <select>): so greift sie\n         auch, wenn die Optionen ASYNC nachgeladen werden (z. B. Protokollant-Roster).\n         Ein [value] am <select> w\u00FCrde eine zum Setzzeitpunkt fehlende Option ignorieren\n         und auf den Platzhalter zur\u00FCckfallen (#select-async). -->\n    @if (placeholder) {\n      <option value=\"\" [disabled]=\"required\" [selected]=\"value() === ''\">{{ placeholder }}</option>\n    }\n    @for (opt of options; track opt.value) {\n      <option [value]=\"opt.value\" [selected]=\"opt.value === value()\" [disabled]=\"opt.disabled ?? false\">{{ opt.label }}</option>\n    }\n  </select>\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: [".sel__control{appearance:none;-webkit-appearance:none;width:100%;height:var(--control-height);box-sizing:border-box;padding:0 var(--space-7) 0 var(--space-4);font-size:var(--fs-md);line-height:var(--lh-normal);color:var(--color-text);background-color:var(--color-surface);background-image:url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 12 12\"><path d=\"M2 4.5l4 4 4-4\" fill=\"none\" stroke=\"%236e756f\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>');background-repeat:no-repeat;background-position:right var(--space-3) center;background-size:.7rem;border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);cursor:pointer;transition:border-color var(--motion-fast) var(--ease-standard)}.sel__control:hover:not(:disabled){border-color:var(--color-text-muted)}.sel__control:disabled{opacity:.6;cursor:not-allowed}.sel__control[aria-invalid=true]{border-color:var(--color-danger)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: SelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-select', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: SelectComponent, multi: true }], template: "<div class=\"flex flex-col gap-2\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <select\n    class=\"sel__control\"\n    [id]=\"id\"\n    [disabled]=\"disabled()\"\n    [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n    [attr.aria-invalid]=\"error ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy\"\n    [attr.required]=\"required ? '' : null\"\n    (change)=\"onSelect($event)\"\n    (blur)=\"onTouched()\"\n  >\n    <!-- Auswahl per [selected] je Option (nicht [value] am <select>): so greift sie\n         auch, wenn die Optionen ASYNC nachgeladen werden (z. B. Protokollant-Roster).\n         Ein [value] am <select> w\u00FCrde eine zum Setzzeitpunkt fehlende Option ignorieren\n         und auf den Platzhalter zur\u00FCckfallen (#select-async). -->\n    @if (placeholder) {\n      <option value=\"\" [disabled]=\"required\" [selected]=\"value() === ''\">{{ placeholder }}</option>\n    }\n    @for (opt of options; track opt.value) {\n      <option [value]=\"opt.value\" [selected]=\"opt.value === value()\" [disabled]=\"opt.disabled ?? false\">{{ opt.label }}</option>\n    }\n  </select>\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: [".sel__control{appearance:none;-webkit-appearance:none;width:100%;height:var(--control-height);box-sizing:border-box;padding:0 var(--space-7) 0 var(--space-4);font-size:var(--fs-md);line-height:var(--lh-normal);color:var(--color-text);background-color:var(--color-surface);background-image:url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 12 12\"><path d=\"M2 4.5l4 4 4-4\" fill=\"none\" stroke=\"%236e756f\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>');background-repeat:no-repeat;background-position:right var(--space-3) center;background-size:.7rem;border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);cursor:pointer;transition:border-color var(--motion-fast) var(--ease-standard)}.sel__control:hover:not(:disabled){border-color:var(--color-text-muted)}.sel__control:disabled{opacity:.6;cursor:not-allowed}.sel__control[aria-invalid=true]{border-color:var(--color-danger)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], hint: [{
                type: Input
            }], error: [{
                type: Input
            }], required: [{
                type: Input
            }], options: [{
                type: Input
            }], id: [{
                type: Input
            }] } });

let nextId$4 = 0;
/**
 * Datumsfeld des UI-Kits (#79). **Lokalisiertes** Anzeigeformat (DE: `TT.MM.JJJJ`,
 * EN: `MM/DD/YYYY`) — unabhängig von der Browser-Sprache, die das native
 * `<input type="date">` sonst erzwingt. Der Wert ist immer ISO (`YYYY-MM-DD`).
 *
 * Bedienung: tippen im Textfeld (locale-Reihenfolge) **oder** den nativen Kalender
 * über den Kalender-Button öffnen (`showPicker()`; das native Feld bleibt unsichtbar,
 * nur sein Kalender-Popup erscheint). `ControlValueAccessor` → Reactive Forms/`ngModel`.
 */
class DatepickerComponent {
    constructor() {
        this.intl = inject(UI_KIT_INTL);
        this.label = '';
        this.ariaLabel = '';
        this.hint = '';
        this.error = '';
        this.required = false;
        this.min = '';
        this.max = '';
        this.id = `app-datepicker-${nextId$4++}`;
        this.native = viewChild('native', ...(ngDevMode ? [{ debugName: "native" }] : []));
        /** ISO-Wert (`YYYY-MM-DD`), CVA-Quelle. */
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        /** Sichtbarer (locale-formatierter) Text — beim Tippen unverändert übernommen. */
        this.display = signal('', ...(ngDevMode ? [{ debugName: "display" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.placeholder = computed(() => this.intl.lang() === 'de' ? 'TT.MM.JJJJ' : 'MM/DD/YYYY', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
        // Anzeige folgt der App-Sprache (#datepicker-locale): ein Sprachwechsel
        // formatiert den sichtbaren Wert sofort um (TT.MM.JJJJ ↔ MM/DD/YYYY) —
        // vorher blieb das alte Format bis zum nächsten writeValue/Commit stehen.
        effect(() => {
            this.intl.lang();
            this.display.set(this.format(this.value()));
        });
    }
    get describedBy() {
        if (this.error)
            return `${this.id}-error`;
        if (this.hint)
            return `${this.id}-hint`;
        return null;
    }
    // Anzeige folgt der Eingabe; Commit (parse → ISO) erst bei Blur.
    onText(text) {
        this.display.set(text);
    }
    onBlur() {
        this.onTouched();
        const iso = this.parse(this.display());
        if (iso) {
            this.commit(iso);
        }
        else if (!this.display().trim()) {
            this.commit('');
        }
        else {
            // Ungültig → letzten gültigen Wert wieder anzeigen.
            this.display.set(this.format(this.value()));
        }
    }
    onNative(iso) {
        this.commit(iso);
    }
    openPicker() {
        const el = this.native()?.nativeElement;
        if (!el)
            return;
        const withPicker = el;
        if (typeof withPicker.showPicker === 'function') {
            withPicker.showPicker();
        }
        else {
            el.focus();
            el.click();
        }
    }
    commit(iso) {
        this.value.set(iso);
        this.display.set(this.format(iso));
        this.onChange(iso);
    }
    /** ISO → locale-Anzeige. */
    format(iso) {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso ?? '');
        if (!m)
            return '';
        const [, y, mo, d] = m;
        return this.intl.lang() === 'de' ? `${d}.${mo}.${y}` : `${mo}/${d}/${y}`;
    }
    /** Locale-Text → ISO (oder `''`). Akzeptiert `. / -` als Trenner; 2-stellige Jahre → 20xx. */
    parse(text) {
        const parts = text.trim().split(/[./\-\s]+/).filter(Boolean);
        if (parts.length !== 3)
            return '';
        const [a, b, y] = parts;
        const day = this.intl.lang() === 'de' ? a : b;
        const month = this.intl.lang() === 'de' ? b : a;
        let yyyy = Number(y);
        const dd = Number(day);
        const mm = Number(month);
        if (!dd || !mm || !yyyy)
            return '';
        if (yyyy < 100)
            yyyy += 2000;
        if (mm < 1 || mm > 12 || dd < 1 || dd > 31)
            return '';
        const iso = `${String(yyyy).padStart(4, '0')}-${String(mm).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
        const dt = new Date(iso + 'T00:00:00');
        return Number.isNaN(dt.getTime()) ? '' : iso;
    }
    writeValue(value) {
        const iso = value ?? '';
        this.value.set(iso);
        this.display.set(this.format(iso));
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DatepickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: DatepickerComponent, isStandalone: true, selector: "app-datepicker", inputs: { label: "label", ariaLabel: "ariaLabel", hint: "hint", error: "error", required: "required", min: "min", max: "max", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: DatepickerComponent, multi: true }], viewQueries: [{ propertyName: "native", first: true, predicate: ["native"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"dp\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <div class=\"relative flex\">\n    <input\n      class=\"dp__text\"\n      type=\"text\"\n      inputmode=\"numeric\"\n      autocomplete=\"off\"\n      [id]=\"id\"\n      [value]=\"display()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n      [attr.aria-invalid]=\"error ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy\"\n      [attr.required]=\"required ? '' : null\"\n      (input)=\"onText($any($event.target).value)\"\n      (blur)=\"onBlur()\"\n    />\n    <button\n      type=\"button\"\n      class=\"dp__cal\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"'datepicker.openCalendar' | uiKitT\"\n      (click)=\"openPicker()\"\n    >\n      <svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" aria-hidden=\"true\">\n        <rect x=\"3\" y=\"4\" width=\"18\" height=\"18\" rx=\"2\" /><path d=\"M16 2v4M8 2v4M3 10h18\" />\n      </svg>\n    </button>\n    <input\n      #native\n      class=\"dp__native\"\n      type=\"date\"\n      tabindex=\"-1\"\n      aria-hidden=\"true\"\n      [value]=\"value()\"\n      [attr.min]=\"min || null\"\n      [attr.max]=\"max || null\"\n      (change)=\"onNative($any($event.target).value)\"\n    />\n  </div>\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{display:block;min-width:0}.dp{display:flex;flex-direction:column;gap:var(--space-2);min-width:0}.dp__text{flex:1;min-width:0;width:100%;height:var(--control-height);box-sizing:border-box;padding:0 2.5rem 0 var(--space-4);font:inherit;font-size:var(--fs-md);color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.dp__text:hover:not(:disabled){border-color:var(--color-text-muted)}.dp__text:disabled{opacity:.6;cursor:not-allowed}.dp__text[aria-invalid=true]{border-color:var(--color-danger)}.dp__cal{position:absolute;right:0;top:0;height:var(--control-height);width:2.5rem;display:inline-flex;align-items:center;justify-content:center;background:transparent;border:0;color:var(--color-text-muted);cursor:pointer;border-radius:var(--radius-md)}.dp__cal:hover:not(:disabled){color:var(--color-text)}.dp__cal:disabled{opacity:.6;cursor:not-allowed}.dp__native{position:absolute;right:.5rem;bottom:0;width:1px;height:1px;opacity:0;pointer-events:none;border:0;padding:0}\n"], dependencies: [{ kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DatepickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-datepicker', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: DatepickerComponent, multi: true }], template: "<div class=\"dp\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <div class=\"relative flex\">\n    <input\n      class=\"dp__text\"\n      type=\"text\"\n      inputmode=\"numeric\"\n      autocomplete=\"off\"\n      [id]=\"id\"\n      [value]=\"display()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n      [attr.aria-invalid]=\"error ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy\"\n      [attr.required]=\"required ? '' : null\"\n      (input)=\"onText($any($event.target).value)\"\n      (blur)=\"onBlur()\"\n    />\n    <button\n      type=\"button\"\n      class=\"dp__cal\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"'datepicker.openCalendar' | uiKitT\"\n      (click)=\"openPicker()\"\n    >\n      <svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" aria-hidden=\"true\">\n        <rect x=\"3\" y=\"4\" width=\"18\" height=\"18\" rx=\"2\" /><path d=\"M16 2v4M8 2v4M3 10h18\" />\n      </svg>\n    </button>\n    <input\n      #native\n      class=\"dp__native\"\n      type=\"date\"\n      tabindex=\"-1\"\n      aria-hidden=\"true\"\n      [value]=\"value()\"\n      [attr.min]=\"min || null\"\n      [attr.max]=\"max || null\"\n      (change)=\"onNative($any($event.target).value)\"\n    />\n  </div>\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{display:block;min-width:0}.dp{display:flex;flex-direction:column;gap:var(--space-2);min-width:0}.dp__text{flex:1;min-width:0;width:100%;height:var(--control-height);box-sizing:border-box;padding:0 2.5rem 0 var(--space-4);font:inherit;font-size:var(--fs-md);color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.dp__text:hover:not(:disabled){border-color:var(--color-text-muted)}.dp__text:disabled{opacity:.6;cursor:not-allowed}.dp__text[aria-invalid=true]{border-color:var(--color-danger)}.dp__cal{position:absolute;right:0;top:0;height:var(--control-height);width:2.5rem;display:inline-flex;align-items:center;justify-content:center;background:transparent;border:0;color:var(--color-text-muted);cursor:pointer;border-radius:var(--radius-md)}.dp__cal:hover:not(:disabled){color:var(--color-text)}.dp__cal:disabled{opacity:.6;cursor:not-allowed}.dp__native{position:absolute;right:.5rem;bottom:0;width:1px;height:1px;opacity:0;pointer-events:none;border:0;padding:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], hint: [{
                type: Input
            }], error: [{
                type: Input
            }], required: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], id: [{
                type: Input
            }], native: [{ type: i0.ViewChild, args: ['native', { isSignal: true }] }] } });

let nextId$3 = 0;
/**
 * Uhrzeit-Feld des UI-Kits (#time-input). Erzwingt **24h-Format** (`HH:MM`) —
 * das native `<input type="time">` rendert je nach Browser-/OS-Locale AM/PM,
 * unabhängig von der App-Sprache. Der Wert ist immer `HH:MM` (oder `''`).
 *
 * Eingabe tolerant: `9:30`, `09.30`, `0930` → `09:30`; Commit bei Blur,
 * Ungültiges fällt auf den letzten gültigen Wert zurück (wie `app-datepicker`).
 * `ControlValueAccessor` → Reactive Forms/`ngModel`.
 */
class TimeInputComponent {
    constructor() {
        this.label = '';
        this.ariaLabel = '';
        this.required = false;
        this.id = `app-time-input-${nextId$3++}`;
        /** Kanonischer Wert (`HH:MM` | `''`), CVA-Quelle. */
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        /** Sichtbarer Text — beim Tippen unverändert, Commit bei Blur. */
        this.display = signal('', ...(ngDevMode ? [{ debugName: "display" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    onText(text) {
        this.display.set(text);
    }
    onBlur() {
        this.onTouched();
        const parsed = parseTime(this.display());
        if (parsed !== null) {
            this.commit(parsed);
        }
        else {
            // Ungültig → letzten gültigen Wert wieder anzeigen.
            this.display.set(this.value());
        }
    }
    commit(value) {
        this.value.set(value);
        this.display.set(value);
        this.onChange(value);
    }
    writeValue(value) {
        const v = normalizeWire(value);
        this.value.set(v);
        this.display.set(v);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: TimeInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: TimeInputComponent, isStandalone: true, selector: "app-time-input", inputs: { label: "label", ariaLabel: "ariaLabel", required: "required", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: TimeInputComponent, multi: true }], ngImport: i0, template: "<div class=\"flex flex-col gap-2\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <input\n    class=\"ti__text\"\n    type=\"text\"\n    inputmode=\"numeric\"\n    autocomplete=\"off\"\n    placeholder=\"HH:MM\"\n    [id]=\"id\"\n    [value]=\"display()\"\n    [disabled]=\"disabled()\"\n    [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n    [attr.required]=\"required ? '' : null\"\n    (input)=\"onText($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  />\n</div>\n", styles: [".ti__text{height:var(--control-height);box-sizing:border-box;padding:0 var(--space-4);font:inherit;font-size:var(--fs-md);font-variant-numeric:tabular-nums;color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.ti__text:hover:not(:disabled){border-color:var(--color-text-muted)}.ti__text:disabled{opacity:.6;cursor:not-allowed}.ti__text:focus-visible{outline:2px solid var(--color-primary);outline-offset:1px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: TimeInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-time-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: TimeInputComponent, multi: true }], template: "<div class=\"flex flex-col gap-2\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <input\n    class=\"ti__text\"\n    type=\"text\"\n    inputmode=\"numeric\"\n    autocomplete=\"off\"\n    placeholder=\"HH:MM\"\n    [id]=\"id\"\n    [value]=\"display()\"\n    [disabled]=\"disabled()\"\n    [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n    [attr.required]=\"required ? '' : null\"\n    (input)=\"onText($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  />\n</div>\n", styles: [".ti__text{height:var(--control-height);box-sizing:border-box;padding:0 var(--space-4);font:inherit;font-size:var(--fs-md);font-variant-numeric:tabular-nums;color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.ti__text:hover:not(:disabled){border-color:var(--color-text-muted)}.ti__text:disabled{opacity:.6;cursor:not-allowed}.ti__text:focus-visible{outline:2px solid var(--color-primary);outline-offset:1px}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], required: [{
                type: Input
            }], id: [{
                type: Input
            }] } });
/** Wire-Wert normalisieren: `HH:MM:SS` (Backend-`time`) → `HH:MM`. */
function normalizeWire(value) {
    const m = /^(\d{2}):(\d{2})/.exec(value ?? '');
    return m ? `${m[1]}:${m[2]}` : '';
}
/** Freie Eingabe → `HH:MM` (24h) | `''` (leer) | `null` (ungültig). */
function parseTime(text) {
    const t = text.trim();
    if (!t)
        return '';
    const m = /^(\d{1,2})[:.,]?([0-5]\d)$/.exec(t) ?? /^(\d{1,2})$/.exec(t);
    if (!m)
        return null;
    const hh = Number(m[1]);
    const mm = m[2] !== undefined ? Number(m[2]) : 0;
    if (hh > 23)
        return null;
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

let nextId$2 = 0;
/**
 * Zeitraum-Feld (#79): zwei gekoppelte native Datumsfelder (Start/Ende). Das Ende
 * kann nicht vor dem Start liegen (`min`/`max`-Kopplung). Wert ist `{ start, end }`;
 * `ControlValueAccessor` → Reactive Forms + `ngModel`. a11y über `<fieldset>` +
 * `<legend>` und `<label for>`-Bindung je Feld; native Kalender-UI folgt dem Theme
 * (`color-scheme`), Dark/Light via Tokens.
 */
class DateRangeComponent {
    constructor() {
        this.legend = '';
        this.startLabel = '';
        this.endLabel = '';
        this.id = `app-date-range-${nextId$2++}`;
        this.start = signal('', ...(ngDevMode ? [{ debugName: "start" }] : []));
        this.end = signal('', ...(ngDevMode ? [{ debugName: "end" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    onStart(v) {
        this.start.set(v);
        this.emit();
    }
    onEnd(v) {
        this.end.set(v);
        this.emit();
    }
    emit() {
        this.onChange({ start: this.start(), end: this.end() });
    }
    writeValue(value) {
        this.start.set(value?.start ?? '');
        this.end.set(value?.end ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DateRangeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: DateRangeComponent, isStandalone: true, selector: "app-date-range", inputs: { legend: "legend", startLabel: "startLabel", endLabel: "endLabel", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: DateRangeComponent, multi: true }], ngImport: i0, template: "<fieldset class=\"dr\">\n  @if (legend) {\n    <legend class=\"p-0 mb-2 text-sm font-semibold text-text\">{{ legend }}</legend>\n  }\n  <div class=\"flex items-end gap-3 flex-wrap\">\n    <div class=\"dr__field\">\n      <app-datepicker\n        [id]=\"id + '-start'\"\n        [ariaLabel]=\"startLabel\"\n        [max]=\"end()\"\n        [ngModel]=\"start()\"\n        (ngModelChange)=\"onStart($event)\"\n      />\n    </div>\n    <span class=\"pb-3 text-muted\" aria-hidden=\"true\">\u2013</span>\n    <div class=\"dr__field\">\n      <app-datepicker\n        [id]=\"id + '-end'\"\n        [ariaLabel]=\"endLabel\"\n        [min]=\"start()\"\n        [ngModel]=\"end()\"\n        (ngModelChange)=\"onEnd($event)\"\n      />\n    </div>\n  </div>\n</fieldset>\n", styles: [".dr{border:0;margin:0;padding:0;min-inline-size:0}.dr__field{display:flex;flex-direction:column;gap:var(--space-2);flex:1 1 9rem}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: DatepickerComponent, selector: "app-datepicker", inputs: ["label", "ariaLabel", "hint", "error", "required", "min", "max", "id"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DateRangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-date-range', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [FormsModule, DatepickerComponent], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: DateRangeComponent, multi: true }], template: "<fieldset class=\"dr\">\n  @if (legend) {\n    <legend class=\"p-0 mb-2 text-sm font-semibold text-text\">{{ legend }}</legend>\n  }\n  <div class=\"flex items-end gap-3 flex-wrap\">\n    <div class=\"dr__field\">\n      <app-datepicker\n        [id]=\"id + '-start'\"\n        [ariaLabel]=\"startLabel\"\n        [max]=\"end()\"\n        [ngModel]=\"start()\"\n        (ngModelChange)=\"onStart($event)\"\n      />\n    </div>\n    <span class=\"pb-3 text-muted\" aria-hidden=\"true\">\u2013</span>\n    <div class=\"dr__field\">\n      <app-datepicker\n        [id]=\"id + '-end'\"\n        [ariaLabel]=\"endLabel\"\n        [min]=\"start()\"\n        [ngModel]=\"end()\"\n        (ngModelChange)=\"onEnd($event)\"\n      />\n    </div>\n  </div>\n</fieldset>\n", styles: [".dr{border:0;margin:0;padding:0;min-inline-size:0}.dr__field{display:flex;flex-direction:column;gap:var(--space-2);flex:1 1 9rem}\n"] }]
        }], propDecorators: { legend: [{
                type: Input
            }], startLabel: [{
                type: Input
            }], endLabel: [{
                type: Input
            }], id: [{
                type: Input
            }] } });

/** Icon-Name → Font-Awesome-Solid-Klasse (#80, FA-Migration). */
const FA = {
    sun: 'fa-sun',
    moon: 'fa-moon',
    language: 'fa-language',
    edit: 'fa-pen-to-square',
    delete: 'fa-trash',
    add: 'fa-plus',
    remove: 'fa-xmark',
    members: 'fa-users',
    roles: 'fa-user-shield',
    user: 'fa-user',
    'chevron-down': 'fa-chevron-down',
    'chevron-up': 'fa-chevron-up',
    power: 'fa-power-off',
    filter: 'fa-filter',
    check: 'fa-check',
    building: 'fa-building',
    parliament: 'fa-landmark',
    euro: 'fa-euro-sign',
    form: 'fa-clipboard-list',
    flow: 'fa-diagram-project',
    palette: 'fa-palette',
    webhook: 'fa-globe',
    bell: 'fa-bell',
    audit: 'fa-clipboard-check',
    clock: 'fa-clock',
    export: 'fa-file-export',
    play: 'fa-play',
    stop: 'fa-stop',
    half: 'fa-circle-half-stroke',
    send: 'fa-paper-plane',
    repeat: 'fa-repeat',
    menu: 'fa-bars',
    gear: 'fa-gear',
    key: 'fa-key',
    handshake: 'fa-handshake',
    paperclip: 'fa-paperclip',
    link: 'fa-link',
    'link-slash': 'fa-link-slash',
    eye: 'fa-eye',
    'eye-slash': 'fa-eye-slash',
    upload: 'fa-file-arrow-up',
    document: 'fa-file-lines',
    'chart-pie': 'fa-chart-pie',
};
/**
 * Icon-Komponente (#80). Rendert ein **Font-Awesome**-Solid-Icon (`fa-solid`),
 * gesteuert über einen stabilen, semantischen `name`. Dekorativ
 * (`aria-hidden`) — der barrierefreie Name kommt vom umschließenden Control.
 * `currentColor` folgt der Text-/Theme-Farbe automatisch (Dark/Light).
 */
class IconComponent {
    constructor() {
        this._name = signal('sun', ...(ngDevMode ? [{ debugName: "_name" }] : []));
        /** Kantenlänge in px (Schriftgröße des Glyphs). */
        this.size = 18;
        this.faClass = computed(() => FA[this._name()] ?? 'fa-circle-question', ...(ngDevMode ? [{ debugName: "faClass" }] : []));
    }
    set name(value) {
        this._name.set(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.25", type: IconComponent, isStandalone: true, selector: "app-icon", inputs: { name: "name", size: "size" }, ngImport: i0, template: "<i class=\"fa-solid\" [class]=\"faClass()\" [style.fontSize.px]=\"size\" aria-hidden=\"true\"></i>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;line-height:0}i{line-height:1}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<i class=\"fa-solid\" [class]=\"faClass()\" [style.fontSize.px]=\"size\" aria-hidden=\"true\"></i>\n", styles: [":host{display:inline-flex;align-items:center;justify-content:center;line-height:0}i{line-height:1}\n"] }]
        }], propDecorators: { name: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

/** Container-Fläche. Slots: [card-header], default body, [card-footer]. */
class CardComponent {
    constructor() {
        this.heading = '';
        this.interactive = false;
        /** Überschriften-Ebene des `heading` (a11y/heading-order). Default `<h3>`. */
        this.headingLevel = 3;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: CardComponent, isStandalone: true, selector: "app-card", inputs: { heading: "heading", interactive: "interactive", headingLevel: "headingLevel" }, ngImport: i0, template: "<section class=\"card\" [class.card--interactive]=\"interactive\">\n  <header class=\"card__header\">\n    @if (heading) {\n      @switch (headingLevel) {\n        @case (2) {\n          <h2 class=\"text-lg font-semibold\">{{ heading }}</h2>\n        }\n        @case (4) {\n          <h4 class=\"text-lg font-semibold\">{{ heading }}</h4>\n        }\n        @default {\n          <h3 class=\"text-lg font-semibold\">{{ heading }}</h3>\n        }\n      }\n    }\n    <ng-content select=\"[card-header]\" />\n  </header>\n  <div class=\"p-5\"><ng-content /></div>\n  <footer class=\"card__footer\"><ng-content select=\"[card-footer]\" /></footer>\n</section>\n", styles: [":host{display:flex;flex-direction:column}.card{flex:1 1 auto;display:flex;flex-direction:column;background:var(--color-surface);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);overflow:hidden}.card--interactive{transition:box-shadow var(--motion-base) var(--ease-standard),border-color var(--motion-base) var(--ease-standard),background-color var(--motion-fast) var(--ease-standard)}.card--interactive:hover{box-shadow:var(--shadow-md);border-color:var(--color-border-strong)}.card--interactive:active{background:var(--color-surface-sunken)}.card__header:empty,.card__footer:empty{display:none}.card__header{padding:var(--space-5) var(--space-5) 0}.card__footer{padding:0 var(--space-5) var(--space-5)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-card', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<section class=\"card\" [class.card--interactive]=\"interactive\">\n  <header class=\"card__header\">\n    @if (heading) {\n      @switch (headingLevel) {\n        @case (2) {\n          <h2 class=\"text-lg font-semibold\">{{ heading }}</h2>\n        }\n        @case (4) {\n          <h4 class=\"text-lg font-semibold\">{{ heading }}</h4>\n        }\n        @default {\n          <h3 class=\"text-lg font-semibold\">{{ heading }}</h3>\n        }\n      }\n    }\n    <ng-content select=\"[card-header]\" />\n  </header>\n  <div class=\"p-5\"><ng-content /></div>\n  <footer class=\"card__footer\"><ng-content select=\"[card-footer]\" /></footer>\n</section>\n", styles: [":host{display:flex;flex-direction:column}.card{flex:1 1 auto;display:flex;flex-direction:column;background:var(--color-surface);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);overflow:hidden}.card--interactive{transition:box-shadow var(--motion-base) var(--ease-standard),border-color var(--motion-base) var(--ease-standard),background-color var(--motion-fast) var(--ease-standard)}.card--interactive:hover{box-shadow:var(--shadow-md);border-color:var(--color-border-strong)}.card--interactive:active{background:var(--color-surface-sunken)}.card__header:empty,.card__footer:empty{display:none}.card__header{padding:var(--space-5) var(--space-5) 0}.card__footer{padding:0 var(--space-5) var(--space-5)}\n"] }]
        }], propDecorators: { heading: [{
                type: Input
            }], interactive: [{
                type: Input
            }], headingLevel: [{
                type: Input
            }] } });

/** Status-Chip (z. B. Antrags-Status, Vote-Ergebnis). */
class BadgeComponent {
    constructor() {
        this.variant = 'neutral';
    }
    /** Lesbare Textfarbe für {@link color} via Luminanz-Schwelle. */
    get textColor() {
        return readableTextColor(this.color) ?? '#ffffff';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: BadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.25", type: BadgeComponent, isStandalone: true, selector: "app-badge", inputs: { variant: "variant", color: "color" }, ngImport: i0, template: "<span\n    class=\"badge\"\n    [class]=\"color ? 'badge--custom' : 'badge--' + variant\"\n    [style.background]=\"color || null\"\n    [style.color]=\"color ? textColor : null\"\n    ><ng-content\n  /></span>\n", styles: [".badge{display:inline-flex;align-items:center;padding:var(--space-1) var(--space-3);font-size:var(--fs-xs);font-weight:var(--fw-semibold);line-height:1.4;border-radius:var(--radius-pill);white-space:nowrap}.badge--neutral{background:var(--color-surface-sunken);color:var(--color-text-muted)}.badge--primary{background:var(--color-primary-subtle);color:var(--color-primary)}.badge--success{background:var(--color-success-subtle);color:var(--color-success)}.badge--warning{background:var(--color-warning-subtle);color:var(--color-warning)}.badge--danger{background:var(--color-danger-subtle);color:var(--color-danger)}.badge--info{background:var(--color-info-subtle);color:var(--color-info)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: BadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-badge', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span\n    class=\"badge\"\n    [class]=\"color ? 'badge--custom' : 'badge--' + variant\"\n    [style.background]=\"color || null\"\n    [style.color]=\"color ? textColor : null\"\n    ><ng-content\n  /></span>\n", styles: [".badge{display:inline-flex;align-items:center;padding:var(--space-1) var(--space-3);font-size:var(--fs-xs);font-weight:var(--fw-semibold);line-height:1.4;border-radius:var(--radius-pill);white-space:nowrap}.badge--neutral{background:var(--color-surface-sunken);color:var(--color-text-muted)}.badge--primary{background:var(--color-primary-subtle);color:var(--color-primary)}.badge--success{background:var(--color-success-subtle);color:var(--color-success)}.badge--warning{background:var(--color-warning-subtle);color:var(--color-warning)}.badge--danger{background:var(--color-danger-subtle);color:var(--color-danger)}.badge--info{background:var(--color-info-subtle);color:var(--color-info)}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }] } });
/**
 * Liefert `#1a1a1a` (dunkel) oder `#ffffff` (weiß) je nach wahrgenommener
 * Helligkeit der gegebenen Hex-Farbe. Gibt `null` bei ungültiger Eingabe.
 */
function readableTextColor(hex) {
    if (!hex)
        return null;
    let h = hex.trim().replace(/^#/, '');
    if (h.length === 3) {
        h = h
            .split('')
            .map((c) => c + c)
            .join('');
    }
    if (!/^[0-9a-fA-F]{6}$/.test(h))
        return null;
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    // Relative Luminanz (sRGB, schnelle Variante).
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.6 ? '#1a1a1a' : '#ffffff';
}

/**
 * Feld-Diff-Renderer (added/removed/changed) — z. B. für Antrags-Historie
 * (Submission-Versionen) oder Config-Versionen (Forms/Flow/Branding). Reine
 * Präsentation: nimmt einen aufgelösten {@link ConfigDiffData} (Arrays) und rendert
 * je Eintrag ein Severity-Badge + Feld-Key + Alt→Neu-Werte.
 */
class ConfigDiffComponent {
    constructor() {
        /** Aufgelöster Diff (`null`/leer ⇒ »keine Änderungen«). */
        this.diff = input(null, ...(ngDevMode ? [{ debugName: "diff" }] : []));
    }
    isEmpty(d) {
        return !d || (d.added.length === 0 && d.removed.length === 0 && d.changed.length === 0);
    }
    /** Wert lesbar machen (Objekte als JSON; null/undefined als »—«). */
    fmt(value) {
        if (value === null || value === undefined)
            return '—';
        return typeof value === 'object' ? JSON.stringify(value) : String(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ConfigDiffComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: ConfigDiffComponent, isStandalone: true, selector: "app-config-diff", inputs: { diff: { classPropertyName: "diff", publicName: "diff", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (isEmpty(diff())) {\n  <p class=\"text-muted cfg-diff__none\">{{ 'diff.none' | uiKitT }}</p>\n} @else {\n  <ul class=\"cfg-diff\">\n    @for (change of diff()!.changed; track change.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--changed\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"warning\">{{ 'diff.changed' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ change.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <del class=\"cfg-diff__val\">{{ fmt(change.old) }}</del>\n          <ins class=\"cfg-diff__val\">{{ fmt(change.new) }}</ins>\n        </div>\n      </li>\n    }\n    @for (added of diff()!.added; track added.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--added\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"success\">{{ 'diff.added' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ added.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <ins class=\"cfg-diff__val\">{{ fmt(added.value) }}</ins>\n        </div>\n      </li>\n    }\n    @for (removed of diff()!.removed; track removed.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--removed\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"danger\">{{ 'diff.removed' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ removed.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <del class=\"cfg-diff__val\">{{ fmt(removed.value) }}</del>\n        </div>\n      </li>\n    }\n  </ul>\n}\n", styles: [".cfg-diff{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-2, .5rem)}.cfg-diff__item{display:flex;flex-direction:column;gap:var(--space-1, .35rem);padding:var(--space-2, .5rem) var(--space-3, .75rem);border:var(--border-width, 1px) solid var(--color-border, #e5e7eb);border-left-width:3px;border-radius:var(--radius-sm, 6px);background:var(--color-surface-sunken, #f7f7f8)}.cfg-diff__item--changed{border-left-color:var(--color-warning, #b58100)}.cfg-diff__item--added{border-left-color:var(--color-success, #1b5e20)}.cfg-diff__item--removed{border-left-color:var(--color-danger, #b00020)}.cfg-diff__head{display:flex;align-items:center;gap:var(--space-2, .5rem);flex-wrap:wrap}.cfg-diff__key{font-family:var(--font-mono, monospace);font-size:var(--fs-sm, .875rem);font-weight:600;overflow-wrap:anywhere}.cfg-diff__vals{display:flex;flex-direction:column;gap:var(--space-1, .35rem)}.cfg-diff__val{font-family:var(--font-mono, monospace);font-size:var(--fs-xs, .78rem);line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere;text-decoration:none}del.cfg-diff__val{color:var(--color-danger, #b00020);text-decoration:line-through}ins.cfg-diff__val{color:var(--color-success, #1b5e20)}.cfg-diff__none{font-size:var(--fs-sm, .875rem)}\n"], dependencies: [{ kind: "component", type: BadgeComponent, selector: "app-badge", inputs: ["variant", "color"] }, { kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ConfigDiffComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-config-diff', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe, BadgeComponent], template: "@if (isEmpty(diff())) {\n  <p class=\"text-muted cfg-diff__none\">{{ 'diff.none' | uiKitT }}</p>\n} @else {\n  <ul class=\"cfg-diff\">\n    @for (change of diff()!.changed; track change.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--changed\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"warning\">{{ 'diff.changed' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ change.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <del class=\"cfg-diff__val\">{{ fmt(change.old) }}</del>\n          <ins class=\"cfg-diff__val\">{{ fmt(change.new) }}</ins>\n        </div>\n      </li>\n    }\n    @for (added of diff()!.added; track added.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--added\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"success\">{{ 'diff.added' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ added.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <ins class=\"cfg-diff__val\">{{ fmt(added.value) }}</ins>\n        </div>\n      </li>\n    }\n    @for (removed of diff()!.removed; track removed.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--removed\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"danger\">{{ 'diff.removed' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ removed.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <del class=\"cfg-diff__val\">{{ fmt(removed.value) }}</del>\n        </div>\n      </li>\n    }\n  </ul>\n}\n", styles: [".cfg-diff{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-2, .5rem)}.cfg-diff__item{display:flex;flex-direction:column;gap:var(--space-1, .35rem);padding:var(--space-2, .5rem) var(--space-3, .75rem);border:var(--border-width, 1px) solid var(--color-border, #e5e7eb);border-left-width:3px;border-radius:var(--radius-sm, 6px);background:var(--color-surface-sunken, #f7f7f8)}.cfg-diff__item--changed{border-left-color:var(--color-warning, #b58100)}.cfg-diff__item--added{border-left-color:var(--color-success, #1b5e20)}.cfg-diff__item--removed{border-left-color:var(--color-danger, #b00020)}.cfg-diff__head{display:flex;align-items:center;gap:var(--space-2, .5rem);flex-wrap:wrap}.cfg-diff__key{font-family:var(--font-mono, monospace);font-size:var(--fs-sm, .875rem);font-weight:600;overflow-wrap:anywhere}.cfg-diff__vals{display:flex;flex-direction:column;gap:var(--space-1, .35rem)}.cfg-diff__val{font-family:var(--font-mono, monospace);font-size:var(--fs-xs, .78rem);line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere;text-decoration:none}del.cfg-diff__val{color:var(--color-danger, #b00020);text-decoration:line-through}ins.cfg-diff__val{color:var(--color-success, #1b5e20)}.cfg-diff__none{font-size:var(--fs-sm, .875rem)}\n"] }]
        }], propDecorators: { diff: [{ type: i0.Input, args: [{ isSignal: true, alias: "diff", required: false }] }] } });

/** Fortschrittsanzeige für den Antrags-Wizard (N1a Multi-Step). */
class StepperComponent {
    constructor() {
        this.steps = [];
        this.activeIndex = 0;
        this.ariaLabel = 'Fortschritt';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: StepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: StepperComponent, isStandalone: true, selector: "app-stepper", inputs: { steps: "steps", activeIndex: "activeIndex", ariaLabel: "ariaLabel" }, ngImport: i0, template: "<ol class=\"stepper\" [attr.aria-label]=\"ariaLabel\">\n  @for (step of steps; track step.label; let i = $index) {\n    <li\n      class=\"stepper__item\"\n      [class.is-active]=\"i === activeIndex\"\n      [class.is-done]=\"i < activeIndex\"\n      [attr.aria-current]=\"i === activeIndex ? 'step' : null\"\n    >\n      <span class=\"stepper__marker\">{{ i < activeIndex ? '\u2713' : i + 1 }}</span>\n      <span class=\"stepper__label\">{{ step.label }}</span>\n    </li>\n  }\n</ol>\n", styles: [".stepper{display:flex;flex-wrap:wrap;gap:var(--space-5);padding:0;margin:0;list-style:none}.stepper__item{display:inline-flex;align-items:center;gap:var(--space-2);color:var(--color-text-muted);font-size:var(--fs-sm)}.stepper__marker{display:inline-flex;align-items:center;justify-content:center;width:1.75rem;height:1.75rem;border-radius:var(--radius-pill);border:var(--border-width) solid var(--color-border-strong);font-weight:var(--fw-semibold);font-size:var(--fs-sm)}.stepper__item.is-active{color:var(--color-text)}.stepper__item.is-active .stepper__marker{background:var(--color-primary);border-color:var(--color-primary);color:var(--color-on-primary)}.stepper__item.is-done .stepper__marker{background:var(--color-primary-subtle);border-color:var(--color-primary);color:var(--color-primary)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: StepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-stepper', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ol class=\"stepper\" [attr.aria-label]=\"ariaLabel\">\n  @for (step of steps; track step.label; let i = $index) {\n    <li\n      class=\"stepper__item\"\n      [class.is-active]=\"i === activeIndex\"\n      [class.is-done]=\"i < activeIndex\"\n      [attr.aria-current]=\"i === activeIndex ? 'step' : null\"\n    >\n      <span class=\"stepper__marker\">{{ i < activeIndex ? '\u2713' : i + 1 }}</span>\n      <span class=\"stepper__label\">{{ step.label }}</span>\n    </li>\n  }\n</ol>\n", styles: [".stepper{display:flex;flex-wrap:wrap;gap:var(--space-5);padding:0;margin:0;list-style:none}.stepper__item{display:inline-flex;align-items:center;gap:var(--space-2);color:var(--color-text-muted);font-size:var(--fs-sm)}.stepper__marker{display:inline-flex;align-items:center;justify-content:center;width:1.75rem;height:1.75rem;border-radius:var(--radius-pill);border:var(--border-width) solid var(--color-border-strong);font-weight:var(--fw-semibold);font-size:var(--fs-sm)}.stepper__item.is-active{color:var(--color-text)}.stepper__item.is-active .stepper__marker{background:var(--color-primary);border-color:var(--color-primary);color:var(--color-on-primary)}.stepper__item.is-done .stepper__marker{background:var(--color-primary-subtle);border-color:var(--color-primary);color:var(--color-primary)}\n"] }]
        }], propDecorators: { steps: [{
                type: Input
            }], activeIndex: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }] } });

let nextId$1 = 0;
/**
 * Modaler Dialog. Schließt per Backdrop-Klick, Schließen-Button oder ESC.
 *
 * a11y (T-43, WCAG 2.1.2/2.4.3): Beim Öffnen wandert der Fokus in den Dialog,
 * Tab/Shift+Tab werden im Dialog gefangen (Focus-Trap), beim Schließen kehrt der
 * Fokus auf das auslösende Element zurück. `aria-modal`/`role="dialog"` +
 * `aria-labelledby` sind gesetzt.
 */
class DialogComponent {
    constructor() {
        this.open = false;
        this.title = '';
        this.closeLabel = 'Schließen';
        /** Breite: 'md' (32rem, Default) oder 'lg' (44rem, z. B. Charts). */
        this.size = 'md';
        this.closed = new EventEmitter();
        this.titleId = `app-dialog-title-${nextId$1++}`;
        /** Element, das vor dem Öffnen den Fokus hatte — für Restore beim Schließen. */
        this.previouslyFocused = null;
        /** Body-Scroll-Sperre: gemerkter vorheriger overflow-Wert für den Restore. */
        this.prevBodyOverflow = null;
        // Drag-to-dismiss (Mobile-Sheet, #14).
        this.dragStartY = 0;
        this.dragStartT = 0;
        this.dragging = false;
        this.dragDy = 0;
    }
    ngOnChanges(changes) {
        const c = changes['open'];
        if (!c || c.firstChange) {
            if (this.open) {
                this.captureAndFocus();
                this.lockScroll();
            }
            return;
        }
        if (!c.previousValue && c.currentValue) {
            this.captureAndFocus();
            this.lockScroll();
        }
        else if (c.previousValue && !c.currentValue) {
            this.restoreFocus();
            this.unlockScroll();
        }
    }
    ngOnDestroy() {
        // Falls der Dialog im offenen Zustand zerstört wird: Scroll-Sperre lösen.
        this.unlockScroll();
    }
    onEscape() {
        if (this.open)
            this.close();
    }
    /** Tab/Shift+Tab im Dialog halten (Focus-Trap). */
    onKeydown(event) {
        if (!this.open || event.key !== 'Tab')
            return;
        const pane = this.pane?.nativeElement;
        if (!pane)
            return;
        const focusables = this.focusable(pane);
        if (focusables.length === 0) {
            event.preventDefault();
            pane.focus();
            return;
        }
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        const active = document.activeElement;
        if (event.shiftKey && (active === first || active === pane)) {
            event.preventDefault();
            last.focus();
        }
        else if (!event.shiftKey && active === last) {
            event.preventDefault();
            first.focus();
        }
    }
    onBackdrop(_event) {
        this.close();
    }
    // --- Drag-to-dismiss (Mobile-Sheet, #14) -----------------------------------
    onDragStart(event) {
        if (event.touches.length !== 1)
            return;
        this.dragging = true;
        this.dragStartY = event.touches[0].clientY;
        this.dragStartT = event.timeStamp;
        this.dragDy = 0;
        const pane = this.pane?.nativeElement;
        if (pane)
            pane.style.transition = 'none';
    }
    onDragMove(event) {
        if (!this.dragging)
            return;
        // Nur nach unten ziehen (kein „Hochziehen").
        this.dragDy = Math.max(0, event.touches[0].clientY - this.dragStartY);
        const pane = this.pane?.nativeElement;
        if (pane)
            pane.style.transform = `translateY(${this.dragDy}px)`;
    }
    onDragEnd(event) {
        if (!this.dragging)
            return;
        this.dragging = false;
        const pane = this.pane?.nativeElement;
        if (pane)
            pane.style.transition = '';
        const dt = event.timeStamp - this.dragStartT;
        const velocity = this.dragDy / Math.max(1, dt); // px/ms
        // Flick (schnelle Abwärtsbewegung) ODER deutlicher Weg → schließen.
        if (velocity > 0.5 || this.dragDy > 120) {
            this.close();
        }
        else if (pane) {
            pane.style.transform = '';
        }
    }
    close() {
        this.open = false;
        const pane = this.pane?.nativeElement;
        if (pane)
            pane.style.transform = '';
        this.restoreFocus();
        this.unlockScroll();
        this.closed.emit();
    }
    lockScroll() {
        if (this.prevBodyOverflow !== null)
            return;
        this.prevBodyOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
    }
    unlockScroll() {
        if (this.prevBodyOverflow === null)
            return;
        document.body.style.overflow = this.prevBodyOverflow;
        this.prevBodyOverflow = null;
    }
    /** Vorherigen Fokus merken und Fokus in den Dialog setzen (nach Render). */
    captureAndFocus() {
        this.previouslyFocused = document.activeElement ?? null;
        queueMicrotask(() => {
            const pane = this.pane?.nativeElement;
            if (!pane)
                return;
            const focusables = this.focusable(pane);
            (focusables[0] ?? pane).focus();
        });
    }
    restoreFocus() {
        const target = this.previouslyFocused;
        this.previouslyFocused = null;
        if (target && typeof target.focus === 'function')
            target.focus();
    }
    focusable(root) {
        const selector = [
            'a[href]',
            'button:not([disabled])',
            'input:not([disabled])',
            'select:not([disabled])',
            'textarea:not([disabled])',
            '[tabindex]:not([tabindex="-1"])',
        ].join(',');
        return Array.from(root.querySelectorAll(selector));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: DialogComponent, isStandalone: true, selector: "app-dialog", inputs: { open: "open", title: "title", closeLabel: "closeLabel", size: "size" }, outputs: { closed: "closed" }, host: { listeners: { "document:keydown.escape": "onEscape()", "document:keydown": "onKeydown($event)" } }, viewQueries: [{ propertyName: "pane", first: true, predicate: ["pane"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "@if (open) {\n  <div class=\"dialog__backdrop\" (click)=\"onBackdrop($event)\">\n    <div\n      #pane\n      class=\"dialog\"\n      [class.dialog--lg]=\"size === 'lg'\"\n      role=\"dialog\"\n      aria-modal=\"true\"\n      tabindex=\"-1\"\n      [attr.aria-labelledby]=\"titleId\"\n      (click)=\"$event.stopPropagation()\"\n    >\n      <!-- Mobile-Sheet: Greifleiste + Header sind die Drag-Zone zum\n           Herunterwischen (Flick schlie\u00DFt). Auf Desktop ausgeblendet (#14). -->\n      <div\n        class=\"dialog__drag\"\n        (touchstart)=\"onDragStart($event)\"\n        (touchmove)=\"onDragMove($event)\"\n        (touchend)=\"onDragEnd($event)\"\n      >\n        <span class=\"dialog__grabber\" aria-hidden=\"true\"></span>\n        <header class=\"dialog__header\">\n          <h2 class=\"text-xl\" [id]=\"titleId\">{{ title }}</h2>\n          <button\n            type=\"button\"\n            class=\"dialog__close\"\n            [attr.aria-label]=\"closeLabel\"\n            (click)=\"close()\"\n          >\n            \u2715\n          </button>\n        </header>\n      </div>\n      <div class=\"dialog__body\"><ng-content /></div>\n      <footer class=\"dialog__footer\"><ng-content select=\"[dialog-footer]\" /></footer>\n    </div>\n  </div>\n}\n", styles: ["@charset \"UTF-8\";.dialog__backdrop{position:fixed;inset:0;z-index:var(--z-dialog);display:flex;align-items:center;justify-content:center;padding:var(--space-5);background:#00120a8c}.dialog{width:100%;max-width:32rem;background:var(--color-bg-elevated);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);display:flex;flex-direction:column;max-height:85dvh}.dialog--lg{max-width:44rem}.dialog__grabber{display:none}.dialog__header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);padding:var(--space-5) var(--space-5) var(--space-3)}.dialog__close{background:transparent;border:0;cursor:pointer;font-size:var(--fs-lg);color:var(--color-text-muted);border-radius:var(--radius-sm);padding:var(--space-1)}.dialog__body{padding:var(--space-4) var(--space-5);overflow-y:auto;--fade: linear-gradient( to bottom, transparent, #000 var(--space-4), #000 calc(100% - var(--space-4)), transparent );-webkit-mask-image:var(--fade);mask-image:var(--fade)}.dialog__footer{display:flex;justify-content:flex-end;gap:var(--space-3);padding:var(--space-5)}.dialog__footer:empty{display:none}@media(max-width:768px){.dialog__backdrop{align-items:flex-end;padding:0}.dialog{max-width:none;max-height:92dvh;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border-bottom:0;padding-bottom:env(safe-area-inset-bottom,0px);transition:transform .22s var(--ease-standard)}.dialog__drag{touch-action:none}.dialog__grabber{display:block;width:2.25rem;height:.25rem;margin:var(--space-2) auto 0;border-radius:999px;background:var(--color-border-strong)}.dialog__header{padding:var(--space-2) var(--space-4)}.dialog__body{padding:var(--space-4) var(--space-4)}.dialog__footer{padding:var(--space-4);flex-wrap:wrap}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-dialog', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (open) {\n  <div class=\"dialog__backdrop\" (click)=\"onBackdrop($event)\">\n    <div\n      #pane\n      class=\"dialog\"\n      [class.dialog--lg]=\"size === 'lg'\"\n      role=\"dialog\"\n      aria-modal=\"true\"\n      tabindex=\"-1\"\n      [attr.aria-labelledby]=\"titleId\"\n      (click)=\"$event.stopPropagation()\"\n    >\n      <!-- Mobile-Sheet: Greifleiste + Header sind die Drag-Zone zum\n           Herunterwischen (Flick schlie\u00DFt). Auf Desktop ausgeblendet (#14). -->\n      <div\n        class=\"dialog__drag\"\n        (touchstart)=\"onDragStart($event)\"\n        (touchmove)=\"onDragMove($event)\"\n        (touchend)=\"onDragEnd($event)\"\n      >\n        <span class=\"dialog__grabber\" aria-hidden=\"true\"></span>\n        <header class=\"dialog__header\">\n          <h2 class=\"text-xl\" [id]=\"titleId\">{{ title }}</h2>\n          <button\n            type=\"button\"\n            class=\"dialog__close\"\n            [attr.aria-label]=\"closeLabel\"\n            (click)=\"close()\"\n          >\n            \u2715\n          </button>\n        </header>\n      </div>\n      <div class=\"dialog__body\"><ng-content /></div>\n      <footer class=\"dialog__footer\"><ng-content select=\"[dialog-footer]\" /></footer>\n    </div>\n  </div>\n}\n", styles: ["@charset \"UTF-8\";.dialog__backdrop{position:fixed;inset:0;z-index:var(--z-dialog);display:flex;align-items:center;justify-content:center;padding:var(--space-5);background:#00120a8c}.dialog{width:100%;max-width:32rem;background:var(--color-bg-elevated);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);display:flex;flex-direction:column;max-height:85dvh}.dialog--lg{max-width:44rem}.dialog__grabber{display:none}.dialog__header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);padding:var(--space-5) var(--space-5) var(--space-3)}.dialog__close{background:transparent;border:0;cursor:pointer;font-size:var(--fs-lg);color:var(--color-text-muted);border-radius:var(--radius-sm);padding:var(--space-1)}.dialog__body{padding:var(--space-4) var(--space-5);overflow-y:auto;--fade: linear-gradient( to bottom, transparent, #000 var(--space-4), #000 calc(100% - var(--space-4)), transparent );-webkit-mask-image:var(--fade);mask-image:var(--fade)}.dialog__footer{display:flex;justify-content:flex-end;gap:var(--space-3);padding:var(--space-5)}.dialog__footer:empty{display:none}@media(max-width:768px){.dialog__backdrop{align-items:flex-end;padding:0}.dialog{max-width:none;max-height:92dvh;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border-bottom:0;padding-bottom:env(safe-area-inset-bottom,0px);transition:transform .22s var(--ease-standard)}.dialog__drag{touch-action:none}.dialog__grabber{display:block;width:2.25rem;height:.25rem;margin:var(--space-2) auto 0;border-radius:999px;background:var(--color-border-strong)}.dialog__header{padding:var(--space-2) var(--space-4)}.dialog__body{padding:var(--space-4) var(--space-4)}.dialog__footer{padding:var(--space-4);flex-wrap:wrap}}\n"] }]
        }], propDecorators: { open: [{
                type: Input
            }], title: [{
                type: Input
            }], closeLabel: [{
                type: Input
            }], size: [{
                type: Input
            }], closed: [{
                type: Output
            }], pane: [{
                type: ViewChild,
                args: ['pane']
            }], onEscape: [{
                type: HostListener,
                args: ['document:keydown.escape']
            }], onKeydown: [{
                type: HostListener,
                args: ['document:keydown', ['$event']]
            }] } });

/** Schlanke, datengetriebene Tabelle. Für komplexe Fälle später erweiterbar. */
class TableComponent {
    constructor() {
        this.columns = [];
        this.rows = [];
        this.caption = '';
        this.emptyText = 'Keine Einträge';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: TableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: TableComponent, isStandalone: true, selector: "app-table", inputs: { columns: "columns", rows: "rows", caption: "caption", emptyText: "emptyText" }, ngImport: i0, template: "<table class=\"tbl\">\n  @if (caption) {\n    <caption class=\"text-start pb-3 text-muted\">{{ caption }}</caption>\n  }\n  <thead>\n    <tr>\n      @for (col of columns; track col.key) {\n        <th scope=\"col\" [style.text-align]=\"col.align ?? 'start'\">{{ col.label }}</th>\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of rows; track $index) {\n      <tr>\n        @for (col of columns; track col.key) {\n          <td [style.text-align]=\"col.align ?? 'start'\">{{ row[col.key] }}</td>\n        }\n      </tr>\n    } @empty {\n      <tr>\n        <td class=\"text-center text-muted p-6\" [attr.colspan]=\"columns.length\">{{ emptyText }}</td>\n      </tr>\n    }\n  </tbody>\n</table>\n", styles: [".tbl{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}th,td{padding:var(--space-3) var(--space-4);border-bottom:var(--border-width) solid var(--color-border)}th{font-weight:var(--fw-semibold);color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.04em;font-size:var(--fs-xs)}tbody tr:hover{background:var(--color-surface-sunken)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: TableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-table', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<table class=\"tbl\">\n  @if (caption) {\n    <caption class=\"text-start pb-3 text-muted\">{{ caption }}</caption>\n  }\n  <thead>\n    <tr>\n      @for (col of columns; track col.key) {\n        <th scope=\"col\" [style.text-align]=\"col.align ?? 'start'\">{{ col.label }}</th>\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of rows; track $index) {\n      <tr>\n        @for (col of columns; track col.key) {\n          <td [style.text-align]=\"col.align ?? 'start'\">{{ row[col.key] }}</td>\n        }\n      </tr>\n    } @empty {\n      <tr>\n        <td class=\"text-center text-muted p-6\" [attr.colspan]=\"columns.length\">{{ emptyText }}</td>\n      </tr>\n    }\n  </tbody>\n</table>\n", styles: [".tbl{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}th,td{padding:var(--space-3) var(--space-4);border-bottom:var(--border-width) solid var(--color-border)}th{font-weight:var(--fw-semibold);color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.04em;font-size:var(--fs-xs)}tbody tr:hover{background:var(--color-surface-sunken)}\n"] }]
        }], propDecorators: { columns: [{
                type: Input
            }], rows: [{
                type: Input
            }], caption: [{
                type: Input
            }], emptyText: [{
                type: Input
            }] } });

/**
 * Markiert ein `<ng-template>` als Zell-Renderer einer Spalte der
 * {@link DataTableComponent}: `<ng-template appCell="status" let-row>…`.
 * Der `let-row`-Kontext ist die jeweilige Zeile.
 */
class CellDirective {
    constructor() {
        /** Spalten-Key, für den dieses Template gerendert wird. */
        this.key = '';
        this.tpl = inject(TemplateRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CellDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.25", type: CellDirective, isStandalone: true, selector: "[appCell]", inputs: { key: ["appCell", "key"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CellDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[appCell]', standalone: true }]
        }], propDecorators: { key: [{
                type: Input,
                args: ['appCell']
            }] } });

/**
 * Markiert ein `<ng-template>` als ausklappbare Detail-Zeile der
 * {@link DataTableComponent}: `<ng-template appRowDetail let-row>…`. Wird je
 * Zeile gerendert, für die `isExpanded(row)` true ist (volle Breite darunter).
 */
class RowDetailDirective {
    constructor() {
        this.tpl = inject(TemplateRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: RowDetailDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.25", type: RowDetailDirective, isStandalone: true, selector: "[appRowDetail]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: RowDetailDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[appRowDetail]', standalone: true }]
        }] });

/**
 * Geteilte, datengetriebene Tabelle (#26). Spalten kommen als {@link ColumnDef}-
 * Liste; einzelne Zellen lassen sich per `<ng-template appCell="key" let-row>`
 * frei rendern (Badges/Buttons/Links). Ohne Template wird `row[key]` als Text
 * gezeigt. Optional als Box (Standard) und mit Zeilen-Klick.
 *
 * So bleiben alle Admin-Tabellen visuell konsistent (eine Quelle für Kopf/Rahmen/
 * Hover/Empty-State), statt jede Seite ihr eigenes `<table>` zu bauen.
 */
class DataTableComponent {
    constructor() {
        this.columns = [];
        this.rows = [];
        this.emptyText = '—';
        this.boxed = true;
        /** Macht Zeilen klickbar (Cursor/Tab/Enter) + emittiert `rowClick`. */
        this.clickable = false;
        this.rowClick = new EventEmitter();
        this.cellMap = signal(new Map(), ...(ngDevMode ? [{ debugName: "cellMap" }] : []));
    }
    ngAfterContentInit() {
        const build = () => this.cellMap.set(new Map(this.cellDirs.map((c) => [c.key, c.tpl])));
        build();
        this.cellDirs.changes.subscribe(build);
    }
    cellFor(key) {
        return this.cellMap().get(key) ?? null;
    }
    text(row, key) {
        return row[key];
    }
    trackRow(row, index) {
        return this.rowKey ? this.rowKey(row, index) : index;
    }
    onRow(row) {
        if (this.clickable)
            this.rowClick.emit(row);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DataTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: DataTableComponent, isStandalone: true, selector: "app-data-table", inputs: { columns: "columns", rows: "rows", emptyText: "emptyText", boxed: "boxed", rowKey: "rowKey", clickable: "clickable", isExpanded: "isExpanded" }, outputs: { rowClick: "rowClick" }, queries: [{ propertyName: "rowDetail", first: true, predicate: RowDetailDirective, descendants: true }, { propertyName: "cellDirs", predicate: CellDirective }], ngImport: i0, template: "<div class=\"dt\" [class.dt--boxed]=\"boxed && rows.length > 0\">\n  @if (rows.length > 0) {\n  <table class=\"dt__table\">\n    <thead>\n      <tr>\n        @for (col of columns; track col.key) {\n          <th scope=\"col\" [style.text-align]=\"col.align ?? 'start'\" [style.width]=\"col.width || null\">{{ col.label }}</th>\n        }\n      </tr>\n    </thead>\n    <tbody>\n      @for (row of rows; track trackRow(row, $index); let i = $index) {\n        <tr [class.dt__row--clickable]=\"clickable\" (click)=\"onRow(row)\" [attr.tabindex]=\"clickable ? 0 : null\" (keydown.enter)=\"onRow(row)\">\n          @for (col of columns; track col.key) {\n            <td [style.text-align]=\"col.align ?? 'start'\" [attr.data-label]=\"col.label\">\n              @if (cellFor(col.key); as tpl) {\n                <ng-container [ngTemplateOutlet]=\"tpl\" [ngTemplateOutletContext]=\"{ $implicit: row, index: i }\" />\n              } @else {\n                {{ text(row, col.key) }}\n              }\n            </td>\n          }\n        </tr>\n        @if (rowDetail && isExpanded && isExpanded(row)) {\n          <tr class=\"dt__detail-row\">\n            <td [attr.colspan]=\"columns.length\">\n              <ng-container [ngTemplateOutlet]=\"rowDetail.tpl\" [ngTemplateOutletContext]=\"{ $implicit: row }\" />\n            </td>\n          </tr>\n        }\n      }\n    </tbody>\n  </table>\n  } @else {\n    <div class=\"empty-state\">{{ emptyText }}</div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";.dt--boxed{margin-top:var(--space-2);background:var(--color-surface);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden}.dt__table{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}.dt__table th{text-align:start;padding:var(--space-3) var(--space-4);font-size:var(--fs-xs);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:.04em;color:var(--color-text-muted);background:var(--color-surface-sunken);border-bottom:var(--border-width) solid var(--color-border)}.dt__table tbody tr{height:3rem}.dt__table td{padding:0 var(--space-4);border-bottom:var(--border-width) solid var(--color-border);vertical-align:middle}.dt__row--clickable{cursor:pointer}.dt__table tbody tr:hover td,.dt__row--clickable:focus-visible td,.dt__row--clickable:active td{background:var(--color-surface-sunken)}.dt__detail-row>td{padding:0;background:var(--color-surface-sunken)}.dt__empty{text-align:center;color:var(--color-text-muted);padding:var(--space-6)!important}@media(max-width:768px){.dt__table,.dt__table tbody{display:block;width:100%}.dt__table thead{display:none}.dt__table tbody tr{display:block;height:auto;padding:var(--space-3) var(--space-4);border-bottom:var(--border-width) solid var(--color-border)}.dt__table tbody tr:last-child{border-bottom:0}.dt__table td{display:flex;align-items:baseline;justify-content:space-between;gap:var(--space-4);padding:var(--space-1) 0;border-bottom:0;text-align:end!important}.dt__table td[data-label]:before{content:attr(data-label);flex:none;font-size:var(--fs-xs);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:.04em;color:var(--color-text-muted)}.dt__table td[data-label=\"\"]:before{content:none}.dt__table td:first-child{flex-direction:column;align-items:flex-start;gap:var(--space-1);text-align:start!important}.dt__detail-row,.dt__detail-row>td,.dt__empty{display:block}.dt__detail-row,.dt__detail-row>td{text-align:start!important}.dt__empty{text-align:center!important}.dt__table tbody tr:hover,.dt__row--clickable:focus-visible,.dt__row--clickable:active{background:var(--color-surface-sunken)}.dt__table tbody tr:hover td,.dt__row--clickable:focus-visible td,.dt__row--clickable:active td{background:transparent}.dt__detail-row{padding:0}}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DataTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-data-table', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet], template: "<div class=\"dt\" [class.dt--boxed]=\"boxed && rows.length > 0\">\n  @if (rows.length > 0) {\n  <table class=\"dt__table\">\n    <thead>\n      <tr>\n        @for (col of columns; track col.key) {\n          <th scope=\"col\" [style.text-align]=\"col.align ?? 'start'\" [style.width]=\"col.width || null\">{{ col.label }}</th>\n        }\n      </tr>\n    </thead>\n    <tbody>\n      @for (row of rows; track trackRow(row, $index); let i = $index) {\n        <tr [class.dt__row--clickable]=\"clickable\" (click)=\"onRow(row)\" [attr.tabindex]=\"clickable ? 0 : null\" (keydown.enter)=\"onRow(row)\">\n          @for (col of columns; track col.key) {\n            <td [style.text-align]=\"col.align ?? 'start'\" [attr.data-label]=\"col.label\">\n              @if (cellFor(col.key); as tpl) {\n                <ng-container [ngTemplateOutlet]=\"tpl\" [ngTemplateOutletContext]=\"{ $implicit: row, index: i }\" />\n              } @else {\n                {{ text(row, col.key) }}\n              }\n            </td>\n          }\n        </tr>\n        @if (rowDetail && isExpanded && isExpanded(row)) {\n          <tr class=\"dt__detail-row\">\n            <td [attr.colspan]=\"columns.length\">\n              <ng-container [ngTemplateOutlet]=\"rowDetail.tpl\" [ngTemplateOutletContext]=\"{ $implicit: row }\" />\n            </td>\n          </tr>\n        }\n      }\n    </tbody>\n  </table>\n  } @else {\n    <div class=\"empty-state\">{{ emptyText }}</div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";.dt--boxed{margin-top:var(--space-2);background:var(--color-surface);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden}.dt__table{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}.dt__table th{text-align:start;padding:var(--space-3) var(--space-4);font-size:var(--fs-xs);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:.04em;color:var(--color-text-muted);background:var(--color-surface-sunken);border-bottom:var(--border-width) solid var(--color-border)}.dt__table tbody tr{height:3rem}.dt__table td{padding:0 var(--space-4);border-bottom:var(--border-width) solid var(--color-border);vertical-align:middle}.dt__row--clickable{cursor:pointer}.dt__table tbody tr:hover td,.dt__row--clickable:focus-visible td,.dt__row--clickable:active td{background:var(--color-surface-sunken)}.dt__detail-row>td{padding:0;background:var(--color-surface-sunken)}.dt__empty{text-align:center;color:var(--color-text-muted);padding:var(--space-6)!important}@media(max-width:768px){.dt__table,.dt__table tbody{display:block;width:100%}.dt__table thead{display:none}.dt__table tbody tr{display:block;height:auto;padding:var(--space-3) var(--space-4);border-bottom:var(--border-width) solid var(--color-border)}.dt__table tbody tr:last-child{border-bottom:0}.dt__table td{display:flex;align-items:baseline;justify-content:space-between;gap:var(--space-4);padding:var(--space-1) 0;border-bottom:0;text-align:end!important}.dt__table td[data-label]:before{content:attr(data-label);flex:none;font-size:var(--fs-xs);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:.04em;color:var(--color-text-muted)}.dt__table td[data-label=\"\"]:before{content:none}.dt__table td:first-child{flex-direction:column;align-items:flex-start;gap:var(--space-1);text-align:start!important}.dt__detail-row,.dt__detail-row>td,.dt__empty{display:block}.dt__detail-row,.dt__detail-row>td{text-align:start!important}.dt__empty{text-align:center!important}.dt__table tbody tr:hover,.dt__row--clickable:focus-visible,.dt__row--clickable:active{background:var(--color-surface-sunken)}.dt__table tbody tr:hover td,.dt__row--clickable:focus-visible td,.dt__row--clickable:active td{background:transparent}.dt__detail-row{padding:0}}\n"] }]
        }], propDecorators: { columns: [{
                type: Input
            }], rows: [{
                type: Input
            }], emptyText: [{
                type: Input
            }], boxed: [{
                type: Input
            }], rowKey: [{
                type: Input
            }], clickable: [{
                type: Input
            }], rowClick: [{
                type: Output
            }], isExpanded: [{
                type: Input
            }], cellDirs: [{
                type: ContentChildren,
                args: [CellDirective]
            }], rowDetail: [{
                type: ContentChild,
                args: [RowDetailDirective]
            }] } });

/**
 * Einheitliches Währungs-Eingabefeld (#currency). Überall gleiche Optik:
 * rechtsbündig, Tausender-Gruppierung + 2 Nachkommastellen, „€"-Suffix.
 *
 * `ControlValueAccessor` → per `[(ngModel)]` nutzbar. Das **Modell** ist stets ein
 * kanonischer Dezimal-String mit Punkt (`"1234.56"`, parsebar fürs Backend) bzw.
 * `''` für leer. Die **Anzeige** ist lokalisiert (de `1.234,56`, en `1,234.56`):
 * beim Fokus editierbar (ohne Gruppierung), beim Verlassen formatiert.
 */
class CurrencyInputComponent {
    constructor() {
        this.intl = inject(UI_KIT_INTL);
        this.placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
        this.ariaLabel = input('', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
        this.name = input('', ...(ngDevMode ? [{ debugName: "name" }] : []));
        /** Optionales Feld-Label; gesetzt → volle Feld-Optik (Label/Hint/Error),
         *  leer → blankes Control (für eigene Label-Wrapper, z. B. Filter/Dialoge). */
        this.label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
        this.hint = input('', ...(ngDevMode ? [{ debugName: "hint" }] : []));
        this.error = input('', ...(ngDevMode ? [{ debugName: "error" }] : []));
        this.required = input(false, ...(ngDevMode ? [{ debugName: "required" }] : []));
        /** Sichtbarer Text (formatiert oder beim Tippen roh). */
        this.text = signal('', ...(ngDevMode ? [{ debugName: "text" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        /** Kanonischer Wert (Punkt-Dezimal, ohne Gruppierung) — das Modell. */
        this.canonical = '';
        this.focused = false;
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    // --- ControlValueAccessor ---------------------------------------------------
    writeValue(value) {
        this.canonical = this.toCanonical(value == null ? '' : String(value));
        this.text.set(this.focused ? this.toEditable(this.canonical) : this.format(this.canonical));
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    // --- Interaktion ------------------------------------------------------------
    onFocus() {
        this.focused = true;
        this.text.set(this.toEditable(this.canonical));
    }
    onInput(raw) {
        this.text.set(raw); // roh stehen lassen (kein Cursor-Springen)
        this.canonical = this.parse(raw);
        this.onChange(this.canonical);
    }
    onBlur() {
        this.focused = false;
        this.text.set(this.format(this.canonical));
        this.onTouched();
    }
    // --- Parsen / Formatieren ---------------------------------------------------
    get decimalSep() {
        return this.intl.lang() === 'en' ? '.' : ',';
    }
    /** Roh-Eingabe → kanonischer Punkt-Dezimal-String (oder ''). */
    parse(raw) {
        const trimmed = (raw ?? '').trim();
        if (!trimmed)
            return '';
        // Alles außer Ziffern und Separatoren entfernen; letzter Separator = Dezimaltrenner.
        let s = trimmed.replace(/[^\d.,-]/g, '');
        const neg = s.startsWith('-');
        s = s.replace(/-/g, '');
        const lastSep = Math.max(s.lastIndexOf(','), s.lastIndexOf('.'));
        let intPart;
        let fracPart;
        if (lastSep === -1) {
            intPart = s;
            fracPart = '';
        }
        else {
            intPart = s.slice(0, lastSep).replace(/[.,]/g, '');
            fracPart = s.slice(lastSep + 1).replace(/[.,]/g, '');
        }
        intPart = intPart.replace(/^0+(?=\d)/, '');
        if (!intPart && !fracPart)
            return '';
        const canonical = fracPart ? `${intPart || '0'}.${fracPart}` : intPart || '0';
        return neg ? `-${canonical}` : canonical;
    }
    /** Beliebigen Wert (Backend-Punkt oder lokal) → kanonisch. */
    toCanonical(value) {
        return this.parse(value);
    }
    /** Kanonisch → editierbarer Text (lokaler Dezimaltrenner, keine Gruppierung). */
    toEditable(canonical) {
        if (!canonical)
            return '';
        return this.decimalSep === ',' ? canonical.replace('.', ',') : canonical;
    }
    /** Kanonisch → lokalisiert formatiert (1.234,56) mit 2 Nachkommastellen. */
    format(canonical) {
        if (!canonical)
            return '';
        const n = Number(canonical);
        if (Number.isNaN(n))
            return '';
        const locale = this.intl.lang() === 'en' ? 'en-US' : 'de-DE';
        return new Intl.NumberFormat(locale, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        }).format(n);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CurrencyInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: CurrencyInputComponent, isStandalone: true, selector: "app-currency-input", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            { provide: NG_VALUE_ACCESSOR, useExisting: CurrencyInputComponent, multi: true },
        ], ngImport: i0, template: "<div class=\"flex flex-col gap-1\">\n  @if (label()) {\n    <label class=\"text-sm font-medium text-muted\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"text-danger ms-[2px]\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <span class=\"cur\" [class.cur--disabled]=\"disabled()\">\n    <input\n      class=\"cur__input\"\n      type=\"text\"\n      inputmode=\"decimal\"\n      [value]=\"text()\"\n      [disabled]=\"disabled()\"\n      [attr.placeholder]=\"placeholder()\"\n      [attr.aria-label]=\"ariaLabel() || label() || null\"\n      [attr.aria-invalid]=\"error() ? 'true' : null\"\n      [attr.name]=\"name() || null\"\n      (focus)=\"onFocus()\"\n      (input)=\"onInput($any($event.target).value)\"\n      (blur)=\"onBlur()\"\n    />\n    <span class=\"cur__symbol\" aria-hidden=\"true\">\u20AC</span>\n  </span>\n  @if (hint() && !error()) {\n    <p class=\"text-xs text-muted m-0\">{{ hint() }}</p>\n  }\n  @if (error()) {\n    <p class=\"text-xs text-danger m-0\" role=\"alert\">{{ error() }}</p>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.cur{display:inline-flex;align-items:center;gap:var(--space-1);width:100%;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg, var(--color-surface));border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md)}.cur:focus-within{outline:2px solid var(--color-primary);outline-offset:1px}.cur--disabled{opacity:.6}.cur__input{flex:1 1 auto;min-width:0;height:100%;border:0;background:transparent;color:var(--color-text);font:inherit;font-variant-numeric:tabular-nums;text-align:end;padding:0}.cur__input:focus{outline:none}.cur__symbol{flex:0 0 auto;color:var(--color-text-muted)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CurrencyInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-currency-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        { provide: NG_VALUE_ACCESSOR, useExisting: CurrencyInputComponent, multi: true },
                    ], template: "<div class=\"flex flex-col gap-1\">\n  @if (label()) {\n    <label class=\"text-sm font-medium text-muted\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"text-danger ms-[2px]\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <span class=\"cur\" [class.cur--disabled]=\"disabled()\">\n    <input\n      class=\"cur__input\"\n      type=\"text\"\n      inputmode=\"decimal\"\n      [value]=\"text()\"\n      [disabled]=\"disabled()\"\n      [attr.placeholder]=\"placeholder()\"\n      [attr.aria-label]=\"ariaLabel() || label() || null\"\n      [attr.aria-invalid]=\"error() ? 'true' : null\"\n      [attr.name]=\"name() || null\"\n      (focus)=\"onFocus()\"\n      (input)=\"onInput($any($event.target).value)\"\n      (blur)=\"onBlur()\"\n    />\n    <span class=\"cur__symbol\" aria-hidden=\"true\">\u20AC</span>\n  </span>\n  @if (hint() && !error()) {\n    <p class=\"text-xs text-muted m-0\">{{ hint() }}</p>\n  }\n  @if (error()) {\n    <p class=\"text-xs text-danger m-0\" role=\"alert\">{{ error() }}</p>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.cur{display:inline-flex;align-items:center;gap:var(--space-1);width:100%;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg, var(--color-surface));border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md)}.cur:focus-within{outline:2px solid var(--color-primary);outline-offset:1px}.cur--disabled{opacity:.6}.cur__input{flex:1 1 auto;min-width:0;height:100%;border:0;background:transparent;color:var(--color-text);font:inherit;font-variant-numeric:tabular-nums;text-align:end;padding:0}.cur__input:focus{outline:none}.cur__symbol{flex:0 0 auto;color:var(--color-text-muted)}\n"] }]
        }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }] } });

/**
 * Globaler Ladebildschirm: halbtransparenter Overlay über dem Inhaltsbereich
 * (unterhalb des Headers) mit zentriertem Spinner, gesteuert über den
 * {@link UI_KIT_LOADING}-Token (vom Host an seinen Lade-Service gebunden).
 * Header/Navigation bleiben bedienbar. Liegt unter Dialogen/Toasts (z-index),
 * damit diese darüber sichtbar bleiben.
 */
class LoadingOverlayComponent {
    constructor() {
        this.loading = inject(UI_KIT_LOADING);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: LoadingOverlayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: LoadingOverlayComponent, isStandalone: true, selector: "app-loading-overlay", ngImport: i0, template: "@if (loading.visible()) {\n  <div class=\"lo\" role=\"status\" aria-live=\"polite\">\n    <div class=\"flex flex-col items-center gap-3 py-5 px-6 rounded-lg bg-surface border border-solid border-line shadow-lg\">\n      <span class=\"lo__spinner\" aria-hidden=\"true\"></span>\n      <span class=\"text-sm text-muted\">{{ 'loading' | uiKitT }}</span>\n    </div>\n  </div>\n}\n", styles: [".lo{position:fixed;top:var(--layout-header-height);inset-inline:0;bottom:0;z-index:1100;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--color-bg, #000) 55%,transparent);-webkit-backdrop-filter:blur(1px);backdrop-filter:blur(1px);animation:lo-fade .12s ease-out}.lo__spinner{width:2.25rem;height:2.25rem;border-radius:999px;border:3px solid var(--color-border-strong, currentColor);border-top-color:var(--color-primary);animation:lo-spin .7s linear infinite}@keyframes lo-spin{to{transform:rotate(360deg)}}@keyframes lo-fade{0%{opacity:0}}@media(prefers-reduced-motion:reduce){.lo{animation:none}.lo__spinner{animation-duration:1.5s}}\n"], dependencies: [{ kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: LoadingOverlayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-loading-overlay', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe], template: "@if (loading.visible()) {\n  <div class=\"lo\" role=\"status\" aria-live=\"polite\">\n    <div class=\"flex flex-col items-center gap-3 py-5 px-6 rounded-lg bg-surface border border-solid border-line shadow-lg\">\n      <span class=\"lo__spinner\" aria-hidden=\"true\"></span>\n      <span class=\"text-sm text-muted\">{{ 'loading' | uiKitT }}</span>\n    </div>\n  </div>\n}\n", styles: [".lo{position:fixed;top:var(--layout-header-height);inset-inline:0;bottom:0;z-index:1100;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--color-bg, #000) 55%,transparent);-webkit-backdrop-filter:blur(1px);backdrop-filter:blur(1px);animation:lo-fade .12s ease-out}.lo__spinner{width:2.25rem;height:2.25rem;border-radius:999px;border:3px solid var(--color-border-strong, currentColor);border-top-color:var(--color-primary);animation:lo-spin .7s linear infinite}@keyframes lo-spin{to{transform:rotate(360deg)}}@keyframes lo-fade{0%{opacity:0}}@media(prefers-reduced-motion:reduce){.lo{animation:none}.lo__spinner{animation-duration:1.5s}}\n"] }]
        }] });

/**
 * Einheitlicher Filter-Balken für Listen (#filters). Ein sekundärer Button
 * (Trichter-Icon + Label + Aktiv-Zähler) öffnet ein rechtsbündiges Popover; die
 * eigentlichen Filter-Felder werden projiziert (`<app-filter-field>` /
 * `<app-filter-range>`). Schließt bei Klick außerhalb und Escape.
 *
 * Zwei Modi:
 * - **Apply** (Default): Popover zeigt „Anwenden" + „Zurücksetzen"; der Konsument
 *   übernimmt die Werte erst bei `(apply)`.
 * - **Live** (`[live]="true"`): keine Anwenden-Taste — Felder wirken sofort (der
 *   Konsument bindet direkt). Nur „Zurücksetzen" erscheint bei aktiven Filtern.
 */
class FilterBarComponent {
    constructor() {
        this.host = inject((ElementRef));
        /** Anzahl aktiver Filter (Badge); 0 blendet den Zähler aus. */
        this.activeCount = input(0, ...(ngDevMode ? [{ debugName: "activeCount" }] : []));
        /** Button-Label; leer = i18n-Default „Filter". */
        this.label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
        /** Live-Modus: keine „Anwenden"-Taste (Felder wirken sofort). */
        this.live = input(false, ...(ngDevMode ? [{ debugName: "live" }] : []));
        this.applyLabel = input('', ...(ngDevMode ? [{ debugName: "applyLabel" }] : []));
        this.resetLabel = input('', ...(ngDevMode ? [{ debugName: "resetLabel" }] : []));
        /** „Anwenden" geklickt (Apply-Modus). Schließt das Popover. */
        this.apply = output();
        /** „Zurücksetzen" geklickt. */
        this.reset = output();
        /** Offen-Zustand geändert (z. B. zum Re-Fokus). */
        this.openChange = output();
        this.open = signal(false, ...(ngDevMode ? [{ debugName: "open" }] : []));
        /** True, wenn das Popover geöffnet ist (für Konsumenten via Template-Ref). */
        this.isOpen = computed(() => this.open(), ...(ngDevMode ? [{ debugName: "isOpen" }] : []));
    }
    toggle() {
        this.setOpen(!this.open());
    }
    close() {
        if (this.open())
            this.setOpen(false);
    }
    emitApply() {
        this.apply.emit();
        this.setOpen(false);
    }
    emitReset() {
        this.reset.emit();
    }
    setOpen(value) {
        this.open.set(value);
        this.openChange.emit(value);
    }
    onDocumentClick(event) {
        if (!this.open())
            return;
        if (!this.host.nativeElement.contains(event.target))
            this.setOpen(false);
    }
    onEscape() {
        this.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: FilterBarComponent, isStandalone: true, selector: "app-filter-bar", inputs: { activeCount: { classPropertyName: "activeCount", publicName: "activeCount", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, live: { classPropertyName: "live", publicName: "live", isSignal: true, isRequired: false, transformFunction: null }, applyLabel: { classPropertyName: "applyLabel", publicName: "applyLabel", isSignal: true, isRequired: false, transformFunction: null }, resetLabel: { classPropertyName: "resetLabel", publicName: "resetLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { apply: "apply", reset: "reset", openChange: "openChange" }, host: { listeners: { "document:click": "onDocumentClick($event)", "document:keydown.escape": "onEscape()" } }, ngImport: i0, template: "<div class=\"relative\">\n  <app-button\n    variant=\"secondary\"\n    size=\"sm\"\n    [attr.aria-expanded]=\"open()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"inline-flex items-center gap-2\">\n      <app-icon name=\"filter\" [size]=\"16\" />\n      {{ label() || ('filter.button' | uiKitT) }}\n      @if (activeCount() > 0) {\n        <span class=\"filter__count\" aria-hidden=\"true\">{{ activeCount() }}</span>\n      }\n    </span>\n  </app-button>\n\n  @if (open()) {\n    <div class=\"filter__panel\" role=\"dialog\" [attr.aria-label]=\"label() || ('filter.button' | uiKitT)\">\n      <div class=\"flex flex-col gap-4\">\n        <ng-content />\n      </div>\n      <div class=\"filter__actions\">\n        @if (!live()) {\n          <app-button size=\"sm\" (click)=\"emitApply()\">\n            {{ applyLabel() || ('filter.apply' | uiKitT) }}\n          </app-button>\n        }\n        @if (live() ? activeCount() > 0 : true) {\n          <app-button variant=\"ghost\" size=\"sm\" (click)=\"emitReset()\">\n            {{ resetLabel() || ('filter.reset' | uiKitT) }}\n          </app-button>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";.filter__count{display:inline-flex;align-items:center;justify-content:center;min-width:1.25rem;height:1.25rem;padding:0 var(--space-1);margin-left:var(--space-1);border-radius:999px;background:var(--color-primary);color:var(--color-on-primary, #fff);font-size:var(--fs-xs);font-weight:var(--fw-bold)}.filter__panel{position:absolute;right:0;z-index:var(--z-dropdown, 50);margin-top:var(--space-2);width:min(22rem,90vw);max-height:80vh;overflow-y:auto;display:flex;flex-direction:column;gap:var(--space-4);padding:var(--space-4);background:var(--color-bg-elevated, var(--color-surface));border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg)}.filter__actions{display:flex;gap:var(--space-2)}@media(max-width:768px){.filter__panel{position:fixed;inset:auto 0 0;margin-top:0;width:auto;max-height:80dvh;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border-bottom:0;z-index:var(--z-dialog)}.filter__actions app-button{flex:1 1 auto;display:flex}}\n"], dependencies: [{ kind: "component", type: ButtonComponent, selector: "app-button", inputs: ["variant", "color", "size", "type", "disabled", "loading", "iconOnly", "block", "ariaLabel", "title"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["name", "size"] }, { kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-filter-bar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe, ButtonComponent, IconComponent], template: "<div class=\"relative\">\n  <app-button\n    variant=\"secondary\"\n    size=\"sm\"\n    [attr.aria-expanded]=\"open()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"inline-flex items-center gap-2\">\n      <app-icon name=\"filter\" [size]=\"16\" />\n      {{ label() || ('filter.button' | uiKitT) }}\n      @if (activeCount() > 0) {\n        <span class=\"filter__count\" aria-hidden=\"true\">{{ activeCount() }}</span>\n      }\n    </span>\n  </app-button>\n\n  @if (open()) {\n    <div class=\"filter__panel\" role=\"dialog\" [attr.aria-label]=\"label() || ('filter.button' | uiKitT)\">\n      <div class=\"flex flex-col gap-4\">\n        <ng-content />\n      </div>\n      <div class=\"filter__actions\">\n        @if (!live()) {\n          <app-button size=\"sm\" (click)=\"emitApply()\">\n            {{ applyLabel() || ('filter.apply' | uiKitT) }}\n          </app-button>\n        }\n        @if (live() ? activeCount() > 0 : true) {\n          <app-button variant=\"ghost\" size=\"sm\" (click)=\"emitReset()\">\n            {{ resetLabel() || ('filter.reset' | uiKitT) }}\n          </app-button>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";.filter__count{display:inline-flex;align-items:center;justify-content:center;min-width:1.25rem;height:1.25rem;padding:0 var(--space-1);margin-left:var(--space-1);border-radius:999px;background:var(--color-primary);color:var(--color-on-primary, #fff);font-size:var(--fs-xs);font-weight:var(--fw-bold)}.filter__panel{position:absolute;right:0;z-index:var(--z-dropdown, 50);margin-top:var(--space-2);width:min(22rem,90vw);max-height:80vh;overflow-y:auto;display:flex;flex-direction:column;gap:var(--space-4);padding:var(--space-4);background:var(--color-bg-elevated, var(--color-surface));border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg)}.filter__actions{display:flex;gap:var(--space-2)}@media(max-width:768px){.filter__panel{position:fixed;inset:auto 0 0;margin-top:0;width:auto;max-height:80dvh;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border-bottom:0;z-index:var(--z-dialog)}.filter__actions app-button{flex:1 1 auto;display:flex}}\n"] }]
        }], propDecorators: { activeCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeCount", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], live: [{ type: i0.Input, args: [{ isSignal: true, alias: "live", required: false }] }], applyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "applyLabel", required: false }] }], resetLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetLabel", required: false }] }], apply: [{ type: i0.Output, args: ["apply"] }], reset: [{ type: i0.Output, args: ["reset"] }], openChange: [{ type: i0.Output, args: ["openChange"] }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }], onEscape: [{
                type: HostListener,
                args: ['document:keydown.escape']
            }] } });

/**
 * Ein Filter-Feld im {@link FilterBarComponent}-Popover: Label + projizierte
 * Steuerung (native input/select oder `<app-select>`). Einheitliche Optik für
 * alle Listen. Controls erben `.filter-field__control`-Styling über `::ng-deep`,
 * sodass Konsumenten nur ihr Control projizieren müssen.
 */
class FilterFieldComponent {
    constructor() {
        /** Sichtbares Label über dem Control. */
        this.label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.25", type: FilterFieldComponent, isStandalone: true, selector: "app-filter-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<label class=\"flex flex-col gap-1 min-w-0\">\n  <span class=\"text-sm font-medium text-muted\">{{ label() }}</span>\n  <ng-content />\n</label>\n", styles: ["@charset \"UTF-8\";:host ::ng-deep input:not([type=checkbox]):not([type=radio]):not(.cur__input),:host ::ng-deep select{width:100%;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg);color:var(--color-text);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);font:inherit;font-size:var(--fs-md)}:host ::ng-deep input[type=date]{min-width:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-filter-field', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<label class=\"flex flex-col gap-1 min-w-0\">\n  <span class=\"text-sm font-medium text-muted\">{{ label() }}</span>\n  <ng-content />\n</label>\n", styles: ["@charset \"UTF-8\";:host ::ng-deep input:not([type=checkbox]):not([type=radio]):not(.cur__input),:host ::ng-deep select{width:100%;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg);color:var(--color-text);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);font:inherit;font-size:var(--fs-md)}:host ::ng-deep input[type=date]{min-width:0}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }] } });

/**
 * Min/Max- bzw. Von/Bis-Bereich im Filter-Popover: zwei projizierte Controls mit
 * einem Trenner dazwischen. Slots: `[start]` und `[end]`.
 *
 * ```html
 * <app-filter-range>
 *   <input start type="date" … />
 *   <input end type="date" … />
 * </app-filter-range>
 * ```
 */
class FilterRangeComponent {
    constructor() {
        /** Trennzeichen zwischen den beiden Controls. */
        this.separator = input('–', ...(ngDevMode ? [{ debugName: "separator" }] : []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterRangeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.25", type: FilterRangeComponent, isStandalone: true, selector: "app-filter-range", inputs: { separator: { classPropertyName: "separator", publicName: "separator", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"flex items-center gap-2 min-w-0\">\n  <ng-content select=\"[start]\" />\n  <span class=\"text-muted flex-none\" aria-hidden=\"true\">{{ separator() }}</span>\n  <ng-content select=\"[end]\" />\n</div>\n", styles: ["@charset \"UTF-8\";:host ::ng-deep app-currency-input{flex:1 1 0;min-width:0}:host ::ng-deep input:not(.cur__input),:host ::ng-deep select{width:100%;min-width:0;flex:1 1 0;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg);color:var(--color-text);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);font:inherit;font-size:var(--fs-md)}:host ::ng-deep input[type=number]{-moz-appearance:textfield;appearance:textfield}:host ::ng-deep input[type=number]::-webkit-outer-spin-button,:host ::ng-deep input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterRangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-filter-range', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"flex items-center gap-2 min-w-0\">\n  <ng-content select=\"[start]\" />\n  <span class=\"text-muted flex-none\" aria-hidden=\"true\">{{ separator() }}</span>\n  <ng-content select=\"[end]\" />\n</div>\n", styles: ["@charset \"UTF-8\";:host ::ng-deep app-currency-input{flex:1 1 0;min-width:0}:host ::ng-deep input:not(.cur__input),:host ::ng-deep select{width:100%;min-width:0;flex:1 1 0;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg);color:var(--color-text);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);font:inherit;font-size:var(--fs-md)}:host ::ng-deep input[type=number]{-moz-appearance:textfield;appearance:textfield}:host ::ng-deep input[type=number]::-webkit-outer-spin-button,:host ::ng-deep input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}\n"] }]
        }], propDecorators: { separator: [{ type: i0.Input, args: [{ isSignal: true, alias: "separator", required: false }] }] } });

let nextId = 0;
/** Globaler Toast-Hub. Komponenten rufen `show()`, der Container rendert. */
class ToastService {
    constructor() {
        this._toasts = signal([], ...(ngDevMode ? [{ debugName: "_toasts" }] : []));
        this.toasts = this._toasts.asReadonly();
    }
    /** Zeigt einen Toast; `timeout=0` deaktiviert das automatische Schließen. */
    show(message, variant = 'info', timeout = 4000) {
        const id = nextId++;
        this._toasts.update((list) => [...list, { id, message, variant }]);
        if (timeout > 0)
            setTimeout(() => this.dismiss(id), timeout);
        return id;
    }
    success(message) {
        return this.show(message, 'success');
    }
    error(message) {
        return this.show(message, 'danger');
    }
    dismiss(id) {
        this._toasts.update((list) => list.filter((t) => t.id !== id));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Toast-Container — einmal im Shell-Layout platziert. ARIA-Live-Region. */
class ToastComponent {
    constructor() {
        this.toastService = inject(ToastService);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: ToastComponent, isStandalone: true, selector: "app-toast", ngImport: i0, template: "<div class=\"toasts\" aria-live=\"polite\" aria-atomic=\"false\">\n  @for (toast of toastService.toasts(); track toast.id) {\n    <div class=\"toast\" [class]=\"'toast--' + toast.variant\" role=\"status\">\n      <span class=\"toast__msg\">{{ toast.message }}</span>\n      <button\n        type=\"button\"\n        class=\"toast__close\"\n        [attr.aria-label]=\"'dialog.close' | uiKitT\"\n        (click)=\"toastService.dismiss(toast.id)\"\n      >\n        \u2715\n      </button>\n    </div>\n  }\n</div>\n", styles: [".toasts{position:fixed;inset-block-end:var(--space-5);inset-inline-end:var(--space-5);z-index:var(--z-toast);display:flex;flex-direction:column;gap:var(--space-3);max-width:min(92vw,24rem)}.toast{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border-radius:var(--radius-md);box-shadow:var(--shadow-md);border-inline-start:3px solid currentColor;background:var(--color-bg-elevated);color:var(--color-text)}.toast--success{border-color:var(--color-success)}.toast--warning{border-color:var(--color-warning)}.toast--danger{border-color:var(--color-danger)}.toast--info{border-color:var(--color-info)}.toast__msg{flex:1;font-size:var(--fs-sm)}.toast__close{background:transparent;border:0;cursor:pointer;color:var(--color-text-muted)}\n"], dependencies: [{ kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-toast', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe], template: "<div class=\"toasts\" aria-live=\"polite\" aria-atomic=\"false\">\n  @for (toast of toastService.toasts(); track toast.id) {\n    <div class=\"toast\" [class]=\"'toast--' + toast.variant\" role=\"status\">\n      <span class=\"toast__msg\">{{ toast.message }}</span>\n      <button\n        type=\"button\"\n        class=\"toast__close\"\n        [attr.aria-label]=\"'dialog.close' | uiKitT\"\n        (click)=\"toastService.dismiss(toast.id)\"\n      >\n        \u2715\n      </button>\n    </div>\n  }\n</div>\n", styles: [".toasts{position:fixed;inset-block-end:var(--space-5);inset-inline-end:var(--space-5);z-index:var(--z-toast);display:flex;flex-direction:column;gap:var(--space-3);max-width:min(92vw,24rem)}.toast{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border-radius:var(--radius-md);box-shadow:var(--shadow-md);border-inline-start:3px solid currentColor;background:var(--color-bg-elevated);color:var(--color-text)}.toast--success{border-color:var(--color-success)}.toast--warning{border-color:var(--color-warning)}.toast--danger{border-color:var(--color-danger)}.toast--info{border-color:var(--color-info)}.toast__msg{flex:1;font-size:var(--fs-sm)}.toast__close{background:transparent;border:0;cursor:pointer;color:var(--color-text-muted)}\n"] }]
        }] });

/*
 * Public API of @stupa-makers/ui-kit.
 *
 * The MarkdownEditorComponent is deliberately NOT re-exported here — it pulls Tiptap
 * (hundreds of kB). Import it from the secondary entry point instead, so it stays in the
 * consumer's lazy chunk:  import { MarkdownEditorComponent } from '@stupa-makers/ui-kit/markdown-editor';
 */
// --- i18n decoupling (token + built-in DE/EN defaults + pipe) ---------------

/**
 * Generated bundle index. Do not edit.
 */

export { BadgeComponent, ButtonComponent, CardComponent, CellDirective, CheckboxComponent, ConfigDiffComponent, CurrencyInputComponent, DataTableComponent, DateRangeComponent, DatepickerComponent, DefaultUiKitIntl, DialogComponent, FilterBarComponent, FilterFieldComponent, FilterRangeComponent, IconComponent, InputComponent, LoadingOverlayComponent, RowDetailDirective, SelectComponent, StepperComponent, TableComponent, TimeInputComponent, ToastComponent, ToastService, UI_KIT_DEFAULT_MESSAGES, UI_KIT_INTL, UI_KIT_LOADING, UiKitTranslatePipe, provideUiKit, uiKitIntlFromLang };
//# sourceMappingURL=stupa-makers-ui-kit.mjs.map
