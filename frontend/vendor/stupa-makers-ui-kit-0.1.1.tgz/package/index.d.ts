import * as i0 from '@angular/core';
import { Signal, InjectionToken, EnvironmentProviders, PipeTransform, OnChanges, OnDestroy, EventEmitter, SimpleChanges, TemplateRef, AfterContentInit } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as _stupa_makers_ui_kit from '@stupa-makers/ui-kit';

/** Languages the built-in catalogue ships. Consumers may map their own onto these. */
type UiLang = 'de' | 'en';
/** Every translatable string the kit renders itself. */
type UiKitTextKey = 'dialog.close' | 'loading' | 'datepicker.openCalendar' | 'filter.button' | 'filter.apply' | 'filter.reset' | 'diff.none' | 'diff.changed' | 'diff.added' | 'diff.removed';
type UiKitMessages = Record<UiKitTextKey, string>;
/** Built-in DE/EN strings — the kit renders identically out of the box. */
declare const UI_KIT_DEFAULT_MESSAGES: Record<UiLang, UiKitMessages>;
/**
 * The kit's i18n contract. The host app provides one (see {@link provideUiKit} /
 * {@link uiKitIntlFromLang}) to drive language + strings from its own system; if it
 * does nothing, a built-in DE/EN {@link DefaultUiKitIntl} is used.
 */
interface UiKitIntl {
    /** Active language as a signal — components react to changes without re-render hacks. */
    readonly lang: Signal<UiLang>;
    translate(key: UiKitTextKey, params?: Record<string, string | number>): string;
}
interface UiKitIntlOptions {
    /** External language signal (e.g. the host app's locale). Omit for an internal, settable one. */
    lang?: Signal<UiLang>;
    /** Partial message overrides merged over the built-in DE/EN catalogue. */
    messages?: Partial<Record<UiLang, Partial<UiKitMessages>>>;
}
/**
 * Default {@link UiKitIntl}: ships the built-in DE/EN catalogue. Language follows an
 * injected signal when given (so it tracks the host app's locale), otherwise an
 * internal signal seeded from the browser and settable via {@link setLang}.
 */
declare class DefaultUiKitIntl implements UiKitIntl {
    private readonly internalLang;
    readonly lang: Signal<UiLang>;
    private readonly messages;
    constructor(options?: UiKitIntlOptions);
    /** Set the language. Only effective when no external `lang` signal was provided. */
    setLang(lang: UiLang): void;
    translate(key: UiKitTextKey, params?: Record<string, string | number>): string;
}
/** DI token for the kit's i18n. Defaults to a built-in DE/EN {@link DefaultUiKitIntl}. */
declare const UI_KIT_INTL: InjectionToken<UiKitIntl>;
/** Build a {@link UiKitIntl} whose language tracks the given signal (e.g. an app locale). */
declare function uiKitIntlFromLang(lang: Signal<UiLang>, messages?: UiKitIntlOptions['messages']): UiKitIntl;
/**
 * Register the kit's i18n. Pass a ready {@link UiKitIntl} via `intl`, or `lang`/`messages`
 * to configure the default implementation. With no argument the built-in catalogue is used.
 */
declare function provideUiKit(options?: UiKitIntlOptions & {
    intl?: UiKitIntl;
}): EnvironmentProviders;

/**
 * `{{ 'dialog.close' | uiKitT }}` — impure so a language switch propagates immediately
 * (the active language is a signal on the {@link UiKitIntl}).
 */
declare class UiKitTranslatePipe implements PipeTransform {
    private readonly intl;
    transform(key: UiKitTextKey, params?: Record<string, string | number>): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiKitTranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UiKitTranslatePipe, "uiKitT", true>;
}

/** Minimal contract {@link LoadingOverlayComponent} needs from a host loading service. */
interface UiKitLoadingState {
    /** True while the global loading overlay should be visible. */
    readonly visible: Signal<boolean>;
}
/**
 * DI token feeding the loading overlay. Defaults to never-visible (no-op); the host app
 * provides one delegating to its own loading service, e.g.
 * `{ provide: UI_KIT_LOADING, useFactory: () => ({ visible: inject(LoadingService).visible }) }`.
 */
declare const UI_KIT_LOADING: InjectionToken<UiKitLoadingState>;

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'success';
type ButtonSize = 'sm' | 'md' | 'lg';
/** Basis-Button des UI-Kits. Clean/minimal, CD-Tokens, a11y-Fokus. */
declare class ButtonComponent {
    variant: ButtonVariant;
    /** Frei wählbare Hintergrundfarbe (Hex); überschreibt die Variante (#flow). */
    color: string | null;
    size: ButtonSize;
    type: 'button' | 'submit' | 'reset';
    disabled: boolean;
    loading: boolean;
    /** Quadratischer Icon-Button (gleiche Höhe/Breite) für einzelne Glyphs (✕ ↑ ↓). */
    iconOnly: boolean;
    /** Volle Breite des Containers (gestapelte Aktionen gleicher Breite). */
    block: boolean;
    /** Barrierefreier Name — Pflicht für Icon-Buttons ohne sichtbaren Text. */
    ariaLabel: string;
    /** Hover-Tooltip; bei Icon-Buttons fällt er automatisch auf `ariaLabel` zurück (#47). */
    title: string;
    /** Tooltip-Text: explizit gesetzt, sonst für Icon-Buttons der `ariaLabel`. */
    protected tooltip(): string | null;
    /** Lesbare Textfarbe (schwarz/weiß) zur gewählten `color` per WCAG-Luminanz. */
    protected contrastColor(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "app-button", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "type": { "alias": "type"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "iconOnly": { "alias": "iconOnly"; "required": false; }; "block": { "alias": "block"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/** Textfeld mit Label/Hinweis/Fehler. ControlValueAccessor → Reactive Forms. */
declare class InputComponent implements ControlValueAccessor {
    label: string;
    type: string;
    placeholder: string;
    hint: string;
    error: string;
    required: boolean;
    id: string;
    readonly value: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    get describedBy(): string | null;
    onInput(event: Event): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputComponent, "app-input", never, { "label": { "alias": "label"; "required": false; }; "type": { "alias": "type"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "error": { "alias": "error"; "required": false; }; "required": { "alias": "required"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Checkbox des UI-Kits. Boolescher Wert über `ControlValueAccessor`
 * (Reactive Forms + `ngModel`). Token-basiert (`accent-color` = CD-Primär),
 * sichtbarer Fokus-Ring (global `:focus-visible`), Label/`for`-Bindung für a11y.
 * Label-Text wird projiziert: `<app-checkbox [(ngModel)]="x">Text</app-checkbox>`.
 */
declare class CheckboxComponent implements ControlValueAccessor {
    id: string;
    hint: string;
    readonly checked: i0.WritableSignal<boolean>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    onToggle(event: Event): void;
    writeValue(value: boolean | null): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "app-checkbox", never, { "id": { "alias": "id"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/** Auswahloption für {@link SelectComponent}. */
interface SelectOption {
    value: string;
    label: string;
    disabled?: boolean;
}
/**
 * Dropdown des UI-Kits (#77). Ersetzt Freitext-Felder mit eingeschränkten
 * Optionen (Gremium, Budget, Status/Typ, Rollen). `ControlValueAccessor` →
 * Reactive Forms + `ngModel`. Token-basiert, eingebettetes Chevron, sichtbarer
 * Fokus-Ring, Label/`for`-Bindung + `aria-describedby` (a11y), Dark/Light.
 */
declare class SelectComponent implements ControlValueAccessor {
    label: string;
    /** Barrierefreier Name, wenn kein sichtbares Label gesetzt ist. */
    ariaLabel: string;
    placeholder: string;
    hint: string;
    error: string;
    required: boolean;
    options: SelectOption[];
    id: string;
    readonly value: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    get describedBy(): string | null;
    onSelect(event: Event): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectComponent, "app-select", never, { "label": { "alias": "label"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "error": { "alias": "error"; "required": false; }; "required": { "alias": "required"; "required": false; }; "options": { "alias": "options"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Datumsfeld des UI-Kits (#79). **Lokalisiertes** Anzeigeformat (DE: `TT.MM.JJJJ`,
 * EN: `MM/DD/YYYY`) — unabhängig von der Browser-Sprache, die das native
 * `<input type="date">` sonst erzwingt. Der Wert ist immer ISO (`YYYY-MM-DD`).
 *
 * Bedienung: tippen im Textfeld (locale-Reihenfolge) **oder** den nativen Kalender
 * über den Kalender-Button öffnen (`showPicker()`; das native Feld bleibt unsichtbar,
 * nur sein Kalender-Popup erscheint). `ControlValueAccessor` → Reactive Forms/`ngModel`.
 */
declare class DatepickerComponent implements ControlValueAccessor {
    private readonly intl;
    label: string;
    ariaLabel: string;
    hint: string;
    error: string;
    required: boolean;
    min: string;
    max: string;
    id: string;
    private readonly native;
    /** ISO-Wert (`YYYY-MM-DD`), CVA-Quelle. */
    readonly value: i0.WritableSignal<string>;
    /** Sichtbarer (locale-formatierter) Text — beim Tippen unverändert übernommen. */
    readonly display: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    readonly placeholder: i0.Signal<"TT.MM.JJJJ" | "MM/DD/YYYY">;
    private onChange;
    onTouched: () => void;
    constructor();
    get describedBy(): string | null;
    onText(text: string): void;
    onBlur(): void;
    onNative(iso: string): void;
    openPicker(): void;
    private commit;
    /** ISO → locale-Anzeige. */
    private format;
    /** Locale-Text → ISO (oder `''`). Akzeptiert `. / -` als Trenner; 2-stellige Jahre → 20xx. */
    private parse;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatepickerComponent, "app-datepicker", never, { "label": { "alias": "label"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "error": { "alias": "error"; "required": false; }; "required": { "alias": "required"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Uhrzeit-Feld des UI-Kits (#time-input). Erzwingt **24h-Format** (`HH:MM`) —
 * das native `<input type="time">` rendert je nach Browser-/OS-Locale AM/PM,
 * unabhängig von der App-Sprache. Der Wert ist immer `HH:MM` (oder `''`).
 *
 * Eingabe tolerant: `9:30`, `09.30`, `0930` → `09:30`; Commit bei Blur,
 * Ungültiges fällt auf den letzten gültigen Wert zurück (wie `app-datepicker`).
 * `ControlValueAccessor` → Reactive Forms/`ngModel`.
 */
declare class TimeInputComponent implements ControlValueAccessor {
    label: string;
    ariaLabel: string;
    required: boolean;
    id: string;
    /** Kanonischer Wert (`HH:MM` | `''`), CVA-Quelle. */
    readonly value: i0.WritableSignal<string>;
    /** Sichtbarer Text — beim Tippen unverändert, Commit bei Blur. */
    readonly display: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    onText(text: string): void;
    onBlur(): void;
    private commit;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimeInputComponent, "app-time-input", never, { "label": { "alias": "label"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "required": { "alias": "required"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

/** Zeitraum-Wert: ISO-Start/-Ende (`YYYY-MM-DD`), je leer wenn ungesetzt. */
interface DateRange {
    start: string;
    end: string;
}
/**
 * Zeitraum-Feld (#79): zwei gekoppelte native Datumsfelder (Start/Ende). Das Ende
 * kann nicht vor dem Start liegen (`min`/`max`-Kopplung). Wert ist `{ start, end }`;
 * `ControlValueAccessor` → Reactive Forms + `ngModel`. a11y über `<fieldset>` +
 * `<legend>` und `<label for>`-Bindung je Feld; native Kalender-UI folgt dem Theme
 * (`color-scheme`), Dark/Light via Tokens.
 */
declare class DateRangeComponent implements ControlValueAccessor {
    legend: string;
    startLabel: string;
    endLabel: string;
    id: string;
    readonly start: i0.WritableSignal<string>;
    readonly end: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    onStart(v: string): void;
    onEnd(v: string): void;
    private emit;
    writeValue(value: DateRange | null): void;
    registerOnChange(fn: (value: DateRange) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateRangeComponent, "app-date-range", never, { "legend": { "alias": "legend"; "required": false; }; "startLabel": { "alias": "startLabel"; "required": false; }; "endLabel": { "alias": "endLabel"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

type IconName = 'sun' | 'moon' | 'language' | 'edit' | 'delete' | 'add' | 'remove' | 'members' | 'roles' | 'user' | 'chevron-down' | 'chevron-up' | 'power' | 'filter' | 'check' | 'building' | 'parliament' | 'euro' | 'form' | 'flow' | 'palette' | 'webhook' | 'bell' | 'audit' | 'clock' | 'export' | 'play' | 'stop' | 'half' | 'send' | 'repeat' | 'menu' | 'gear' | 'key' | 'handshake' | 'paperclip' | 'link' | 'link-slash' | 'eye' | 'eye-slash' | 'upload' | 'document' | 'chart-pie';
/**
 * Icon-Komponente (#80). Rendert ein **Font-Awesome**-Solid-Icon (`fa-solid`),
 * gesteuert über einen stabilen, semantischen `name`. Dekorativ
 * (`aria-hidden`) — der barrierefreie Name kommt vom umschließenden Control.
 * `currentColor` folgt der Text-/Theme-Farbe automatisch (Dark/Light).
 */
declare class IconComponent {
    private readonly _name;
    set name(value: IconName);
    /** Kantenlänge in px (Schriftgröße des Glyphs). */
    size: number;
    protected readonly faClass: i0.Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "app-icon", never, { "name": { "alias": "name"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}

/** Container-Fläche. Slots: [card-header], default body, [card-footer]. */
declare class CardComponent {
    heading: string;
    interactive: boolean;
    /** Überschriften-Ebene des `heading` (a11y/heading-order). Default `<h3>`. */
    headingLevel: 2 | 3 | 4;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent, "app-card", never, { "heading": { "alias": "heading"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "headingLevel": { "alias": "headingLevel"; "required": false; }; }, {}, never, ["[card-header]", "*", "[card-footer]"], true, never>;
}

type BadgeVariant = 'neutral' | 'primary' | 'success' | 'warning' | 'danger' | 'info';
/** Status-Chip (z. B. Antrags-Status, Vote-Ergebnis). */
declare class BadgeComponent {
    variant: BadgeVariant;
    /**
     * Optionale, frei konfigurierte Hintergrundfarbe (Hex, z. B. Flow-State-Farbe).
     * Ist sie gesetzt, überschreibt sie das Variant-Styling; die Textfarbe wird
     * automatisch lesbar gewählt (dunkler Text auf hellem Grund, sonst weiß).
     */
    color?: string | null;
    /** Lesbare Textfarbe für {@link color} via Luminanz-Schwelle. */
    get textColor(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeComponent, "app-badge", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/**
 * Resolved field diff consumed by {@link ConfigDiffComponent}. Deliberately framework- and
 * app-agnostic: any `{ added, removed, changed }` object with this shape works (structural
 * typing), so callers can pass their own diff models without adapting.
 */
interface ConfigDiffEntry {
    key: string;
    value: unknown;
}
interface ConfigFieldChange {
    key: string;
    old: unknown;
    new: unknown;
}
interface ConfigDiffData {
    added: ConfigDiffEntry[];
    removed: ConfigDiffEntry[];
    changed: ConfigFieldChange[];
}

/**
 * Feld-Diff-Renderer (added/removed/changed) — z. B. für Antrags-Historie
 * (Submission-Versionen) oder Config-Versionen (Forms/Flow/Branding). Reine
 * Präsentation: nimmt einen aufgelösten {@link ConfigDiffData} (Arrays) und rendert
 * je Eintrag ein Severity-Badge + Feld-Key + Alt→Neu-Werte.
 */
declare class ConfigDiffComponent {
    /** Aufgelöster Diff (`null`/leer ⇒ »keine Änderungen«). */
    readonly diff: i0.InputSignal<ConfigDiffData | null>;
    protected isEmpty(d: ConfigDiffData | null): boolean;
    /** Wert lesbar machen (Objekte als JSON; null/undefined als »—«). */
    protected fmt(value: unknown): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigDiffComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfigDiffComponent, "app-config-diff", never, { "diff": { "alias": "diff"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface Step {
    label: string;
}
/** Fortschrittsanzeige für den Antrags-Wizard (N1a Multi-Step). */
declare class StepperComponent {
    steps: Step[];
    activeIndex: number;
    ariaLabel: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StepperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StepperComponent, "app-stepper", never, { "steps": { "alias": "steps"; "required": false; }; "activeIndex": { "alias": "activeIndex"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Modaler Dialog. Schließt per Backdrop-Klick, Schließen-Button oder ESC.
 *
 * a11y (T-43, WCAG 2.1.2/2.4.3): Beim Öffnen wandert der Fokus in den Dialog,
 * Tab/Shift+Tab werden im Dialog gefangen (Focus-Trap), beim Schließen kehrt der
 * Fokus auf das auslösende Element zurück. `aria-modal`/`role="dialog"` +
 * `aria-labelledby` sind gesetzt.
 */
declare class DialogComponent implements OnChanges, OnDestroy {
    open: boolean;
    title: string;
    closeLabel: string;
    /** Breite: 'md' (32rem, Default) oder 'lg' (44rem, z. B. Charts). */
    size: 'md' | 'lg';
    closed: EventEmitter<void>;
    private pane?;
    readonly titleId: string;
    /** Element, das vor dem Öffnen den Fokus hatte — für Restore beim Schließen. */
    private previouslyFocused;
    /** Body-Scroll-Sperre: gemerkter vorheriger overflow-Wert für den Restore. */
    private prevBodyOverflow;
    private dragStartY;
    private dragStartT;
    private dragging;
    private dragDy;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    onEscape(): void;
    /** Tab/Shift+Tab im Dialog halten (Focus-Trap). */
    onKeydown(event: KeyboardEvent): void;
    onBackdrop(_event: MouseEvent): void;
    onDragStart(event: TouchEvent): void;
    onDragMove(event: TouchEvent): void;
    onDragEnd(event: TouchEvent): void;
    close(): void;
    private lockScroll;
    private unlockScroll;
    /** Vorherigen Fokus merken und Fokus in den Dialog setzen (nach Render). */
    private captureAndFocus;
    private restoreFocus;
    private focusable;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogComponent, "app-dialog", never, { "open": { "alias": "open"; "required": false; }; "title": { "alias": "title"; "required": false; }; "closeLabel": { "alias": "closeLabel"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "closed": "closed"; }, never, ["*", "[dialog-footer]"], true, never>;
}

interface Column<T> {
    key: keyof T & string;
    label: string;
    align?: 'start' | 'end';
}
/** Schlanke, datengetriebene Tabelle. Für komplexe Fälle später erweiterbar. */
declare class TableComponent<T extends Record<string, unknown>> {
    columns: Column<T>[];
    rows: T[];
    caption: string;
    emptyText: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableComponent<any>, "app-table", never, { "columns": { "alias": "columns"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "emptyText": { "alias": "emptyText"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Markiert ein `<ng-template>` als ausklappbare Detail-Zeile der
 * {@link DataTableComponent}: `<ng-template appRowDetail let-row>…`. Wird je
 * Zeile gerendert, für die `isExpanded(row)` true ist (volle Breite darunter).
 */
declare class RowDetailDirective {
    readonly tpl: TemplateRef<{
        $implicit: unknown;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RowDetailDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RowDetailDirective, "[appRowDetail]", never, {}, {}, never, never, true, never>;
}

/** Spalten-Definition der {@link DataTableComponent}. */
interface ColumnDef {
    key: string;
    label: string;
    align?: 'start' | 'end';
    /** CSS-Breite (z. B. `12rem`); optional. */
    width?: string;
}
/**
 * Geteilte, datengetriebene Tabelle (#26). Spalten kommen als {@link ColumnDef}-
 * Liste; einzelne Zellen lassen sich per `<ng-template appCell="key" let-row>`
 * frei rendern (Badges/Buttons/Links). Ohne Template wird `row[key]` als Text
 * gezeigt. Optional als Box (Standard) und mit Zeilen-Klick.
 *
 * So bleiben alle Admin-Tabellen visuell konsistent (eine Quelle für Kopf/Rahmen/
 * Hover/Empty-State), statt jede Seite ihr eigenes `<table>` zu bauen.
 */
declare class DataTableComponent implements AfterContentInit {
    columns: ColumnDef[];
    rows: readonly unknown[];
    emptyText: string;
    boxed: boolean;
    /** Stabiler Track-Key je Zeile (sonst Index). */
    rowKey?: (row: unknown, index: number) => unknown;
    /** Macht Zeilen klickbar (Cursor/Tab/Enter) + emittiert `rowClick`. */
    clickable: boolean;
    rowClick: EventEmitter<unknown>;
    /** Prädikat: für welche Zeilen die Detail-Zeile gezeigt wird. */
    isExpanded?: (row: unknown) => boolean;
    private cellDirs;
    protected rowDetail?: RowDetailDirective;
    private readonly cellMap;
    ngAfterContentInit(): void;
    protected cellFor(key: string): TemplateRef<unknown> | null;
    protected text(row: unknown, key: string): unknown;
    protected trackRow(row: unknown, index: number): unknown;
    protected onRow(row: unknown): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataTableComponent, "app-data-table", never, { "columns": { "alias": "columns"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "emptyText": { "alias": "emptyText"; "required": false; }; "boxed": { "alias": "boxed"; "required": false; }; "rowKey": { "alias": "rowKey"; "required": false; }; "clickable": { "alias": "clickable"; "required": false; }; "isExpanded": { "alias": "isExpanded"; "required": false; }; }, { "rowClick": "rowClick"; }, ["rowDetail", "cellDirs"], never, true, never>;
}

/**
 * Markiert ein `<ng-template>` als Zell-Renderer einer Spalte der
 * {@link DataTableComponent}: `<ng-template appCell="status" let-row>…`.
 * Der `let-row`-Kontext ist die jeweilige Zeile.
 */
declare class CellDirective {
    /** Spalten-Key, für den dieses Template gerendert wird. */
    key: string;
    readonly tpl: TemplateRef<{
        $implicit: unknown;
        index: number;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CellDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CellDirective, "[appCell]", never, { "key": { "alias": "appCell"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Einheitliches Währungs-Eingabefeld (#currency). Überall gleiche Optik:
 * rechtsbündig, Tausender-Gruppierung + 2 Nachkommastellen, „€"-Suffix.
 *
 * `ControlValueAccessor` → per `[(ngModel)]` nutzbar. Das **Modell** ist stets ein
 * kanonischer Dezimal-String mit Punkt (`"1234.56"`, parsebar fürs Backend) bzw.
 * `''` für leer. Die **Anzeige** ist lokalisiert (de `1.234,56`, en `1,234.56`):
 * beim Fokus editierbar (ohne Gruppierung), beim Verlassen formatiert.
 */
declare class CurrencyInputComponent implements ControlValueAccessor {
    private readonly intl;
    readonly placeholder: i0.InputSignal<string>;
    readonly ariaLabel: i0.InputSignal<string>;
    readonly name: i0.InputSignal<string>;
    /** Optionales Feld-Label; gesetzt → volle Feld-Optik (Label/Hint/Error),
     *  leer → blankes Control (für eigene Label-Wrapper, z. B. Filter/Dialoge). */
    readonly label: i0.InputSignal<string>;
    readonly hint: i0.InputSignal<string>;
    readonly error: i0.InputSignal<string>;
    readonly required: i0.InputSignal<boolean>;
    /** Sichtbarer Text (formatiert oder beim Tippen roh). */
    protected readonly text: i0.WritableSignal<string>;
    protected readonly disabled: i0.WritableSignal<boolean>;
    /** Kanonischer Wert (Punkt-Dezimal, ohne Gruppierung) — das Modell. */
    private canonical;
    private focused;
    private onChange;
    private onTouched;
    writeValue(value: string | number | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    protected onFocus(): void;
    protected onInput(raw: string): void;
    protected onBlur(): void;
    private get decimalSep();
    /** Roh-Eingabe → kanonischer Punkt-Dezimal-String (oder ''). */
    private parse;
    /** Beliebigen Wert (Backend-Punkt oder lokal) → kanonisch. */
    private toCanonical;
    /** Kanonisch → editierbarer Text (lokaler Dezimaltrenner, keine Gruppierung). */
    private toEditable;
    /** Kanonisch → lokalisiert formatiert (1.234,56) mit 2 Nachkommastellen. */
    private format;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CurrencyInputComponent, "app-currency-input", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Globaler Ladebildschirm: halbtransparenter Overlay über dem Inhaltsbereich
 * (unterhalb des Headers) mit zentriertem Spinner, gesteuert über den
 * {@link UI_KIT_LOADING}-Token (vom Host an seinen Lade-Service gebunden).
 * Header/Navigation bleiben bedienbar. Liegt unter Dialogen/Toasts (z-index),
 * damit diese darüber sichtbar bleiben.
 */
declare class LoadingOverlayComponent {
    protected readonly loading: _stupa_makers_ui_kit.UiKitLoadingState;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingOverlayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingOverlayComponent, "app-loading-overlay", never, {}, {}, never, never, true, never>;
}

/**
 * Einheitlicher Filter-Balken für Listen (#filters). Ein sekundärer Button
 * (Trichter-Icon + Label + Aktiv-Zähler) öffnet ein rechtsbündiges Popover; die
 * eigentlichen Filter-Felder werden projiziert (`<app-filter-field>` /
 * `<app-filter-range>`). Schließt bei Klick außerhalb und Escape.
 *
 * Zwei Modi:
 * - **Apply** (Default): Popover zeigt „Anwenden" + „Zurücksetzen"; der Konsument
 *   übernimmt die Werte erst bei `(apply)`.
 * - **Live** (`[live]="true"`): keine Anwenden-Taste — Felder wirken sofort (der
 *   Konsument bindet direkt). Nur „Zurücksetzen" erscheint bei aktiven Filtern.
 */
declare class FilterBarComponent {
    private readonly host;
    /** Anzahl aktiver Filter (Badge); 0 blendet den Zähler aus. */
    readonly activeCount: i0.InputSignal<number>;
    /** Button-Label; leer = i18n-Default „Filter". */
    readonly label: i0.InputSignal<string>;
    /** Live-Modus: keine „Anwenden"-Taste (Felder wirken sofort). */
    readonly live: i0.InputSignal<boolean>;
    readonly applyLabel: i0.InputSignal<string>;
    readonly resetLabel: i0.InputSignal<string>;
    /** „Anwenden" geklickt (Apply-Modus). Schließt das Popover. */
    readonly apply: i0.OutputEmitterRef<void>;
    /** „Zurücksetzen" geklickt. */
    readonly reset: i0.OutputEmitterRef<void>;
    /** Offen-Zustand geändert (z. B. zum Re-Fokus). */
    readonly openChange: i0.OutputEmitterRef<boolean>;
    protected readonly open: i0.WritableSignal<boolean>;
    /** True, wenn das Popover geöffnet ist (für Konsumenten via Template-Ref). */
    readonly isOpen: i0.Signal<boolean>;
    toggle(): void;
    close(): void;
    protected emitApply(): void;
    protected emitReset(): void;
    private setOpen;
    protected onDocumentClick(event: MouseEvent): void;
    protected onEscape(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterBarComponent, "app-filter-bar", never, { "activeCount": { "alias": "activeCount"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "live": { "alias": "live"; "required": false; "isSignal": true; }; "applyLabel": { "alias": "applyLabel"; "required": false; "isSignal": true; }; "resetLabel": { "alias": "resetLabel"; "required": false; "isSignal": true; }; }, { "apply": "apply"; "reset": "reset"; "openChange": "openChange"; }, never, ["*"], true, never>;
}

/**
 * Ein Filter-Feld im {@link FilterBarComponent}-Popover: Label + projizierte
 * Steuerung (native input/select oder `<app-select>`). Einheitliche Optik für
 * alle Listen. Controls erben `.filter-field__control`-Styling über `::ng-deep`,
 * sodass Konsumenten nur ihr Control projizieren müssen.
 */
declare class FilterFieldComponent {
    /** Sichtbares Label über dem Control. */
    readonly label: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterFieldComponent, "app-filter-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Min/Max- bzw. Von/Bis-Bereich im Filter-Popover: zwei projizierte Controls mit
 * einem Trenner dazwischen. Slots: `[start]` und `[end]`.
 *
 * ```html
 * <app-filter-range>
 *   <input start type="date" … />
 *   <input end type="date" … />
 * </app-filter-range>
 * ```
 */
declare class FilterRangeComponent {
    /** Trennzeichen zwischen den beiden Controls. */
    readonly separator: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterRangeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterRangeComponent, "app-filter-range", never, { "separator": { "alias": "separator"; "required": false; "isSignal": true; }; }, {}, never, ["[start]", "[end]"], true, never>;
}

type ToastVariant = 'info' | 'success' | 'warning' | 'danger';
interface Toast {
    id: number;
    message: string;
    variant: ToastVariant;
}
/** Globaler Toast-Hub. Komponenten rufen `show()`, der Container rendert. */
declare class ToastService {
    private readonly _toasts;
    readonly toasts: i0.Signal<Toast[]>;
    /** Zeigt einen Toast; `timeout=0` deaktiviert das automatische Schließen. */
    show(message: string, variant?: ToastVariant, timeout?: number): number;
    success(message: string): number;
    error(message: string): number;
    dismiss(id: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToastService>;
}

/** Toast-Container — einmal im Shell-Layout platziert. ARIA-Live-Region. */
declare class ToastComponent {
    readonly toastService: ToastService;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToastComponent, "app-toast", never, {}, {}, never, never, true, never>;
}

export { BadgeComponent, ButtonComponent, CardComponent, CellDirective, CheckboxComponent, ConfigDiffComponent, CurrencyInputComponent, DataTableComponent, DateRangeComponent, DatepickerComponent, DefaultUiKitIntl, DialogComponent, FilterBarComponent, FilterFieldComponent, FilterRangeComponent, IconComponent, InputComponent, LoadingOverlayComponent, RowDetailDirective, SelectComponent, StepperComponent, TableComponent, TimeInputComponent, ToastComponent, ToastService, UI_KIT_DEFAULT_MESSAGES, UI_KIT_INTL, UI_KIT_LOADING, UiKitTranslatePipe, provideUiKit, uiKitIntlFromLang };
export type { BadgeVariant, ButtonSize, ButtonVariant, Column, ColumnDef, ConfigDiffData, ConfigDiffEntry, ConfigFieldChange, DateRange, IconName, SelectOption, Step, Toast, ToastVariant, UiKitIntl, UiKitIntlOptions, UiKitLoadingState, UiKitMessages, UiKitTextKey, UiLang };
