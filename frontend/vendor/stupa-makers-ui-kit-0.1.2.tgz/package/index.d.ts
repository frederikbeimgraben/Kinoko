import * as i0 from '@angular/core';
import { Signal, InjectionToken, EnvironmentProviders, PipeTransform, OnChanges, OnDestroy, EventEmitter, SimpleChanges, TemplateRef, AfterContentInit, AfterViewInit, AfterViewChecked } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';
import * as _stupa_makers_ui_kit from '@stupa-makers/ui-kit';

/** Languages the built-in catalogue ships. Consumers may map their own onto these. */
type UiLang = 'de' | 'en';
/** Every translatable string the kit renders itself. */
type UiKitTextKey = 'dialog.close' | 'loading' | 'datepicker.openCalendar' | 'filter.button' | 'filter.apply' | 'filter.reset' | 'diff.none' | 'diff.changed' | 'diff.added' | 'diff.removed' | 'table.scrollStart' | 'table.scrollEnd';
type UiKitMessages = Record<UiKitTextKey, string>;
/** Built-in DE/EN strings — the kit renders identically out of the box. */
declare const UI_KIT_DEFAULT_MESSAGES: Record<UiLang, UiKitMessages>;
/**
 * The kit's i18n contract. The host app provides one (see {@link provideUiKit} /
 * {@link uiKitIntlFromLang}) to drive language + strings from its own system; if it
 * does nothing, a built-in DE/EN {@link DefaultUiKitIntl} is used.
 */
interface UiKitIntl {
    /** Active language as a signal — components react to changes without re-render hacks. */
    readonly lang: Signal<UiLang>;
    translate(key: UiKitTextKey, params?: Record<string, string | number>): string;
}
interface UiKitIntlOptions {
    /** External language signal (e.g. the host app's locale). Omit for an internal, settable one. */
    lang?: Signal<UiLang>;
    /** Partial message overrides merged over the built-in DE/EN catalogue. */
    messages?: Partial<Record<UiLang, Partial<UiKitMessages>>>;
}
/**
 * Default {@link UiKitIntl}: ships the built-in DE/EN catalogue. Language follows an
 * injected signal when given (so it tracks the host app's locale), otherwise an
 * internal signal seeded from the browser and settable via {@link setLang}.
 */
declare class DefaultUiKitIntl implements UiKitIntl {
    private readonly internalLang;
    readonly lang: Signal<UiLang>;
    private readonly messages;
    constructor(options?: UiKitIntlOptions);
    /** Set the language. Only effective when no external `lang` signal was provided. */
    setLang(lang: UiLang): void;
    translate(key: UiKitTextKey, params?: Record<string, string | number>): string;
}
/** DI token for the kit's i18n. Defaults to a built-in DE/EN {@link DefaultUiKitIntl}. */
declare const UI_KIT_INTL: InjectionToken<UiKitIntl>;
/** Build a {@link UiKitIntl} whose language tracks the given signal (e.g. an app locale). */
declare function uiKitIntlFromLang(lang: Signal<UiLang>, messages?: UiKitIntlOptions['messages']): UiKitIntl;
/**
 * Register the kit's i18n. Pass a ready {@link UiKitIntl} via `intl`, or `lang`/`messages`
 * to configure the default implementation. With no argument the built-in catalogue is used.
 */
declare function provideUiKit(options?: UiKitIntlOptions & {
    intl?: UiKitIntl;
}): EnvironmentProviders;

/**
 * `{{ 'dialog.close' | uiKitT }}` — impure so a language switch propagates immediately
 * (the active language is a signal on the {@link UiKitIntl}).
 */
declare class UiKitTranslatePipe implements PipeTransform {
    private readonly intl;
    transform(key: UiKitTextKey, params?: Record<string, string | number>): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<UiKitTranslatePipe, never>;
    static ɵpipe: i0.ɵɵPipeDeclaration<UiKitTranslatePipe, "uiKitT", true>;
}

/** Minimal contract {@link LoadingOverlayComponent} needs from a host loading service. */
interface UiKitLoadingState {
    /** True while the global loading overlay should be visible. */
    readonly visible: Signal<boolean>;
}
/**
 * DI token feeding the loading overlay. Defaults to never-visible (no-op); the host app
 * provides one delegating to its own loading service, e.g.
 * `{ provide: UI_KIT_LOADING, useFactory: () => ({ visible: inject(LoadingService).visible }) }`.
 */
declare const UI_KIT_LOADING: InjectionToken<UiKitLoadingState>;

type ButtonVariant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'danger-outline' | 'success';
type ButtonSize = 'sm' | 'md' | 'lg';
/** Basis-Button des UI-Kits. Clean/minimal, CD-Tokens, a11y-Fokus. */
declare class ButtonComponent {
    variant: ButtonVariant;
    /** Frei wählbare Hintergrundfarbe (Hex); überschreibt die Variante. */
    color: string | null;
    size: ButtonSize;
    type: 'button' | 'submit' | 'reset';
    disabled: boolean;
    loading: boolean;
    /** Quadratischer Icon-Button (gleiche Höhe/Breite) für einzelne Glyphs (✕ ↑ ↓). */
    iconOnly: boolean;
    /** Volle Breite des Containers (gestapelte Aktionen gleicher Breite). */
    block: boolean;
    /** Barrierefreier Name — Pflicht für Icon-Buttons ohne sichtbaren Text. */
    ariaLabel: string;
    /**
     * Toggle-Zustand für einen Button, der an/aus ist — etwa ein Segment in einer
     * Filtergruppe. Ohne das unterscheidet nur die `variant`-Farbe den aktiven Eintrag,
     * und eine Vorlesehilfe hört drei gleich benannte Buttons ohne Zustand.
     */
    ariaPressed: boolean | null;
    /** Hover-Tooltip; bei Icon-Buttons fällt er automatisch auf `ariaLabel` zurück. */
    title: string;
    /** Tooltip-Text: explizit gesetzt, sonst für Icon-Buttons der `ariaLabel`. */
    protected tooltip(): string | null;
    /** Lesbare Textfarbe (schwarz/weiß) zur gewählten `color` per WCAG-Luminanz. */
    protected contrastColor(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ButtonComponent, "app-button", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; "size": { "alias": "size"; "required": false; }; "type": { "alias": "type"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "iconOnly": { "alias": "iconOnly"; "required": false; }; "block": { "alias": "block"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "ariaPressed": { "alias": "ariaPressed"; "required": false; }; "title": { "alias": "title"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/** Textfeld mit Label/Hinweis/Fehler. ControlValueAccessor → Reactive Forms. */
declare class InputComponent implements ControlValueAccessor {
    label: string;
    type: string;
    placeholder: string;
    hint: string;
    error: string;
    required: boolean;
    id: string;
    readonly value: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    get describedBy(): string | null;
    onInput(event: Event): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<InputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<InputComponent, "app-input", never, { "label": { "alias": "label"; "required": false; }; "type": { "alias": "type"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "error": { "alias": "error"; "required": false; }; "required": { "alias": "required"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Checkbox des UI-Kits. Boolescher Wert über `ControlValueAccessor`
 * (Reactive Forms + `ngModel`). Token-basiert (`accent-color` = CD-Primär),
 * sichtbarer Fokus-Ring (global `:focus-visible`), Label/`for`-Bindung für a11y.
 * Label-Text wird projiziert: `<app-checkbox [(ngModel)]="x">Text</app-checkbox>`.
 */
declare class CheckboxComponent implements ControlValueAccessor {
    id: string;
    hint: string;
    readonly checked: i0.WritableSignal<boolean>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    onToggle(event: Event): void;
    writeValue(value: boolean | null): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<CheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CheckboxComponent, "app-checkbox", never, { "id": { "alias": "id"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/** Auswahloption für {@link SelectComponent}. */
interface SelectOption {
    value: string;
    label: string;
    disabled?: boolean;
}
/**
 * Dropdown des UI-Kits. Ersetzt Freitext-Felder mit eingeschränkten
 * Optionen (Gremium, Budget, Status/Typ, Rollen). `ControlValueAccessor` →
 * Reactive Forms + `ngModel`. Token-basiert, eingebettetes Chevron, sichtbarer
 * Fokus-Ring, Label/`for`-Bindung + `aria-describedby` (a11y), Dark/Light.
 */
declare class SelectComponent implements ControlValueAccessor {
    label: string;
    /** Barrierefreier Name, wenn kein sichtbares Label gesetzt ist. */
    ariaLabel: string;
    placeholder: string;
    hint: string;
    error: string;
    required: boolean;
    options: SelectOption[];
    id: string;
    readonly value: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    get describedBy(): string | null;
    onSelect(event: Event): void;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<SelectComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SelectComponent, "app-select", never, { "label": { "alias": "label"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "error": { "alias": "error"; "required": false; }; "required": { "alias": "required"; "required": false; }; "options": { "alias": "options"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Datumsfeld des UI-Kits. **Lokalisiertes** Anzeigeformat (DE: `TT.MM.JJJJ`,
 * EN: `MM/DD/YYYY`) — unabhängig von der Browser-Sprache, die das native
 * `<input type="date">` sonst erzwingt. Der Wert ist immer ISO (`YYYY-MM-DD`).
 *
 * Bedienung: tippen im Textfeld (locale-Reihenfolge) **oder** den nativen Kalender
 * über den Kalender-Button öffnen (`showPicker()`; das native Feld bleibt unsichtbar,
 * nur sein Kalender-Popup erscheint). `ControlValueAccessor` → Reactive Forms/`ngModel`.
 */
declare class DatepickerComponent implements ControlValueAccessor {
    private readonly intl;
    label: string;
    ariaLabel: string;
    hint: string;
    error: string;
    required: boolean;
    min: string;
    max: string;
    id: string;
    private readonly native;
    /** ISO-Wert (`YYYY-MM-DD`), CVA-Quelle. */
    readonly value: i0.WritableSignal<string>;
    /** Sichtbarer (locale-formatierter) Text — beim Tippen unverändert übernommen. */
    readonly display: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    readonly placeholder: i0.Signal<"TT.MM.JJJJ" | "DD/MM/YYYY">;
    private onChange;
    onTouched: () => void;
    constructor();
    get describedBy(): string | null;
    onText(text: string): void;
    onBlur(): void;
    onNative(iso: string): void;
    openPicker(): void;
    private commit;
    /** ISO → locale-Anzeige. */
    private format;
    /**
     * Locale-Text → ISO (oder `''`). Akzeptiert `. / -` als Trenner; 2-stellige Jahre → 20xx.
     *
     * Day first in BOTH languages. The host renders EN dates as en-GB, so a table showing
     * 04/09/2026 means 4 September; reading it back as 9 April changed the date silently.
     */
    private parse;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DatepickerComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DatepickerComponent, "app-datepicker", never, { "label": { "alias": "label"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "hint": { "alias": "hint"; "required": false; }; "error": { "alias": "error"; "required": false; }; "required": { "alias": "required"; "required": false; }; "min": { "alias": "min"; "required": false; }; "max": { "alias": "max"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Uhrzeit-Feld des UI-Kits. Erzwingt **24h-Format** (`HH:MM`) —
 * das native `<input type="time">` rendert je nach Browser-/OS-Locale AM/PM,
 * unabhängig von der App-Sprache. Der Wert ist immer `HH:MM` (oder `''`).
 *
 * Eingabe tolerant: `9:30`, `09.30`, `0930` → `09:30`; Commit bei Blur,
 * Ungültiges fällt auf den letzten gültigen Wert zurück (wie `app-datepicker`).
 * `ControlValueAccessor` → Reactive Forms/`ngModel`.
 */
declare class TimeInputComponent implements ControlValueAccessor {
    label: string;
    ariaLabel: string;
    required: boolean;
    id: string;
    /** Kanonischer Wert (`HH:MM` | `''`), CVA-Quelle. */
    readonly value: i0.WritableSignal<string>;
    /** Sichtbarer Text — beim Tippen unverändert, Commit bei Blur. */
    readonly display: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    onText(text: string): void;
    onBlur(): void;
    private commit;
    writeValue(value: string | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<TimeInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TimeInputComponent, "app-time-input", never, { "label": { "alias": "label"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "required": { "alias": "required"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

/** Zeitraum-Wert: ISO-Start/-Ende (`YYYY-MM-DD`), je leer wenn ungesetzt. */
interface DateRange {
    start: string;
    end: string;
}
/**
 * Zeitraum-Feld: zwei gekoppelte native Datumsfelder (Start/Ende). Das Ende
 * kann nicht vor dem Start liegen (`min`/`max`-Kopplung). Wert ist `{ start, end }`;
 * `ControlValueAccessor` → Reactive Forms + `ngModel`. a11y über `<fieldset>` +
 * `<legend>` und `<label for>`-Bindung je Feld; native Kalender-UI folgt dem Theme
 * (`color-scheme`), Dark/Light via Tokens.
 */
declare class DateRangeComponent implements ControlValueAccessor {
    legend: string;
    startLabel: string;
    endLabel: string;
    id: string;
    readonly start: i0.WritableSignal<string>;
    readonly end: i0.WritableSignal<string>;
    readonly disabled: i0.WritableSignal<boolean>;
    private onChange;
    onTouched: () => void;
    onStart(v: string): void;
    onEnd(v: string): void;
    private emit;
    writeValue(value: DateRange | null): void;
    registerOnChange(fn: (value: DateRange) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DateRangeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DateRangeComponent, "app-date-range", never, { "legend": { "alias": "legend"; "required": false; }; "startLabel": { "alias": "startLabel"; "required": false; }; "endLabel": { "alias": "endLabel"; "required": false; }; "id": { "alias": "id"; "required": false; }; }, {}, never, never, true, never>;
}

type IconName = 'sun' | 'moon' | 'language' | 'edit' | 'delete' | 'add' | 'remove' | 'members' | 'roles' | 'user' | 'chevron-down' | 'chevron-up' | 'power' | 'filter' | 'check' | 'building' | 'parliament' | 'euro' | 'form' | 'flow' | 'palette' | 'webhook' | 'bell' | 'audit' | 'clock' | 'export' | 'play' | 'stop' | 'half' | 'send' | 'repeat' | 'menu' | 'gear' | 'key' | 'handshake' | 'paperclip' | 'paperclip-slash' | 'home' | 'link' | 'link-slash' | 'search' | 'eye' | 'eye-slash' | 'upload' | 'document' | 'chart-pie';
/**
 * Icon-Komponente. Rendert ein **Font-Awesome**-Solid-Icon (`fa-solid`),
 * gesteuert über einen stabilen, semantischen `name`. Dekorativ
 * (`aria-hidden`) — der barrierefreie Name kommt vom umschließenden Control.
 * `currentColor` folgt der Text-/Theme-Farbe automatisch (Dark/Light).
 */
declare class IconComponent {
    private readonly _name;
    set name(value: IconName);
    /** Kantenlänge in px (Schriftgröße des Glyphs). */
    size: number;
    protected readonly faClass: i0.Signal<string>;
    /** Leer, wenn das Icon aus einem einzigen Glyph besteht. */
    protected readonly overlayClass: i0.Signal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<IconComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<IconComponent, "app-icon", never, { "name": { "alias": "name"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, {}, never, never, true, never>;
}

/** Container-Fläche. Slots: [card-header], default body, [card-footer]. */
declare class CardComponent {
    heading: string;
    interactive: boolean;
    /** Überschriften-Ebene des `heading` (a11y/heading-order). Default `<h3>`. */
    headingLevel: 2 | 3 | 4;
    static ɵfac: i0.ɵɵFactoryDeclaration<CardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CardComponent, "app-card", never, { "heading": { "alias": "heading"; "required": false; }; "interactive": { "alias": "interactive"; "required": false; }; "headingLevel": { "alias": "headingLevel"; "required": false; }; }, {}, never, ["[card-header]", "*", "[card-footer]"], true, never>;
}

type BadgeVariant = 'neutral' | 'primary' | 'success' | 'warning' | 'danger' | 'info';
/** Status-Chip (z. B. Antrags-Status, Vote-Ergebnis). */
declare class BadgeComponent {
    variant: BadgeVariant;
    /**
     * Optionale, frei konfigurierte Hintergrundfarbe (Hex, z. B. Flow-State-Farbe).
     * Ist sie gesetzt, überschreibt sie das Variant-Styling; die Textfarbe wird
     * automatisch lesbar gewählt (dunkler Text auf hellem Grund, sonst weiß).
     */
    color?: string | null;
    /** Lesbare Textfarbe für {@link color} via Luminanz-Schwelle. */
    get textColor(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<BadgeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<BadgeComponent, "app-badge", never, { "variant": { "alias": "variant"; "required": false; }; "color": { "alias": "color"; "required": false; }; }, {}, never, ["*"], true, never>;
}

/**
 * Resolved field diff consumed by {@link ConfigDiffComponent}. Deliberately framework- and
 * app-agnostic: any `{ added, removed, changed }` object with this shape works (structural
 * typing), so callers can pass their own diff models without adapting.
 */
interface ConfigDiffEntry {
    key: string;
    value: unknown;
}
interface ConfigFieldChange {
    key: string;
    old: unknown;
    new: unknown;
}
interface ConfigDiffData {
    added: ConfigDiffEntry[];
    removed: ConfigDiffEntry[];
    changed: ConfigFieldChange[];
}

/**
 * Feld-Diff-Renderer (added/removed/changed) — z. B. für Antrags-Historie
 * (Submission-Versionen) oder Config-Versionen (Forms/Flow/Branding). Reine
 * Präsentation: nimmt einen aufgelösten {@link ConfigDiffData} (Arrays) und rendert
 * je Eintrag ein Severity-Badge + Feld-Key + Alt→Neu-Werte.
 */
declare class ConfigDiffComponent {
    /** Aufgelöster Diff (`null`/leer ⇒ »keine Änderungen«). */
    readonly diff: i0.InputSignal<ConfigDiffData | null>;
    protected isEmpty(d: ConfigDiffData | null): boolean;
    /** Wert lesbar machen (Objekte als JSON; null/undefined als »—«). */
    protected fmt(value: unknown): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<ConfigDiffComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ConfigDiffComponent, "app-config-diff", never, { "diff": { "alias": "diff"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

interface Step {
    label: string;
}
/** Fortschrittsanzeige für den Antrags-Wizard (N1a Multi-Step). */
declare class StepperComponent {
    steps: Step[];
    activeIndex: number;
    ariaLabel: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<StepperComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<StepperComponent, "app-stepper", never, { "steps": { "alias": "steps"; "required": false; }; "activeIndex": { "alias": "activeIndex"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Modaler Dialog. Schließt per Backdrop-Klick, Schließen-Button oder ESC.
 *
 * a11y (T-43, WCAG 2.1.2/2.4.3): Beim Öffnen wandert der Fokus in den Dialog,
 * Tab/Shift+Tab werden im Dialog gefangen (Focus-Trap), beim Schließen kehrt der
 * Fokus auf das auslösende Element zurück. `aria-modal`/`role="dialog"` +
 * `aria-labelledby` sind gesetzt.
 */
declare class DialogComponent implements OnChanges, OnDestroy {
    open: boolean;
    title: string;
    closeLabel: string;
    /** Breite: 'md' (32rem, Default) oder 'lg' (44rem, z. B. Charts). */
    size: 'md' | 'lg';
    closed: EventEmitter<void>;
    private pane?;
    readonly titleId: string;
    /** Element, das vor dem Öffnen den Fokus hatte — für Restore beim Schließen. */
    private previouslyFocused;
    /** Body-Scroll-Sperre: gemerkter vorheriger overflow-Wert für den Restore. */
    private prevBodyOverflow;
    private dragStartY;
    private dragStartT;
    private dragging;
    private dragDy;
    ngOnChanges(changes: SimpleChanges): void;
    ngOnDestroy(): void;
    onEscape(): void;
    /** Tab/Shift+Tab im Dialog halten (Focus-Trap). */
    onKeydown(event: KeyboardEvent): void;
    onBackdrop(_event: MouseEvent): void;
    onDragStart(event: TouchEvent): void;
    onDragMove(event: TouchEvent): void;
    onDragEnd(event: TouchEvent): void;
    close(): void;
    private lockScroll;
    private unlockScroll;
    /** Vorherigen Fokus merken und Fokus in den Dialog setzen (nach Render). */
    private captureAndFocus;
    private restoreFocus;
    private focusable;
    static ɵfac: i0.ɵɵFactoryDeclaration<DialogComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DialogComponent, "app-dialog", never, { "open": { "alias": "open"; "required": false; }; "title": { "alias": "title"; "required": false; }; "closeLabel": { "alias": "closeLabel"; "required": false; }; "size": { "alias": "size"; "required": false; }; }, { "closed": "closed"; }, never, ["*", "[dialog-footer]"], true, never>;
}

interface Column<T> {
    key: keyof T & string;
    label: string;
    align?: 'start' | 'end';
}
/** Schlanke, datengetriebene Tabelle. Für komplexe Fälle später erweiterbar. */
declare class TableComponent<T extends Record<string, unknown>> {
    columns: Column<T>[];
    rows: T[];
    caption: string;
    emptyText: string;
    static ɵfac: i0.ɵɵFactoryDeclaration<TableComponent<any>, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<TableComponent<any>, "app-table", never, { "columns": { "alias": "columns"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "caption": { "alias": "caption"; "required": false; }; "emptyText": { "alias": "emptyText"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Markiert ein `<ng-template>` als ausklappbare Detail-Zeile der
 * {@link DataTableComponent}: `<ng-template appRowDetail let-row>…`. Wird je
 * Zeile gerendert, für die `isExpanded(row)` true ist (volle Breite darunter).
 */
declare class RowDetailDirective {
    readonly tpl: TemplateRef<{
        $implicit: unknown;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<RowDetailDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<RowDetailDirective, "[appRowDetail]", never, {}, {}, never, never, true, never>;
}

/** Column definition of the {@link DataTableComponent}. */
interface ColumnDef {
    key: string;
    label: string;
    align?: 'start' | 'end';
    /**
     * Wie breit die Spalte sein soll, als UNTERGRENZE statt als Vorschlag.
     *
     * `width` allein ist bei `table-layout: auto` nur ein Wunsch: der Browser darf die
     * Spalte kleiner rechnen, wenn andere mehr fordern. Eine mit `22rem` angeforderte
     * Namensspalte landete gemessen bei 107px und brach um. Zusammen mit `min-width`
     * bleibt die Breite stehen und die Tabelle scrollt stattdessen — wofür die
     * Aktionsspalte `sticky: 'end'` bekommt.
     */
    width?: string;
    /**
     * What this column becomes when the table stacks into cards below the mobile
     * breakpoint.
     *
     * A card is not a table row turned on its side. Stacking every column gives a label
     * and a value per column, so a nine-column table becomes a nine-line card: the
     * checkbox on a line of its own, a placeholder dash on a line of its own, and no
     * heading a reader can scan. Declaring a role per column keeps the card to what
     * identifies the record.
     *
     * * `title` — the card's heading: full width, left aligned, no label. Pick the column
     *   that says WHICH record this is.
     * * `hidden` — left out of the card. For a column that is redundant once the others
     *   are visible, or is a placeholder on most rows.
     * * `row` (the default) — the label/value pair.
     *
     * A table that declares nothing keeps the previous behaviour, where the first data
     * column becomes the heading.
     */
    card?: 'title' | 'row' | 'hidden';
    /** Renders the header as a sort control and emits `sortChange` on click. */
    sortable?: boolean;
    /**
     * Direction a FIRST click on this column asks for. Defaults to ascending, which is
     * what a name or a key wants; a date or an amount usually wants the largest first,
     * so those columns set `desc`.
     */
    initialSort?: 'asc' | 'desc';
    /**
     * Pins the column to the trailing edge while the table scrolls sideways.
     *
     * For the actions column of a wide table: edit and delete stay reachable instead of
     * sitting past the right edge, where a reader has to scroll to find them and scroll
     * back to see which row they belong to. Below the mobile breakpoint the table stacks
     * into cards and nothing scrolls sideways, so the pin lifts by itself.
     *
     * Pin ONE column at most, and pin it last: two pinned columns would overlap, because
     * each one is offset from the same edge.
     */
    sticky?: 'end';
}
/** Which column a table is sorted by, and in which direction. */
interface SortState {
    key: string;
    direction: 'asc' | 'desc';
}
/**
 * Shared, data-driven table. Columns come as a {@link ColumnDef} list; a single
 * cell can be rendered freely with `<ng-template appCell="key" let-row>` (badges,
 * buttons, links). Without a template the cell shows `row[key]` as text. Boxed by
 * default, optionally with row clicks.
 *
 * This keeps every table visually consistent — one source for the header, the border,
 * the hover, the empty state, the loading state and the sort affordance — instead of
 * each page building its own `<table>`.
 *
 * **Loading:** set `loading` while data is in flight. The table keeps its header and
 * column widths and draws skeleton rows. It deliberately does NOT collapse to the empty
 * state, because "nothing here" and "not here yet" mean different things to a reader.
 */
declare class DataTableComponent implements AfterContentInit, AfterViewInit, AfterViewChecked, OnChanges, OnDestroy {
    columns: ColumnDef[];
    rows: readonly unknown[];
    emptyText: string;
    boxed: boolean;
    /** Stable track key per row (index otherwise). */
    rowKey?: (row: unknown, index: number) => unknown;
    /** Makes rows clickable (cursor/tab/enter) and emits `rowClick`. */
    clickable: boolean;
    rowClick: EventEmitter<unknown>;
    /** Predicate: which rows show their detail row. */
    isExpanded?: (row: unknown) => boolean;
    /** Draws skeleton rows instead of the body, keeping the header in place. */
    loading: boolean;
    /** How many skeleton rows to draw. Match it to the usual page size. */
    skeletonRowCount: number;
    /** Announced to a screen reader while `loading`, because the skeleton is hidden. */
    loadingText: string;
    /**
     * Adds a leading checkbox column and makes rows selectable.
     *
     * The table owns the selection rather than the caller wiring a column of its own,
     * because a hand-built checkbox column has to agree with `rowKey`, with the header's
     * select-all, and with the skeleton — and every table that built one got at least one
     * of those subtly different.
     */
    selectable: boolean;
    /** The selected rows, as `rowKey` values. */
    selected: ReadonlySet<unknown>;
    /** Emits the next selection. The caller holds it; the table never mutates the input. */
    selectedChange: EventEmitter<Set<unknown>>;
    /** Accessible name for the select-all checkbox in the header. */
    selectAllLabel: string;
    /** Accessible name for one row's checkbox. Falls back to the row's position. */
    rowSelectLabel?: (row: unknown, index: number) => string;
    /**
     * Child rows of one row, rendered directly under it with the SAME columns.
     *
     * Different from `appRowDetail`, which renders one full-width cell for a panel. A
     * child here is another record of the same shape — a sub-booking under its booking —
     * so it reuses the caller's `appCell` templates and lines up with the parent column
     * for column. The template context carries `child: true`, so a cell can render a child
     * differently without the caller writing the column twice.
     */
    childrenOf?: (row: unknown) => readonly unknown[];
    /** Extra class per row, for a state the table cannot know about. */
    rowClass?: (row: unknown, child: boolean) => string | null;
    /** Current sort, or `undefined` when the table is unsorted. */
    sort?: SortState;
    /** Emits the next sort state when a sortable header is clicked. */
    sortChange: EventEmitter<SortState>;
    private cellDirs;
    private footDirs;
    protected rowDetail?: RowDetailDirective;
    private scroller?;
    private box?;
    private endTongue?;
    private readonly zone;
    private readonly cellMap;
    private readonly footMap;
    /**
     * True while the scroll container still hides a column past that edge — the condition
     * for showing the tongue that scrolls that way.
     */
    protected readonly hiddenStart: i0.WritableSignal<boolean>;
    protected readonly hiddenEnd: i0.WritableSignal<boolean>;
    /**
     * True while a tongue is hovered or focused, which lights the cut it moves towards.
     *
     * One flag per side, not one shared: a shared flag lit the far cut while the reader
     * pointed at the near tongue.
     */
    protected readonly cutHot: i0.WritableSignal<boolean>;
    protected readonly cutHotStart: i0.WritableSignal<boolean>;
    /** Which tongue is held down, for its pressed colour. */
    protected readonly held: i0.WritableSignal<0 | 1 | -1>;
    private holdTimer?;
    private holdTick?;
    private readonly teardown;
    /** Long-press state. `pressSelected` swallows the click a completed press produces. */
    private pressTimer?;
    private pressOrigin;
    private pressWasTouch;
    private pressSelected;
    /**
     * Last sideways position, for a redraw that empties the table. Written only while the
     * content overflows: the clamp to 0 that comes with an empty table arrives as a scroll
     * event and would otherwise store the 0 it caused.
     */
    private keptScrollLeft;
    /** True between the rows coming back and the scroll position being put back. */
    private restorePending;
    /** Whether the table was in the DOM at the previous check. */
    private wasRendering;
    /** Pixel fallback applies only after the table left the DOM, never on a row change. */
    private restoreFromPixels;
    /**
     * Column at the left edge and how far it is cut off, taken before a redraw.
     * `table-layout: auto` re-measures columns from the new rows, so a pixel offset lands
     * on a different column.
     */
    private anchor;
    /** Runs before the redraw, so the geometry is still the old layout. */
    ngOnChanges(changes: SimpleChanges): void;
    ngAfterContentInit(): void;
    protected cellFor(key: string): TemplateRef<unknown> | null;
    protected footCellFor(key: string): TemplateRef<unknown> | null;
    /** True when any column contributes a footer, so `<tfoot>` stays out otherwise. */
    protected get hasFooter(): boolean;
    protected childrenFor(row: unknown): readonly unknown[];
    protected classFor(row: unknown, child: boolean): string | null;
    protected isSelected(row: unknown, index: number): boolean;
    /** True only when every row is selected. An empty table is not "all selected". */
    protected get allSelected(): boolean;
    /** True when some but not all are selected, for the header's indeterminate state. */
    protected get someSelected(): boolean;
    protected toggleRow(row: unknown, index: number): void;
    /** Select-all applies to the rows ON SCREEN, which is what the checkbox sits above. */
    protected toggleAll(): void;
    protected selectLabel(row: unknown, index: number): string;
    /**
     * Total column count, for a `colspan` that has to span the whole table.
     *
     * The selection column is not in `columns`, so anything spanning the table has to add
     * it back or the detail row comes up one cell short.
     */
    protected get columnSpan(): number;
    protected text(row: unknown, key: string): unknown;
    protected trackRow(row: unknown, index: number): unknown;
    /**
     * A tap opens the row, unless a selection is under way.
     *
     * Touch only: on a pointer device the checkbox is the way in, and a click that
     * sometimes opened and sometimes selected would be unpredictable.
     */
    protected onRow(row: unknown, index: number): void;
    /** Start the press timer. A mouse is left alone; it has the checkbox. */
    protected onRowPressStart(event: PointerEvent, row: unknown, index: number): void;
    /** A finger that travels is scrolling the list, not holding a row. */
    protected onRowPressMove(event: PointerEvent): void;
    protected cancelPress(): void;
    /** A plain index list, so the template can repeat the skeleton row. */
    protected skeletonRows(): number[];
    /**
     * Toggle the sort for one column.
     *
     * A new column starts at its own `initialSort`; clicking the active column flips it.
     */
    protected toggleSort(col: ColumnDef): void;
    /** `aria-sort` for one header, so the sort is announced and not only drawn. */
    protected ariaSort(col: ColumnDef): 'ascending' | 'descending' | 'none' | null;
    /** True when a column asks to be pinned, which is what puts a cut in the table. */
    protected get hasSticky(): boolean;
    /**
     * Width of the trailing pinned column: how far the cut sits in from the edge.
     *
     * NOT rounded. A column is often a fractional width — 206.5px measured — and rounding
     * moved the cut half a pixel off the column it marks, leaving a sliver of scrolling
     * content between the two. CSS takes the fraction.
     */
    private stickyWidth;
    /** Width of the leading pinned column, if the table has one. Not rounded, as above. */
    private stickyStartWidth;
    /**
     * Which edges still hide a column, measured rather than computed.
     *
     * NOT `scrollLeft < scrollWidth - clientWidth`. `.dt__scroll` sets
     * `scrollbar-gutter: stable`, so `scrollWidth - clientWidth` overshoots the maximum
     * the browser actually clamps `scrollLeft` to, by the width of the gutter: measured at
     * 612 against a real maximum of 597 on an 820px viewport, a 15px overshoot that no
     * one-pixel slack can absorb. The end cue then never switched off at full scroll.
     *
     * Geometry answers the question the cue really asks — does a column still stick out
     * past the cut? — and asks it of the same boxes the reader is looking at.
     */
    private occluded;
    /**
     * Height of the horizontal scrollbar, so nothing is drawn over it.
     *
     * Measured, never assumed: it is 0 on a table that fits, about 15px where a scrollbar
     * shows, and a different number again on another platform.
     */
    private gutter;
    /**
     * Centre of the VISIBLE slice of the scroller, in the scroller's own space.
     *
     * The middle of the box is the wrong place on a long table: it leaves the tongues off
     * screen exactly while the reader needs them. Two corrections, both about the bottom
     * edge — the area that counts is the ROWS, so the scrollbar gutter comes off before
     * anything is measured, and the result is then clamped by half a tongue, so a thin
     * visible slice can never push the tongue itself down onto the scrollbar.
     */
    private visibleCentre;
    /** Recompute which edges hide content, and where the cut and the tongues belong. */
    protected onScroll(): void;
    /** `cut` is how much of the column has passed the edge. */
    private captureAnchor;
    /**
     * A frame later and outside Angular: widths exist only after layout, and setting the
     * cue signals from a lifecycle hook trips ExpressionChangedAfterItHasBeenChecked.
     */
    private restoreScroll;
    /** One step sideways. Instant where the reader asked for less motion. */
    private step;
    /**
     * Press to step, hold to keep going.
     *
     * A reader who does not know shift+scroll should not have to click fifteen times to
     * cross a wide table.
     */
    protected onTonguePress(event: MouseEvent, direction: -1 | 1): void;
    /** Release, leave or cancel: the repeat stops with the gesture that started it. */
    protected stopHold(): void;
    /**
     * Enter and Space step once and do not repeat: the key repeat of the platform already
     * does that, and two repeats would race.
     */
    protected onTongueKey(event: KeyboardEvent, direction: -1 | 1): void;
    ngAfterViewInit(): void;
    /** The template draws the table under `loading || rows.length`; watch that edge. */
    ngAfterViewChecked(): void;
    ngOnDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<DataTableComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<DataTableComponent, "app-data-table", never, { "columns": { "alias": "columns"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "emptyText": { "alias": "emptyText"; "required": false; }; "boxed": { "alias": "boxed"; "required": false; }; "rowKey": { "alias": "rowKey"; "required": false; }; "clickable": { "alias": "clickable"; "required": false; }; "isExpanded": { "alias": "isExpanded"; "required": false; }; "loading": { "alias": "loading"; "required": false; }; "skeletonRowCount": { "alias": "skeletonRowCount"; "required": false; }; "loadingText": { "alias": "loadingText"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "selectAllLabel": { "alias": "selectAllLabel"; "required": false; }; "rowSelectLabel": { "alias": "rowSelectLabel"; "required": false; }; "childrenOf": { "alias": "childrenOf"; "required": false; }; "rowClass": { "alias": "rowClass"; "required": false; }; "sort": { "alias": "sort"; "required": false; }; }, { "rowClick": "rowClick"; "selectedChange": "selectedChange"; "sortChange": "sortChange"; }, ["rowDetail", "cellDirs", "footDirs"], never, true, never>;
}

/**
 * Markiert ein `<ng-template>` als Zell-Renderer einer Spalte der
 * {@link DataTableComponent}: `<ng-template appCell="status" let-row>…`.
 * Der `let-row`-Kontext ist die jeweilige Zeile.
 */
declare class CellDirective {
    /** Spalten-Key, für den dieses Template gerendert wird. */
    key: string;
    readonly tpl: TemplateRef<{
        $implicit: unknown;
        index: number;
    }>;
    static ɵfac: i0.ɵɵFactoryDeclaration<CellDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<CellDirective, "[appCell]", never, { "key": { "alias": "appCell"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Marks an `<ng-template>` as the FOOTER cell of one column of the
 * {@link DataTableComponent}: `<ng-template appFootCell="amount">…`.
 *
 * Per column rather than one projected `<tr>`, for the same reason `appCell` is per
 * column: a caller writing the whole row has to keep its cell count in step with the
 * column list by hand, and a mismatch is invisible until the table is on screen.
 *
 * A column with no footer template gets an empty cell, so a total can sit under the one
 * column it belongs to without the caller filling in the rest.
 */
declare class FootCellDirective {
    /** Column key this template renders the footer cell for. */
    key: string;
    readonly tpl: TemplateRef<Record<string, never>>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FootCellDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FootCellDirective, "[appFootCell]", never, { "key": { "alias": "appFootCell"; "required": false; }; }, {}, never, never, true, never>;
}

/**
 * Einheitliches Währungs-Eingabefeld. Überall gleiche Optik:
 * rechtsbündig, Tausender-Gruppierung + 2 Nachkommastellen, „€"-Suffix.
 *
 * `ControlValueAccessor` → per `[(ngModel)]` nutzbar. Das **Modell** ist stets ein
 * kanonischer Dezimal-String mit Punkt (`"1234.56"`, parsebar fürs Backend) bzw.
 * `''` für leer. Die **Anzeige** ist lokalisiert (de `1.234,56`, en `1,234.56`):
 * beim Fokus editierbar (ohne Gruppierung), beim Verlassen formatiert.
 */
declare class CurrencyInputComponent implements ControlValueAccessor {
    private readonly intl;
    readonly placeholder: i0.InputSignal<string>;
    readonly ariaLabel: i0.InputSignal<string>;
    readonly name: i0.InputSignal<string>;
    /** Optionales Feld-Label; gesetzt → volle Feld-Optik (Label/Hint/Error),
     *  leer → blankes Control (für eigene Label-Wrapper, z. B. Filter/Dialoge). */
    readonly label: i0.InputSignal<string>;
    readonly hint: i0.InputSignal<string>;
    readonly error: i0.InputSignal<string>;
    readonly required: i0.InputSignal<boolean>;
    /** Sichtbarer Text (formatiert oder beim Tippen roh). */
    protected readonly text: i0.WritableSignal<string>;
    protected readonly disabled: i0.WritableSignal<boolean>;
    /** Kanonischer Wert (Punkt-Dezimal, ohne Gruppierung) — das Modell. */
    private canonical;
    private focused;
    private onChange;
    private onTouched;
    writeValue(value: string | number | null): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    protected onFocus(): void;
    protected onInput(raw: string): void;
    protected onBlur(): void;
    private get decimalSep();
    /** Roh-Eingabe → kanonischer Punkt-Dezimal-String (oder ''). */
    private parse;
    /** Beliebigen Wert (Backend-Punkt oder lokal) → kanonisch. */
    private toCanonical;
    /** Kanonisch → editierbarer Text (lokaler Dezimaltrenner, keine Gruppierung). */
    private toEditable;
    /** Kanonisch → lokalisiert formatiert (1.234,56) mit 2 Nachkommastellen. */
    private format;
    static ɵfac: i0.ɵɵFactoryDeclaration<CurrencyInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<CurrencyInputComponent, "app-currency-input", never, { "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; "isSignal": true; }; "name": { "alias": "name"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "hint": { "alias": "hint"; "required": false; "isSignal": true; }; "error": { "alias": "error"; "required": false; "isSignal": true; }; "required": { "alias": "required"; "required": false; "isSignal": true; }; }, {}, never, never, true, never>;
}

/**
 * Globaler Ladebildschirm: halbtransparenter Overlay über dem Inhaltsbereich
 * (unterhalb des Headers) mit zentriertem Spinner, gesteuert über den
 * {@link UI_KIT_LOADING}-Token (vom Host an seinen Lade-Service gebunden).
 * Header/Navigation bleiben bedienbar. Liegt unter Dialogen/Toasts (z-index),
 * damit diese darüber sichtbar bleiben.
 */
declare class LoadingOverlayComponent {
    protected readonly loading: _stupa_makers_ui_kit.UiKitLoadingState;
    static ɵfac: i0.ɵɵFactoryDeclaration<LoadingOverlayComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<LoadingOverlayComponent, "app-loading-overlay", never, {}, {}, never, never, true, never>;
}

/**
 * Einheitlicher Filter-Balken für Listen. Ein sekundärer Button
 * (Trichter-Icon + Label + Aktiv-Zähler) öffnet ein rechtsbündiges Popover; die
 * eigentlichen Filter-Felder werden projiziert (`<app-filter-field>` /
 * `<app-filter-range>`). Schließt bei Klick außerhalb und Escape.
 *
 * Zwei Modi:
 * - **Apply** (Default): Popover zeigt „Anwenden" + „Zurücksetzen"; der Konsument
 *   übernimmt die Werte erst bei `(apply)`.
 * - **Live** (`[live]="true"`): keine Anwenden-Taste — Felder wirken sofort (der
 *   Konsument bindet direkt). Nur „Zurücksetzen" erscheint bei aktiven Filtern.
 */
declare class FilterBarComponent {
    private readonly host;
    /** Anzahl aktiver Filter (Badge); 0 blendet den Zähler aus. */
    readonly activeCount: i0.InputSignal<number>;
    /** Button-Label; leer = i18n-Default „Filter". */
    readonly label: i0.InputSignal<string>;
    /** Live-Modus: keine „Anwenden"-Taste (Felder wirken sofort). */
    readonly live: i0.InputSignal<boolean>;
    readonly applyLabel: i0.InputSignal<string>;
    readonly resetLabel: i0.InputSignal<string>;
    /** „Anwenden" geklickt (Apply-Modus). Schließt das Popover. */
    readonly apply: i0.OutputEmitterRef<void>;
    /** „Zurücksetzen" geklickt. */
    readonly reset: i0.OutputEmitterRef<void>;
    /** Offen-Zustand geändert (z. B. zum Re-Fokus). */
    readonly openChange: i0.OutputEmitterRef<boolean>;
    protected readonly open: i0.WritableSignal<boolean>;
    /** True, wenn das Popover geöffnet ist (für Konsumenten via Template-Ref). */
    readonly isOpen: i0.Signal<boolean>;
    toggle(): void;
    close(): void;
    protected emitApply(): void;
    protected emitReset(): void;
    private setOpen;
    protected onDocumentClick(event: MouseEvent): void;
    protected onEscape(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterBarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterBarComponent, "app-filter-bar", never, { "activeCount": { "alias": "activeCount"; "required": false; "isSignal": true; }; "label": { "alias": "label"; "required": false; "isSignal": true; }; "live": { "alias": "live"; "required": false; "isSignal": true; }; "applyLabel": { "alias": "applyLabel"; "required": false; "isSignal": true; }; "resetLabel": { "alias": "resetLabel"; "required": false; "isSignal": true; }; }, { "apply": "apply"; "reset": "reset"; "openChange": "openChange"; }, never, ["*"], true, never>;
}

/**
 * Ein Filter-Feld im {@link FilterBarComponent}-Popover: Label + projizierte
 * Steuerung (native input/select oder `<app-select>`). Einheitliche Optik für
 * alle Listen. Controls erben `.filter-field__control`-Styling über `::ng-deep`,
 * sodass Konsumenten nur ihr Control projizieren müssen.
 */
declare class FilterFieldComponent {
    /** Sichtbares Label über dem Control. */
    readonly label: i0.InputSignal<string>;
    /**
     * Der Inhalt ist eine GRUPPE von Controls statt eines einzelnen.
     *
     * Ein `<label>` verbindet sich mit dem ersten Control darin. Bei einem Segment-Filter
     * heißt der erste Knopf dann wie das Feld statt wie er selbst — gemessen kam eine
     * Gruppe als "Archiv Nur archivierte Alle" heraus, der eigene Name des ersten Knopfs
     * fehlte. Mit `group` wird das Set über `role="group"` benannt.
     */
    readonly group: i0.InputSignal<boolean>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterFieldComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterFieldComponent, "app-filter-field", never, { "label": { "alias": "label"; "required": false; "isSignal": true; }; "group": { "alias": "group"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

/**
 * Min/Max- bzw. Von/Bis-Bereich im Filter-Popover: zwei projizierte Controls mit
 * einem Trenner dazwischen. Slots: `[start]` und `[end]`.
 *
 * ```html
 * <app-filter-range>
 *   <input start type="date" … />
 *   <input end type="date" … />
 * </app-filter-range>
 * ```
 */
declare class FilterRangeComponent {
    /** Trennzeichen zwischen den beiden Controls. */
    readonly separator: i0.InputSignal<string>;
    static ɵfac: i0.ɵɵFactoryDeclaration<FilterRangeComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<FilterRangeComponent, "app-filter-range", never, { "separator": { "alias": "separator"; "required": false; "isSignal": true; }; }, {}, never, ["[start]", "[end]"], true, never>;
}

type ToastVariant = 'info' | 'success' | 'warning' | 'danger';
interface Toast {
    id: number;
    message: string;
    variant: ToastVariant;
}
/** Globaler Toast-Hub. Komponenten rufen `show()`, der Container rendert. */
declare class ToastService {
    private readonly _toasts;
    readonly toasts: i0.Signal<Toast[]>;
    /** Zeigt einen Toast; `timeout=0` deaktiviert das automatische Schließen. */
    show(message: string, variant?: ToastVariant, timeout?: number): number;
    success(message: string): number;
    error(message: string): number;
    dismiss(id: number): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastService, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<ToastService>;
}

/** Toast-Container — einmal im Shell-Layout platziert. ARIA-Live-Region. */
declare class ToastComponent {
    readonly toastService: ToastService;
    static ɵfac: i0.ɵɵFactoryDeclaration<ToastComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<ToastComponent, "app-toast", never, {}, {}, never, never, true, never>;
}

export { BadgeComponent, ButtonComponent, CardComponent, CellDirective, CheckboxComponent, ConfigDiffComponent, CurrencyInputComponent, DataTableComponent, DateRangeComponent, DatepickerComponent, DefaultUiKitIntl, DialogComponent, FilterBarComponent, FilterFieldComponent, FilterRangeComponent, FootCellDirective, IconComponent, InputComponent, LoadingOverlayComponent, RowDetailDirective, SelectComponent, StepperComponent, TableComponent, TimeInputComponent, ToastComponent, ToastService, UI_KIT_DEFAULT_MESSAGES, UI_KIT_INTL, UI_KIT_LOADING, UiKitTranslatePipe, provideUiKit, uiKitIntlFromLang };
export type { BadgeVariant, ButtonSize, ButtonVariant, Column, ColumnDef, ConfigDiffData, ConfigDiffEntry, ConfigFieldChange, DateRange, IconName, SelectOption, SortState, Step, Toast, ToastVariant, UiKitIntl, UiKitIntlOptions, UiKitLoadingState, UiKitMessages, UiKitTextKey, UiLang };
