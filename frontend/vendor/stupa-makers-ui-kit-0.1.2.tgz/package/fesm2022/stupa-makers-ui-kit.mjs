import * as i0 from '@angular/core';
import { signal, InjectionToken, makeEnvironmentProviders, inject, Pipe, Input, HostBinding, ChangeDetectionStrategy, Component, viewChild, computed, effect, input, EventEmitter, HostListener, ViewChild, Output, TemplateRef, Directive, NgZone, ContentChild, ContentChildren, ElementRef, output, Injectable } from '@angular/core';
import * as i1 from '@angular/forms';
import { NG_VALUE_ACCESSOR, FormsModule } from '@angular/forms';
import { NgTemplateOutlet } from '@angular/common';

/** Built-in DE/EN strings — the kit renders identically out of the box. */
const UI_KIT_DEFAULT_MESSAGES = {
    de: {
        'dialog.close': 'Schließen',
        loading: 'Wird geladen…',
        'datepicker.openCalendar': 'Kalender öffnen',
        'filter.button': 'Filter',
        'filter.apply': 'Anwenden',
        'filter.reset': 'Zurücksetzen',
        'diff.none': 'Keine Feldänderungen.',
        'diff.changed': 'Geändert',
        'diff.added': 'Hinzugefügt',
        'diff.removed': 'Entfernt',
        'table.scrollStart': 'Tabelle nach links scrollen',
        'table.scrollEnd': 'Tabelle nach rechts scrollen',
    },
    en: {
        'dialog.close': 'Close',
        loading: 'Loading…',
        'datepicker.openCalendar': 'Open calendar',
        'filter.button': 'Filter',
        'filter.apply': 'Apply',
        'filter.reset': 'Reset',
        'diff.none': 'No field changes.',
        'diff.changed': 'Changed',
        'diff.added': 'Added',
        'diff.removed': 'Removed',
        'table.scrollStart': 'Scroll the table left',
        'table.scrollEnd': 'Scroll the table right',
    },
};
const DEFAULT_LANG = 'de';
function detectLang() {
    if (typeof navigator === 'undefined')
        return DEFAULT_LANG;
    return navigator.language.slice(0, 2).toLowerCase() === 'en' ? 'en' : 'de';
}
function interpolate(text, params) {
    if (!params)
        return text;
    return text.replace(/\{(\w+)\}/g, (match, name) => name in params ? String(params[name]) : match);
}
/**
 * Default {@link UiKitIntl}: ships the built-in DE/EN catalogue. Language follows an
 * injected signal when given (so it tracks the host app's locale), otherwise an
 * internal signal seeded from the browser and settable via {@link setLang}.
 */
class DefaultUiKitIntl {
    constructor(options = {}) {
        this.internalLang = signal(detectLang(), ...(ngDevMode ? [{ debugName: "internalLang" }] : []));
        this.lang = options.lang ?? this.internalLang.asReadonly();
        this.messages = {
            de: { ...UI_KIT_DEFAULT_MESSAGES.de, ...(options.messages?.de ?? {}) },
            en: { ...UI_KIT_DEFAULT_MESSAGES.en, ...(options.messages?.en ?? {}) },
        };
    }
    /** Set the language. Only effective when no external `lang` signal was provided. */
    setLang(lang) {
        this.internalLang.set(lang);
    }
    translate(key, params) {
        const raw = this.messages[this.lang()][key] ?? this.messages[DEFAULT_LANG][key] ?? key;
        return interpolate(raw, params);
    }
}
/** DI token for the kit's i18n. Defaults to a built-in DE/EN {@link DefaultUiKitIntl}. */
const UI_KIT_INTL = new InjectionToken('UI_KIT_INTL', {
    providedIn: 'root',
    factory: () => new DefaultUiKitIntl(),
});
/** Build a {@link UiKitIntl} whose language tracks the given signal (e.g. an app locale). */
function uiKitIntlFromLang(lang, messages) {
    return new DefaultUiKitIntl({ lang, messages });
}
/**
 * Register the kit's i18n. Pass a ready {@link UiKitIntl} via `intl`, or `lang`/`messages`
 * to configure the default implementation. With no argument the built-in catalogue is used.
 */
function provideUiKit(options = {}) {
    return makeEnvironmentProviders([
        {
            provide: UI_KIT_INTL,
            useFactory: () => options.intl ?? new DefaultUiKitIntl(options),
        },
    ]);
}

/**
 * `{{ 'dialog.close' | uiKitT }}` — impure so a language switch propagates immediately
 * (the active language is a signal on the {@link UiKitIntl}).
 */
class UiKitTranslatePipe {
    constructor() {
        this.intl = inject(UI_KIT_INTL);
    }
    transform(key, params) {
        return this.intl.translate(key, params);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: UiKitTranslatePipe, deps: [], target: i0.ɵɵFactoryTarget.Pipe }); }
    static { this.ɵpipe = i0.ɵɵngDeclarePipe({ minVersion: "14.0.0", version: "20.3.25", ngImport: i0, type: UiKitTranslatePipe, isStandalone: true, name: "uiKitT", pure: false }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: UiKitTranslatePipe, decorators: [{
            type: Pipe,
            args: [{ name: 'uiKitT', standalone: true, pure: false }]
        }] });

const NEVER_VISIBLE = { visible: signal(false).asReadonly() };
/**
 * DI token feeding the loading overlay. Defaults to never-visible (no-op); the host app
 * provides one delegating to its own loading service, e.g.
 * `{ provide: UI_KIT_LOADING, useFactory: () => ({ visible: inject(LoadingService).visible }) }`.
 */
const UI_KIT_LOADING = new InjectionToken('UI_KIT_LOADING', {
    providedIn: 'root',
    factory: () => NEVER_VISIBLE,
});

/** Basis-Button des UI-Kits. Clean/minimal, CD-Tokens, a11y-Fokus. */
class ButtonComponent {
    constructor() {
        this.variant = 'primary';
        /** Frei wählbare Hintergrundfarbe (Hex); überschreibt die Variante. */
        this.color = null;
        this.size = 'md';
        this.type = 'button';
        this.disabled = false;
        this.loading = false;
        /** Quadratischer Icon-Button (gleiche Höhe/Breite) für einzelne Glyphs (✕ ↑ ↓). */
        this.iconOnly = false;
        /** Volle Breite des Containers (gestapelte Aktionen gleicher Breite). */
        this.block = false;
        /** Barrierefreier Name — Pflicht für Icon-Buttons ohne sichtbaren Text. */
        this.ariaLabel = '';
        /**
         * Toggle-Zustand für einen Button, der an/aus ist — etwa ein Segment in einer
         * Filtergruppe. Ohne das unterscheidet nur die `variant`-Farbe den aktiven Eintrag,
         * und eine Vorlesehilfe hört drei gleich benannte Buttons ohne Zustand.
         */
        this.ariaPressed = null;
        /** Hover-Tooltip; bei Icon-Buttons fällt er automatisch auf `ariaLabel` zurück. */
        this.title = '';
    }
    /** Tooltip-Text: explizit gesetzt, sonst für Icon-Buttons der `ariaLabel`. */
    tooltip() {
        return this.title || (this.iconOnly ? this.ariaLabel : '') || null;
    }
    /** Lesbare Textfarbe (schwarz/weiß) zur gewählten `color` per WCAG-Luminanz. */
    contrastColor() {
        const hex = (this.color ?? '').trim().replace('#', '');
        const full = hex.length === 3
            ? hex
                .split('')
                .map((c) => c + c)
                .join('')
            : hex;
        if (full.length !== 6)
            return '#ffffff';
        const channel = (i) => {
            const v = parseInt(full.slice(i, i + 2), 16) / 255;
            return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
        };
        const lum = 0.2126 * channel(0) + 0.7152 * channel(2) + 0.0722 * channel(4);
        return lum > 0.4 ? '#111111' : '#ffffff';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: ButtonComponent, isStandalone: true, selector: "app-button", inputs: { variant: "variant", color: "color", size: "size", type: "type", disabled: "disabled", loading: "loading", iconOnly: "iconOnly", block: "block", ariaLabel: "ariaLabel", ariaPressed: "ariaPressed", title: "title" }, host: { properties: { "class.btn-block": "this.block" } }, ngImport: i0, template: "<button\n  [type]=\"type\"\n  [disabled]=\"disabled || loading\"\n  [attr.aria-busy]=\"loading ? 'true' : null\"\n  [attr.aria-label]=\"ariaLabel || null\"\n  [attr.aria-pressed]=\"ariaPressed === null ? null : ariaPressed\"\n  [attr.title]=\"tooltip()\"\n  [class]=\"'btn btn--' + variant + ' btn--' + size + (iconOnly ? ' btn--icon' : '')\"\n  [class.btn--custom]=\"!!color\"\n  [style.background]=\"color || null\"\n  [style.color]=\"color ? contrastColor() : null\"\n>\n  @if (loading) {\n    <span class=\"btn__spinner\" aria-hidden=\"true\"></span>\n  }\n  <span class=\"btn__label\" [class.btn__label--loading]=\"loading\"><ng-content /></span>\n</button>\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}:host(.btn-block){display:flex}:host(.btn-block) .btn{width:100%}.btn{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);font-weight:var(--fw-semibold);line-height:1;border:var(--border-width) solid transparent;border-radius:var(--radius-md);cursor:pointer;white-space:nowrap;max-width:100%;min-width:0;transition:background-color var(--motion-fast) var(--ease-standard),color var(--motion-fast) var(--ease-standard),border-color var(--motion-fast) var(--ease-standard)}.btn:disabled{opacity:.4;cursor:not-allowed;box-shadow:none;filter:grayscale(.4)}.btn--sm{padding:var(--space-2) var(--space-3);font-size:var(--fs-sm)}.btn--md{padding:var(--space-3) var(--space-5);font-size:var(--fs-md)}.btn--lg{padding:var(--space-4) var(--space-6);font-size:var(--fs-lg)}.btn--icon{aspect-ratio:1;padding:var(--space-2);line-height:1}.btn--icon.btn--sm{padding:var(--space-1) var(--space-2)}.btn--primary{background:var(--color-primary);color:var(--color-on-primary)}.btn--primary:hover:not(:disabled){background:var(--color-primary-hover)}.btn--primary:active:not(:disabled){background:var(--color-primary-active)}.btn--secondary{background:var(--color-surface);color:var(--color-text);border-color:var(--color-border-strong)}.btn--secondary:hover:not(:disabled){background:var(--color-surface-sunken);border-color:var(--color-text-muted)}.btn--secondary:active:not(:disabled){background:var(--color-border)}.btn--ghost{background:transparent;color:var(--color-primary)}.btn--ghost:hover:not(:disabled){background:var(--color-primary-subtle)}.btn--ghost:active:not(:disabled){background:var(--color-primary-subtle);color:var(--color-primary-active)}.btn--danger{background:var(--color-danger);color:var(--color-text-inverse)}.btn--danger:hover:not(:disabled){filter:brightness(1.08)}.btn--danger:active:not(:disabled){filter:brightness(.94)}.btn--danger-outline{background:var(--color-surface);color:var(--color-danger);border-color:var(--color-danger)}.btn--danger-outline:hover:not(:disabled){background:var(--color-danger-subtle)}.btn--danger-outline:active:not(:disabled){background:var(--color-danger-subtle);filter:brightness(.94)}.btn--success{background:var(--color-success);color:var(--color-text-inverse)}.btn--success:hover:not(:disabled){filter:brightness(1.08)}.btn--success:active:not(:disabled){filter:brightness(.94)}.btn--custom:hover:not(:disabled){filter:brightness(1.08)}.btn--custom:active:not(:disabled){filter:brightness(.94)}.btn__label{overflow:hidden;text-overflow:ellipsis;min-width:0;max-width:100%;line-height:1.3}.btn__spinner{position:absolute;inset:0;margin:auto;width:1em;height:1em;border:2px solid currentColor;border-right-color:transparent;border-radius:var(--radius-pill);animation:btn-spin .6s linear infinite}.btn__label--loading{visibility:hidden}@keyframes btn-spin{to{transform:rotate(360deg)}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-button', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<button\n  [type]=\"type\"\n  [disabled]=\"disabled || loading\"\n  [attr.aria-busy]=\"loading ? 'true' : null\"\n  [attr.aria-label]=\"ariaLabel || null\"\n  [attr.aria-pressed]=\"ariaPressed === null ? null : ariaPressed\"\n  [attr.title]=\"tooltip()\"\n  [class]=\"'btn btn--' + variant + ' btn--' + size + (iconOnly ? ' btn--icon' : '')\"\n  [class.btn--custom]=\"!!color\"\n  [style.background]=\"color || null\"\n  [style.color]=\"color ? contrastColor() : null\"\n>\n  @if (loading) {\n    <span class=\"btn__spinner\" aria-hidden=\"true\"></span>\n  }\n  <span class=\"btn__label\" [class.btn__label--loading]=\"loading\"><ng-content /></span>\n</button>\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex}:host(.btn-block){display:flex}:host(.btn-block) .btn{width:100%}.btn{position:relative;display:inline-flex;align-items:center;justify-content:center;gap:var(--space-2);font-weight:var(--fw-semibold);line-height:1;border:var(--border-width) solid transparent;border-radius:var(--radius-md);cursor:pointer;white-space:nowrap;max-width:100%;min-width:0;transition:background-color var(--motion-fast) var(--ease-standard),color var(--motion-fast) var(--ease-standard),border-color var(--motion-fast) var(--ease-standard)}.btn:disabled{opacity:.4;cursor:not-allowed;box-shadow:none;filter:grayscale(.4)}.btn--sm{padding:var(--space-2) var(--space-3);font-size:var(--fs-sm)}.btn--md{padding:var(--space-3) var(--space-5);font-size:var(--fs-md)}.btn--lg{padding:var(--space-4) var(--space-6);font-size:var(--fs-lg)}.btn--icon{aspect-ratio:1;padding:var(--space-2);line-height:1}.btn--icon.btn--sm{padding:var(--space-1) var(--space-2)}.btn--primary{background:var(--color-primary);color:var(--color-on-primary)}.btn--primary:hover:not(:disabled){background:var(--color-primary-hover)}.btn--primary:active:not(:disabled){background:var(--color-primary-active)}.btn--secondary{background:var(--color-surface);color:var(--color-text);border-color:var(--color-border-strong)}.btn--secondary:hover:not(:disabled){background:var(--color-surface-sunken);border-color:var(--color-text-muted)}.btn--secondary:active:not(:disabled){background:var(--color-border)}.btn--ghost{background:transparent;color:var(--color-primary)}.btn--ghost:hover:not(:disabled){background:var(--color-primary-subtle)}.btn--ghost:active:not(:disabled){background:var(--color-primary-subtle);color:var(--color-primary-active)}.btn--danger{background:var(--color-danger);color:var(--color-text-inverse)}.btn--danger:hover:not(:disabled){filter:brightness(1.08)}.btn--danger:active:not(:disabled){filter:brightness(.94)}.btn--danger-outline{background:var(--color-surface);color:var(--color-danger);border-color:var(--color-danger)}.btn--danger-outline:hover:not(:disabled){background:var(--color-danger-subtle)}.btn--danger-outline:active:not(:disabled){background:var(--color-danger-subtle);filter:brightness(.94)}.btn--success{background:var(--color-success);color:var(--color-text-inverse)}.btn--success:hover:not(:disabled){filter:brightness(1.08)}.btn--success:active:not(:disabled){filter:brightness(.94)}.btn--custom:hover:not(:disabled){filter:brightness(1.08)}.btn--custom:active:not(:disabled){filter:brightness(.94)}.btn__label{overflow:hidden;text-overflow:ellipsis;min-width:0;max-width:100%;line-height:1.3}.btn__spinner{position:absolute;inset:0;margin:auto;width:1em;height:1em;border:2px solid currentColor;border-right-color:transparent;border-radius:var(--radius-pill);animation:btn-spin .6s linear infinite}.btn__label--loading{visibility:hidden}@keyframes btn-spin{to{transform:rotate(360deg)}}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }], size: [{
                type: Input
            }], type: [{
                type: Input
            }], disabled: [{
                type: Input
            }], loading: [{
                type: Input
            }], iconOnly: [{
                type: Input
            }], block: [{
                type: Input
            }, {
                type: HostBinding,
                args: ['class.btn-block']
            }], ariaLabel: [{
                type: Input
            }], ariaPressed: [{
                type: Input
            }], title: [{
                type: Input
            }] } });

let nextId$7 = 0;
/** Textfeld mit Label/Hinweis/Fehler. ControlValueAccessor → Reactive Forms. */
class InputComponent {
    constructor() {
        this.label = '';
        this.type = 'text';
        this.placeholder = '';
        this.hint = '';
        this.error = '';
        this.required = false;
        this.id = `app-input-${nextId$7++}`;
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    get describedBy() {
        if (this.error)
            return `${this.id}-error`;
        if (this.hint)
            return `${this.id}-hint`;
        return null;
    }
    onInput(event) {
        const v = event.target.value;
        this.value.set(v);
        this.onChange(v);
    }
    writeValue(value) {
        this.value.set(value ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: InputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: InputComponent, isStandalone: true, selector: "app-input", inputs: { label: "label", type: "type", placeholder: "placeholder", hint: "hint", error: "error", required: "required", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: InputComponent, multi: true }], ngImport: i0, template: "<div class=\"flex flex-col gap-2\">\n  <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n    {{ label }}\n    @if (required) {\n      <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n    }\n  </label>\n  <input\n    class=\"field__control\"\n    [id]=\"id\"\n    [type]=\"type\"\n    [value]=\"value()\"\n    [disabled]=\"disabled()\"\n    [attr.placeholder]=\"placeholder || null\"\n    [attr.aria-invalid]=\"error ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy\"\n    [attr.required]=\"required ? '' : null\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onTouched()\"\n  />\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: [".field__control{height:var(--control-height);box-sizing:border-box;padding:0 var(--space-4);font-size:var(--fs-md);line-height:var(--lh-normal);color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.field__control:hover:not(:disabled){border-color:var(--color-text-muted)}.field__control:disabled{opacity:.6;cursor:not-allowed}.field__control[aria-invalid=true]{border-color:var(--color-danger)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: InputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: InputComponent, multi: true }], template: "<div class=\"flex flex-col gap-2\">\n  <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n    {{ label }}\n    @if (required) {\n      <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n    }\n  </label>\n  <input\n    class=\"field__control\"\n    [id]=\"id\"\n    [type]=\"type\"\n    [value]=\"value()\"\n    [disabled]=\"disabled()\"\n    [attr.placeholder]=\"placeholder || null\"\n    [attr.aria-invalid]=\"error ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy\"\n    [attr.required]=\"required ? '' : null\"\n    (input)=\"onInput($event)\"\n    (blur)=\"onTouched()\"\n  />\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: [".field__control{height:var(--control-height);box-sizing:border-box;padding:0 var(--space-4);font-size:var(--fs-md);line-height:var(--lh-normal);color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.field__control:hover:not(:disabled){border-color:var(--color-text-muted)}.field__control:disabled{opacity:.6;cursor:not-allowed}.field__control[aria-invalid=true]{border-color:var(--color-danger)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], type: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], hint: [{
                type: Input
            }], error: [{
                type: Input
            }], required: [{
                type: Input
            }], id: [{
                type: Input
            }] } });

let nextId$6 = 0;
/**
 * Checkbox des UI-Kits. Boolescher Wert über `ControlValueAccessor`
 * (Reactive Forms + `ngModel`). Token-basiert (`accent-color` = CD-Primär),
 * sichtbarer Fokus-Ring (global `:focus-visible`), Label/`for`-Bindung für a11y.
 * Label-Text wird projiziert: `<app-checkbox [(ngModel)]="x">Text</app-checkbox>`.
 */
class CheckboxComponent {
    constructor() {
        this.id = `app-checkbox-${nextId$6++}`;
        this.hint = '';
        this.checked = signal(false, ...(ngDevMode ? [{ debugName: "checked" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    onToggle(event) {
        const v = event.target.checked;
        this.checked.set(v);
        this.onChange(v);
    }
    writeValue(value) {
        this.checked.set(!!value);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: CheckboxComponent, isStandalone: true, selector: "app-checkbox", inputs: { id: "id", hint: "hint" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: CheckboxComponent, multi: true }], ngImport: i0, template: "<label class=\"inline-flex items-center gap-2 cursor-pointer text-sm text-text\" [class.cbx--disabled]=\"disabled()\" [for]=\"id\">\n  <input\n    class=\"cbx__input\"\n    type=\"checkbox\"\n    [id]=\"id\"\n    [checked]=\"checked()\"\n    [disabled]=\"disabled()\"\n    [attr.aria-describedby]=\"hint ? id + '-hint' : null\"\n    (change)=\"onToggle($event)\"\n    (blur)=\"onTouched()\"\n  />\n  <span class=\"cbx__label\"><ng-content /></span>\n</label>\n@if (hint) {\n  <p class=\"cbx__hint\" [id]=\"id + '-hint'\">{{ hint }}</p>\n}\n", styles: [":host{display:inline-flex;flex-direction:column;gap:var(--space-1)}.cbx--disabled{cursor:not-allowed;opacity:.6}.cbx__input{flex:none;width:1.1rem;height:1.1rem;margin:0;accent-color:var(--color-primary);cursor:inherit}.cbx__label{line-height:var(--lh-normal)}.cbx__hint{font-size:var(--fs-xs);color:var(--color-text-muted);padding-left:calc(1.1rem + var(--space-2))}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-checkbox', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: CheckboxComponent, multi: true }], template: "<label class=\"inline-flex items-center gap-2 cursor-pointer text-sm text-text\" [class.cbx--disabled]=\"disabled()\" [for]=\"id\">\n  <input\n    class=\"cbx__input\"\n    type=\"checkbox\"\n    [id]=\"id\"\n    [checked]=\"checked()\"\n    [disabled]=\"disabled()\"\n    [attr.aria-describedby]=\"hint ? id + '-hint' : null\"\n    (change)=\"onToggle($event)\"\n    (blur)=\"onTouched()\"\n  />\n  <span class=\"cbx__label\"><ng-content /></span>\n</label>\n@if (hint) {\n  <p class=\"cbx__hint\" [id]=\"id + '-hint'\">{{ hint }}</p>\n}\n", styles: [":host{display:inline-flex;flex-direction:column;gap:var(--space-1)}.cbx--disabled{cursor:not-allowed;opacity:.6}.cbx__input{flex:none;width:1.1rem;height:1.1rem;margin:0;accent-color:var(--color-primary);cursor:inherit}.cbx__label{line-height:var(--lh-normal)}.cbx__hint{font-size:var(--fs-xs);color:var(--color-text-muted);padding-left:calc(1.1rem + var(--space-2))}\n"] }]
        }], propDecorators: { id: [{
                type: Input
            }], hint: [{
                type: Input
            }] } });

let nextId$5 = 0;
/**
 * Dropdown des UI-Kits. Ersetzt Freitext-Felder mit eingeschränkten
 * Optionen (Gremium, Budget, Status/Typ, Rollen). `ControlValueAccessor` →
 * Reactive Forms + `ngModel`. Token-basiert, eingebettetes Chevron, sichtbarer
 * Fokus-Ring, Label/`for`-Bindung + `aria-describedby` (a11y), Dark/Light.
 */
class SelectComponent {
    constructor() {
        this.label = '';
        /** Barrierefreier Name, wenn kein sichtbares Label gesetzt ist. */
        this.ariaLabel = '';
        this.placeholder = '';
        this.hint = '';
        this.error = '';
        this.required = false;
        this.options = [];
        this.id = `app-select-${nextId$5++}`;
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    get describedBy() {
        if (this.error)
            return `${this.id}-error`;
        if (this.hint)
            return `${this.id}-hint`;
        return null;
    }
    onSelect(event) {
        const v = event.target.value;
        this.value.set(v);
        this.onChange(v);
    }
    writeValue(value) {
        this.value.set(value ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: SelectComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: SelectComponent, isStandalone: true, selector: "app-select", inputs: { label: "label", ariaLabel: "ariaLabel", placeholder: "placeholder", hint: "hint", error: "error", required: "required", options: "options", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: SelectComponent, multi: true }], ngImport: i0, template: "<div class=\"flex flex-col gap-2\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <select\n    class=\"sel__control\"\n    [id]=\"id\"\n    [disabled]=\"disabled()\"\n    [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n    [attr.aria-invalid]=\"error ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy\"\n    [attr.required]=\"required ? '' : null\"\n    (change)=\"onSelect($event)\"\n    (blur)=\"onTouched()\"\n  >\n    <!-- Auswahl per [selected] je Option (nicht [value] am <select>): so greift sie\n         auch, wenn die Optionen ASYNC nachgeladen werden (z. B. Protokollant-Roster).\n         Ein [value] am <select> w\u00FCrde eine zum Setzzeitpunkt fehlende Option ignorieren\n         und auf den Platzhalter zur\u00FCckfallen (#select-async). -->\n    @if (placeholder) {\n      <option value=\"\" [disabled]=\"required\" [selected]=\"value() === ''\">{{ placeholder }}</option>\n    }\n    @for (opt of options; track opt.value) {\n      <option [value]=\"opt.value\" [selected]=\"opt.value === value()\" [disabled]=\"opt.disabled ?? false\">{{ opt.label }}</option>\n    }\n  </select>\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: [".sel__control{appearance:none;-webkit-appearance:none;width:100%;height:var(--control-height);box-sizing:border-box;padding:0 var(--space-7) 0 var(--space-4);font-size:var(--fs-md);line-height:var(--lh-normal);color:var(--color-text);background-color:var(--color-surface);background-image:url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 12 12\"><path d=\"M2 4.5l4 4 4-4\" fill=\"none\" stroke=\"%236e756f\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>');background-repeat:no-repeat;background-position:right var(--space-3) center;background-size:.7rem;border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);cursor:pointer;transition:border-color var(--motion-fast) var(--ease-standard)}.sel__control:hover:not(:disabled){border-color:var(--color-text-muted)}.sel__control:disabled{opacity:.6;cursor:not-allowed}.sel__control[aria-invalid=true]{border-color:var(--color-danger)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: SelectComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-select', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: SelectComponent, multi: true }], template: "<div class=\"flex flex-col gap-2\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <select\n    class=\"sel__control\"\n    [id]=\"id\"\n    [disabled]=\"disabled()\"\n    [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n    [attr.aria-invalid]=\"error ? 'true' : null\"\n    [attr.aria-describedby]=\"describedBy\"\n    [attr.required]=\"required ? '' : null\"\n    (change)=\"onSelect($event)\"\n    (blur)=\"onTouched()\"\n  >\n    <!-- Auswahl per [selected] je Option (nicht [value] am <select>): so greift sie\n         auch, wenn die Optionen ASYNC nachgeladen werden (z. B. Protokollant-Roster).\n         Ein [value] am <select> w\u00FCrde eine zum Setzzeitpunkt fehlende Option ignorieren\n         und auf den Platzhalter zur\u00FCckfallen (#select-async). -->\n    @if (placeholder) {\n      <option value=\"\" [disabled]=\"required\" [selected]=\"value() === ''\">{{ placeholder }}</option>\n    }\n    @for (opt of options; track opt.value) {\n      <option [value]=\"opt.value\" [selected]=\"opt.value === value()\" [disabled]=\"opt.disabled ?? false\">{{ opt.label }}</option>\n    }\n  </select>\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: [".sel__control{appearance:none;-webkit-appearance:none;width:100%;height:var(--control-height);box-sizing:border-box;padding:0 var(--space-7) 0 var(--space-4);font-size:var(--fs-md);line-height:var(--lh-normal);color:var(--color-text);background-color:var(--color-surface);background-image:url('data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 12 12\"><path d=\"M2 4.5l4 4 4-4\" fill=\"none\" stroke=\"%236e756f\" stroke-width=\"1.5\" stroke-linecap=\"round\" stroke-linejoin=\"round\"/></svg>');background-repeat:no-repeat;background-position:right var(--space-3) center;background-size:.7rem;border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);cursor:pointer;transition:border-color var(--motion-fast) var(--ease-standard)}.sel__control:hover:not(:disabled){border-color:var(--color-text-muted)}.sel__control:disabled{opacity:.6;cursor:not-allowed}.sel__control[aria-invalid=true]{border-color:var(--color-danger)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], hint: [{
                type: Input
            }], error: [{
                type: Input
            }], required: [{
                type: Input
            }], options: [{
                type: Input
            }], id: [{
                type: Input
            }] } });

let nextId$4 = 0;
/**
 * Datumsfeld des UI-Kits. **Lokalisiertes** Anzeigeformat (DE: `TT.MM.JJJJ`,
 * EN: `MM/DD/YYYY`) — unabhängig von der Browser-Sprache, die das native
 * `<input type="date">` sonst erzwingt. Der Wert ist immer ISO (`YYYY-MM-DD`).
 *
 * Bedienung: tippen im Textfeld (locale-Reihenfolge) **oder** den nativen Kalender
 * über den Kalender-Button öffnen (`showPicker()`; das native Feld bleibt unsichtbar,
 * nur sein Kalender-Popup erscheint). `ControlValueAccessor` → Reactive Forms/`ngModel`.
 */
class DatepickerComponent {
    constructor() {
        this.intl = inject(UI_KIT_INTL);
        this.label = '';
        this.ariaLabel = '';
        this.hint = '';
        this.error = '';
        this.required = false;
        this.min = '';
        this.max = '';
        this.id = `app-datepicker-${nextId$4++}`;
        this.native = viewChild('native', ...(ngDevMode ? [{ debugName: "native" }] : []));
        /** ISO-Wert (`YYYY-MM-DD`), CVA-Quelle. */
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        /** Sichtbarer (locale-formatierter) Text — beim Tippen unverändert übernommen. */
        this.display = signal('', ...(ngDevMode ? [{ debugName: "display" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.placeholder = computed(() => this.intl.lang() === 'de' ? 'TT.MM.JJJJ' : 'DD/MM/YYYY', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
        // Anzeige folgt der App-Sprache: ein Sprachwechsel
        // formatiert den sichtbaren Wert sofort um (TT.MM.JJJJ ↔ MM/DD/YYYY) —
        // vorher blieb das alte Format bis zum nächsten writeValue/Commit stehen.
        effect(() => {
            this.intl.lang();
            this.display.set(this.format(this.value()));
        });
    }
    get describedBy() {
        if (this.error)
            return `${this.id}-error`;
        if (this.hint)
            return `${this.id}-hint`;
        return null;
    }
    // Anzeige folgt der Eingabe; Commit (parse → ISO) erst bei Blur.
    onText(text) {
        this.display.set(text);
    }
    onBlur() {
        this.onTouched();
        const iso = this.parse(this.display());
        if (iso) {
            this.commit(iso);
        }
        else if (!this.display().trim()) {
            this.commit('');
        }
        else {
            // Ungültig → letzten gültigen Wert wieder anzeigen.
            this.display.set(this.format(this.value()));
        }
    }
    onNative(iso) {
        this.commit(iso);
    }
    openPicker() {
        const el = this.native()?.nativeElement;
        if (!el)
            return;
        const withPicker = el;
        if (typeof withPicker.showPicker === 'function') {
            withPicker.showPicker();
        }
        else {
            el.focus();
            el.click();
        }
    }
    commit(iso) {
        this.value.set(iso);
        this.display.set(this.format(iso));
        this.onChange(iso);
    }
    /** ISO → locale-Anzeige. */
    format(iso) {
        const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso ?? '');
        if (!m)
            return '';
        const [, y, mo, d] = m;
        // Both languages are day-first; only the separator differs.
        return this.intl.lang() === 'de' ? `${d}.${mo}.${y}` : `${d}/${mo}/${y}`;
    }
    /**
     * Locale-Text → ISO (oder `''`). Akzeptiert `. / -` als Trenner; 2-stellige Jahre → 20xx.
     *
     * Day first in BOTH languages. The host renders EN dates as en-GB, so a table showing
     * 04/09/2026 means 4 September; reading it back as 9 April changed the date silently.
     */
    parse(text) {
        const parts = text.trim().split(/[./\-\s]+/).filter(Boolean);
        if (parts.length !== 3)
            return '';
        const [day, month, y] = parts;
        let yyyy = Number(y);
        const dd = Number(day);
        const mm = Number(month);
        if (!dd || !mm || !yyyy)
            return '';
        if (yyyy < 100)
            yyyy += 2000;
        if (mm < 1 || mm > 12 || dd < 1 || dd > 31)
            return '';
        const iso = `${String(yyyy).padStart(4, '0')}-${String(mm).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
        const dt = new Date(iso + 'T00:00:00');
        return Number.isNaN(dt.getTime()) ? '' : iso;
    }
    writeValue(value) {
        const iso = value ?? '';
        this.value.set(iso);
        this.display.set(this.format(iso));
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DatepickerComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: DatepickerComponent, isStandalone: true, selector: "app-datepicker", inputs: { label: "label", ariaLabel: "ariaLabel", hint: "hint", error: "error", required: "required", min: "min", max: "max", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: DatepickerComponent, multi: true }], viewQueries: [{ propertyName: "native", first: true, predicate: ["native"], descendants: true, isSignal: true }], ngImport: i0, template: "<div class=\"dp\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <div class=\"relative flex\">\n    <input\n      class=\"dp__text\"\n      type=\"text\"\n      inputmode=\"numeric\"\n      autocomplete=\"off\"\n      [id]=\"id\"\n      [value]=\"display()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n      [attr.aria-invalid]=\"error ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy\"\n      [attr.required]=\"required ? '' : null\"\n      (input)=\"onText($any($event.target).value)\"\n      (blur)=\"onBlur()\"\n    />\n    <button\n      type=\"button\"\n      class=\"dp__cal\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"'datepicker.openCalendar' | uiKitT\"\n      (click)=\"openPicker()\"\n    >\n      <svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" aria-hidden=\"true\">\n        <rect x=\"3\" y=\"4\" width=\"18\" height=\"18\" rx=\"2\" /><path d=\"M16 2v4M8 2v4M3 10h18\" />\n      </svg>\n    </button>\n    <input\n      #native\n      class=\"dp__native\"\n      type=\"date\"\n      tabindex=\"-1\"\n      aria-hidden=\"true\"\n      [value]=\"value()\"\n      [attr.min]=\"min || null\"\n      [attr.max]=\"max || null\"\n      (change)=\"onNative($any($event.target).value)\"\n    />\n  </div>\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{display:block;min-width:0}.dp{display:flex;flex-direction:column;gap:var(--space-2);min-width:0}.dp__text{flex:1;min-width:0;width:100%;height:var(--control-height);box-sizing:border-box;padding:0 2.5rem 0 var(--space-4);font:inherit;font-size:var(--fs-md);color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.dp__text:hover:not(:disabled){border-color:var(--color-text-muted)}.dp__text:disabled{opacity:.6;cursor:not-allowed}.dp__text[aria-invalid=true]{border-color:var(--color-danger)}.dp__cal{position:absolute;right:0;top:0;height:var(--control-height);width:2.5rem;display:inline-flex;align-items:center;justify-content:center;background:transparent;border:0;color:var(--color-text-muted);cursor:pointer;border-radius:var(--radius-md)}.dp__cal:hover:not(:disabled){color:var(--color-text)}.dp__cal:disabled{opacity:.6;cursor:not-allowed}.dp__native{position:absolute;right:.5rem;bottom:0;width:1px;height:1px;opacity:0;pointer-events:none;border:0;padding:0}\n"], dependencies: [{ kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DatepickerComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-datepicker', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: DatepickerComponent, multi: true }], template: "<div class=\"dp\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <div class=\"relative flex\">\n    <input\n      class=\"dp__text\"\n      type=\"text\"\n      inputmode=\"numeric\"\n      autocomplete=\"off\"\n      [id]=\"id\"\n      [value]=\"display()\"\n      [placeholder]=\"placeholder()\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n      [attr.aria-invalid]=\"error ? 'true' : null\"\n      [attr.aria-describedby]=\"describedBy\"\n      [attr.required]=\"required ? '' : null\"\n      (input)=\"onText($any($event.target).value)\"\n      (blur)=\"onBlur()\"\n    />\n    <button\n      type=\"button\"\n      class=\"dp__cal\"\n      [disabled]=\"disabled()\"\n      [attr.aria-label]=\"'datepicker.openCalendar' | uiKitT\"\n      (click)=\"openPicker()\"\n    >\n      <svg width=\"18\" height=\"18\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" aria-hidden=\"true\">\n        <rect x=\"3\" y=\"4\" width=\"18\" height=\"18\" rx=\"2\" /><path d=\"M16 2v4M8 2v4M3 10h18\" />\n      </svg>\n    </button>\n    <input\n      #native\n      class=\"dp__native\"\n      type=\"date\"\n      tabindex=\"-1\"\n      aria-hidden=\"true\"\n      [value]=\"value()\"\n      [attr.min]=\"min || null\"\n      [attr.max]=\"max || null\"\n      (change)=\"onNative($any($event.target).value)\"\n    />\n  </div>\n  @if (hint && !error) {\n    <p class=\"text-xs text-muted\" [id]=\"id + '-hint'\">{{ hint }}</p>\n  }\n  @if (error) {\n    <p class=\"text-xs text-danger\" [id]=\"id + '-error'\" role=\"alert\">{{ error }}</p>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";:host{display:block;min-width:0}.dp{display:flex;flex-direction:column;gap:var(--space-2);min-width:0}.dp__text{flex:1;min-width:0;width:100%;height:var(--control-height);box-sizing:border-box;padding:0 2.5rem 0 var(--space-4);font:inherit;font-size:var(--fs-md);color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.dp__text:hover:not(:disabled){border-color:var(--color-text-muted)}.dp__text:disabled{opacity:.6;cursor:not-allowed}.dp__text[aria-invalid=true]{border-color:var(--color-danger)}.dp__cal{position:absolute;right:0;top:0;height:var(--control-height);width:2.5rem;display:inline-flex;align-items:center;justify-content:center;background:transparent;border:0;color:var(--color-text-muted);cursor:pointer;border-radius:var(--radius-md)}.dp__cal:hover:not(:disabled){color:var(--color-text)}.dp__cal:disabled{opacity:.6;cursor:not-allowed}.dp__native{position:absolute;right:.5rem;bottom:0;width:1px;height:1px;opacity:0;pointer-events:none;border:0;padding:0}\n"] }]
        }], ctorParameters: () => [], propDecorators: { label: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], hint: [{
                type: Input
            }], error: [{
                type: Input
            }], required: [{
                type: Input
            }], min: [{
                type: Input
            }], max: [{
                type: Input
            }], id: [{
                type: Input
            }], native: [{ type: i0.ViewChild, args: ['native', { isSignal: true }] }] } });

let nextId$3 = 0;
/**
 * Uhrzeit-Feld des UI-Kits. Erzwingt **24h-Format** (`HH:MM`) —
 * das native `<input type="time">` rendert je nach Browser-/OS-Locale AM/PM,
 * unabhängig von der App-Sprache. Der Wert ist immer `HH:MM` (oder `''`).
 *
 * Eingabe tolerant: `9:30`, `09.30`, `0930` → `09:30`; Commit bei Blur,
 * Ungültiges fällt auf den letzten gültigen Wert zurück (wie `app-datepicker`).
 * `ControlValueAccessor` → Reactive Forms/`ngModel`.
 */
class TimeInputComponent {
    constructor() {
        this.label = '';
        this.ariaLabel = '';
        this.required = false;
        this.id = `app-time-input-${nextId$3++}`;
        /** Kanonischer Wert (`HH:MM` | `''`), CVA-Quelle. */
        this.value = signal('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        /** Sichtbarer Text — beim Tippen unverändert, Commit bei Blur. */
        this.display = signal('', ...(ngDevMode ? [{ debugName: "display" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    onText(text) {
        this.display.set(text);
    }
    onBlur() {
        this.onTouched();
        const parsed = parseTime(this.display());
        if (parsed !== null) {
            this.commit(parsed);
        }
        else {
            // Ungültig → letzten gültigen Wert wieder anzeigen.
            this.display.set(this.value());
        }
    }
    commit(value) {
        this.value.set(value);
        this.display.set(value);
        this.onChange(value);
    }
    writeValue(value) {
        const v = normalizeWire(value);
        this.value.set(v);
        this.display.set(v);
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: TimeInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: TimeInputComponent, isStandalone: true, selector: "app-time-input", inputs: { label: "label", ariaLabel: "ariaLabel", required: "required", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: TimeInputComponent, multi: true }], ngImport: i0, template: "<div class=\"flex flex-col gap-2\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <input\n    class=\"ti__text\"\n    type=\"text\"\n    inputmode=\"numeric\"\n    autocomplete=\"off\"\n    placeholder=\"HH:MM\"\n    [id]=\"id\"\n    [value]=\"display()\"\n    [disabled]=\"disabled()\"\n    [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n    [attr.required]=\"required ? '' : null\"\n    (input)=\"onText($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  />\n</div>\n", styles: [".ti__text{height:var(--control-height);box-sizing:border-box;padding:0 var(--space-4);font:inherit;font-size:var(--fs-md);font-variant-numeric:tabular-nums;color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.ti__text:hover:not(:disabled){border-color:var(--color-text-muted)}.ti__text:disabled{opacity:.6;cursor:not-allowed}.ti__text:focus-visible{outline:2px solid var(--color-primary);outline-offset:1px}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: TimeInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-time-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: TimeInputComponent, multi: true }], template: "<div class=\"flex flex-col gap-2\">\n  @if (label) {\n    <label class=\"text-sm font-medium text-text\" [for]=\"id\">\n      {{ label }}\n      @if (required) {\n        <span class=\"text-danger\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <input\n    class=\"ti__text\"\n    type=\"text\"\n    inputmode=\"numeric\"\n    autocomplete=\"off\"\n    placeholder=\"HH:MM\"\n    [id]=\"id\"\n    [value]=\"display()\"\n    [disabled]=\"disabled()\"\n    [attr.aria-label]=\"!label && ariaLabel ? ariaLabel : null\"\n    [attr.required]=\"required ? '' : null\"\n    (input)=\"onText($any($event.target).value)\"\n    (blur)=\"onBlur()\"\n  />\n</div>\n", styles: [".ti__text{height:var(--control-height);box-sizing:border-box;padding:0 var(--space-4);font:inherit;font-size:var(--fs-md);font-variant-numeric:tabular-nums;color:var(--color-text);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);transition:border-color var(--motion-fast) var(--ease-standard)}.ti__text:hover:not(:disabled){border-color:var(--color-text-muted)}.ti__text:disabled{opacity:.6;cursor:not-allowed}.ti__text:focus-visible{outline:2px solid var(--color-primary);outline-offset:1px}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], required: [{
                type: Input
            }], id: [{
                type: Input
            }] } });
/** Wire-Wert normalisieren: `HH:MM:SS` (Backend-`time`) → `HH:MM`. */
function normalizeWire(value) {
    const m = /^(\d{2}):(\d{2})/.exec(value ?? '');
    return m ? `${m[1]}:${m[2]}` : '';
}
/** Freie Eingabe → `HH:MM` (24h) | `''` (leer) | `null` (ungültig). */
function parseTime(text) {
    const t = text.trim();
    if (!t)
        return '';
    const m = /^(\d{1,2})[:.,]?([0-5]\d)$/.exec(t) ?? /^(\d{1,2})$/.exec(t);
    if (!m)
        return null;
    const hh = Number(m[1]);
    const mm = m[2] !== undefined ? Number(m[2]) : 0;
    if (hh > 23)
        return null;
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

let nextId$2 = 0;
/**
 * Zeitraum-Feld: zwei gekoppelte native Datumsfelder (Start/Ende). Das Ende
 * kann nicht vor dem Start liegen (`min`/`max`-Kopplung). Wert ist `{ start, end }`;
 * `ControlValueAccessor` → Reactive Forms + `ngModel`. a11y über `<fieldset>` +
 * `<legend>` und `<label for>`-Bindung je Feld; native Kalender-UI folgt dem Theme
 * (`color-scheme`), Dark/Light via Tokens.
 */
class DateRangeComponent {
    constructor() {
        this.legend = '';
        this.startLabel = '';
        this.endLabel = '';
        this.id = `app-date-range-${nextId$2++}`;
        this.start = signal('', ...(ngDevMode ? [{ debugName: "start" }] : []));
        this.end = signal('', ...(ngDevMode ? [{ debugName: "end" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    onStart(v) {
        this.start.set(v);
        this.emit();
    }
    onEnd(v) {
        this.end.set(v);
        this.emit();
    }
    emit() {
        this.onChange({ start: this.start(), end: this.end() });
    }
    writeValue(value) {
        this.start.set(value?.start ?? '');
        this.end.set(value?.end ?? '');
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DateRangeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: DateRangeComponent, isStandalone: true, selector: "app-date-range", inputs: { legend: "legend", startLabel: "startLabel", endLabel: "endLabel", id: "id" }, providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: DateRangeComponent, multi: true }], ngImport: i0, template: "<fieldset class=\"dr\">\n  @if (legend) {\n    <legend class=\"p-0 mb-2 text-sm font-semibold text-text\">{{ legend }}</legend>\n  }\n  <div class=\"flex items-end gap-3 flex-wrap\">\n    <div class=\"dr__field\">\n      <app-datepicker\n        [id]=\"id + '-start'\"\n        [ariaLabel]=\"startLabel\"\n        [max]=\"end()\"\n        [ngModel]=\"start()\"\n        (ngModelChange)=\"onStart($event)\"\n      />\n    </div>\n    <span class=\"pb-3 text-muted\" aria-hidden=\"true\">\u2013</span>\n    <div class=\"dr__field\">\n      <app-datepicker\n        [id]=\"id + '-end'\"\n        [ariaLabel]=\"endLabel\"\n        [min]=\"start()\"\n        [ngModel]=\"end()\"\n        (ngModelChange)=\"onEnd($event)\"\n      />\n    </div>\n  </div>\n</fieldset>\n", styles: [".dr{border:0;margin:0;padding:0;min-inline-size:0}.dr__field{display:flex;flex-direction:column;gap:var(--space-2);flex:1 1 9rem}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "component", type: DatepickerComponent, selector: "app-datepicker", inputs: ["label", "ariaLabel", "hint", "error", "required", "min", "max", "id"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DateRangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-date-range', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [FormsModule, DatepickerComponent], providers: [{ provide: NG_VALUE_ACCESSOR, useExisting: DateRangeComponent, multi: true }], template: "<fieldset class=\"dr\">\n  @if (legend) {\n    <legend class=\"p-0 mb-2 text-sm font-semibold text-text\">{{ legend }}</legend>\n  }\n  <div class=\"flex items-end gap-3 flex-wrap\">\n    <div class=\"dr__field\">\n      <app-datepicker\n        [id]=\"id + '-start'\"\n        [ariaLabel]=\"startLabel\"\n        [max]=\"end()\"\n        [ngModel]=\"start()\"\n        (ngModelChange)=\"onStart($event)\"\n      />\n    </div>\n    <span class=\"pb-3 text-muted\" aria-hidden=\"true\">\u2013</span>\n    <div class=\"dr__field\">\n      <app-datepicker\n        [id]=\"id + '-end'\"\n        [ariaLabel]=\"endLabel\"\n        [min]=\"start()\"\n        [ngModel]=\"end()\"\n        (ngModelChange)=\"onEnd($event)\"\n      />\n    </div>\n  </div>\n</fieldset>\n", styles: [".dr{border:0;margin:0;padding:0;min-inline-size:0}.dr__field{display:flex;flex-direction:column;gap:var(--space-2);flex:1 1 9rem}\n"] }]
        }], propDecorators: { legend: [{
                type: Input
            }], startLabel: [{
                type: Input
            }], endLabel: [{
                type: Input
            }], id: [{
                type: Input
            }] } });

/** Icon-Name → Font-Awesome-Solid-Klasse (#80, FA-Migration). */
const FA = {
    sun: 'fa-sun',
    moon: 'fa-moon',
    language: 'fa-language',
    edit: 'fa-pen-to-square',
    delete: 'fa-trash',
    add: 'fa-plus',
    remove: 'fa-xmark',
    members: 'fa-users',
    roles: 'fa-user-shield',
    user: 'fa-user',
    'chevron-down': 'fa-chevron-down',
    'chevron-up': 'fa-chevron-up',
    power: 'fa-power-off',
    filter: 'fa-filter',
    check: 'fa-check',
    building: 'fa-building',
    parliament: 'fa-landmark',
    euro: 'fa-euro-sign',
    form: 'fa-clipboard-list',
    flow: 'fa-diagram-project',
    palette: 'fa-palette',
    webhook: 'fa-globe',
    bell: 'fa-bell',
    audit: 'fa-clipboard-check',
    clock: 'fa-clock',
    export: 'fa-file-export',
    play: 'fa-play',
    stop: 'fa-stop',
    half: 'fa-circle-half-stroke',
    send: 'fa-paper-plane',
    repeat: 'fa-repeat',
    menu: 'fa-bars',
    gear: 'fa-gear',
    key: 'fa-key',
    handshake: 'fa-handshake',
    paperclip: 'fa-paperclip',
    // Font Awesome Free hat kein `paperclip-slash` (nur Pro). Der Grundriss ist die
    // Büroklammer; der Strich kommt aus OVERLAY.
    'paperclip-slash': 'fa-paperclip',
    home: 'fa-house',
    link: 'fa-link',
    'link-slash': 'fa-link-slash',
    // Suchen ist nicht Filtern: der Trichter ist der Filter-Button der Listenseiten.
    search: 'fa-magnifying-glass',
    eye: 'fa-eye',
    'eye-slash': 'fa-eye-slash',
    upload: 'fa-file-arrow-up',
    document: 'fa-file-lines',
    'chart-pie': 'fa-chart-pie',
};
/**
 * Zweites, überlagertes Glyph für Icons, die Font Awesome Free nicht als eigenes Zeichen
 * führt. Das Overlay liegt deckungsgleich über dem Grundriss.
 */
const OVERLAY = {
    'paperclip-slash': 'fa-slash',
};
/**
 * Icon-Komponente. Rendert ein **Font-Awesome**-Solid-Icon (`fa-solid`),
 * gesteuert über einen stabilen, semantischen `name`. Dekorativ
 * (`aria-hidden`) — der barrierefreie Name kommt vom umschließenden Control.
 * `currentColor` folgt der Text-/Theme-Farbe automatisch (Dark/Light).
 */
class IconComponent {
    constructor() {
        this._name = signal('sun', ...(ngDevMode ? [{ debugName: "_name" }] : []));
        /** Kantenlänge in px (Schriftgröße des Glyphs). */
        this.size = 18;
        this.faClass = computed(() => FA[this._name()] ?? 'fa-circle-question', ...(ngDevMode ? [{ debugName: "faClass" }] : []));
        /** Leer, wenn das Icon aus einem einzigen Glyph besteht. */
        this.overlayClass = computed(() => OVERLAY[this._name()] ?? '', ...(ngDevMode ? [{ debugName: "overlayClass" }] : []));
    }
    set name(value) {
        this._name.set(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: IconComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: IconComponent, isStandalone: true, selector: "app-icon", inputs: { name: "name", size: "size" }, ngImport: i0, template: "<span class=\"icon__stack\">\n  <i class=\"fa-solid\" [class]=\"faClass()\" [style.fontSize.px]=\"size\" aria-hidden=\"true\"></i>\n  @if (overlayClass()) {\n    <i\n      class=\"fa-solid icon__overlay\"\n      [class]=\"overlayClass()\"\n      [style.fontSize.px]=\"size\"\n      aria-hidden=\"true\"\n    ></i>\n  }\n</span>\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex;align-items:center;justify-content:center;line-height:0}i{line-height:1}.icon__stack{position:relative;display:inline-flex;align-items:center;justify-content:center;line-height:0}.icon__overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: IconComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-icon', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span class=\"icon__stack\">\n  <i class=\"fa-solid\" [class]=\"faClass()\" [style.fontSize.px]=\"size\" aria-hidden=\"true\"></i>\n  @if (overlayClass()) {\n    <i\n      class=\"fa-solid icon__overlay\"\n      [class]=\"overlayClass()\"\n      [style.fontSize.px]=\"size\"\n      aria-hidden=\"true\"\n    ></i>\n  }\n</span>\n", styles: ["@charset \"UTF-8\";:host{display:inline-flex;align-items:center;justify-content:center;line-height:0}i{line-height:1}.icon__stack{position:relative;display:inline-flex;align-items:center;justify-content:center;line-height:0}.icon__overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}\n"] }]
        }], propDecorators: { name: [{
                type: Input
            }], size: [{
                type: Input
            }] } });

/** Container-Fläche. Slots: [card-header], default body, [card-footer]. */
class CardComponent {
    constructor() {
        this.heading = '';
        this.interactive = false;
        /** Überschriften-Ebene des `heading` (a11y/heading-order). Default `<h3>`. */
        this.headingLevel = 3;
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: CardComponent, isStandalone: true, selector: "app-card", inputs: { heading: "heading", interactive: "interactive", headingLevel: "headingLevel" }, ngImport: i0, template: "<section class=\"card\" [class.card--interactive]=\"interactive\">\n  <header class=\"card__header\">\n    @if (heading) {\n      @switch (headingLevel) {\n        @case (2) {\n          <h2 class=\"text-lg font-semibold\">{{ heading }}</h2>\n        }\n        @case (4) {\n          <h4 class=\"text-lg font-semibold\">{{ heading }}</h4>\n        }\n        @default {\n          <h3 class=\"text-lg font-semibold\">{{ heading }}</h3>\n        }\n      }\n    }\n    <ng-content select=\"[card-header]\" />\n  </header>\n  <div class=\"card__body p-5\"><ng-content /></div>\n  <footer class=\"card__footer\"><ng-content select=\"[card-footer]\" /></footer>\n</section>\n", styles: ["@charset \"UTF-8\";:host{display:flex;flex-direction:column}.card{flex:1 1 auto;display:flex;flex-direction:column;background:var(--color-surface);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);overflow:hidden}.card--interactive{transition:box-shadow var(--motion-base) var(--ease-standard),border-color var(--motion-base) var(--ease-standard),background-color var(--motion-fast) var(--ease-standard)}.card--interactive:hover{box-shadow:var(--shadow-md);border-color:var(--color-border-strong)}.card--interactive:active{background:var(--color-surface-sunken)}.card__header:empty,.card__footer:empty{display:none}.card__header{padding:var(--space-5) var(--space-5) 0}.card__header>:first-child{margin-block:0}.card__footer{padding:0 var(--space-5) var(--space-5)}.card__body:empty{padding:0 0 var(--space-5)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-card', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<section class=\"card\" [class.card--interactive]=\"interactive\">\n  <header class=\"card__header\">\n    @if (heading) {\n      @switch (headingLevel) {\n        @case (2) {\n          <h2 class=\"text-lg font-semibold\">{{ heading }}</h2>\n        }\n        @case (4) {\n          <h4 class=\"text-lg font-semibold\">{{ heading }}</h4>\n        }\n        @default {\n          <h3 class=\"text-lg font-semibold\">{{ heading }}</h3>\n        }\n      }\n    }\n    <ng-content select=\"[card-header]\" />\n  </header>\n  <div class=\"card__body p-5\"><ng-content /></div>\n  <footer class=\"card__footer\"><ng-content select=\"[card-footer]\" /></footer>\n</section>\n", styles: ["@charset \"UTF-8\";:host{display:flex;flex-direction:column}.card{flex:1 1 auto;display:flex;flex-direction:column;background:var(--color-surface);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-sm);overflow:hidden}.card--interactive{transition:box-shadow var(--motion-base) var(--ease-standard),border-color var(--motion-base) var(--ease-standard),background-color var(--motion-fast) var(--ease-standard)}.card--interactive:hover{box-shadow:var(--shadow-md);border-color:var(--color-border-strong)}.card--interactive:active{background:var(--color-surface-sunken)}.card__header:empty,.card__footer:empty{display:none}.card__header{padding:var(--space-5) var(--space-5) 0}.card__header>:first-child{margin-block:0}.card__footer{padding:0 var(--space-5) var(--space-5)}.card__body:empty{padding:0 0 var(--space-5)}\n"] }]
        }], propDecorators: { heading: [{
                type: Input
            }], interactive: [{
                type: Input
            }], headingLevel: [{
                type: Input
            }] } });

/** Status-Chip (z. B. Antrags-Status, Vote-Ergebnis). */
class BadgeComponent {
    constructor() {
        this.variant = 'neutral';
    }
    /** Lesbare Textfarbe für {@link color} via Luminanz-Schwelle. */
    get textColor() {
        return readableTextColor(this.color) ?? '#ffffff';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: BadgeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "20.3.25", type: BadgeComponent, isStandalone: true, selector: "app-badge", inputs: { variant: "variant", color: "color" }, ngImport: i0, template: "<span\n    class=\"badge\"\n    [class]=\"color ? 'badge--custom' : 'badge--' + variant\"\n    [style.background]=\"color || null\"\n    [style.color]=\"color ? textColor : null\"\n    ><ng-content\n  /></span>\n", styles: [".badge{display:inline-flex;align-items:center;padding:var(--space-1) var(--space-3);font-size:var(--fs-xs);font-weight:var(--fw-semibold);line-height:1.4;border-radius:var(--radius-pill);white-space:nowrap}.badge--neutral{background:var(--color-surface-sunken);color:var(--color-text-muted)}.badge--primary{background:var(--color-primary-subtle);color:var(--color-primary)}.badge--success{background:var(--color-success-subtle);color:var(--color-success)}.badge--warning{background:var(--color-warning-subtle);color:var(--color-warning)}.badge--danger{background:var(--color-danger-subtle);color:var(--color-danger)}.badge--info{background:var(--color-info-subtle);color:var(--color-info)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: BadgeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-badge', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<span\n    class=\"badge\"\n    [class]=\"color ? 'badge--custom' : 'badge--' + variant\"\n    [style.background]=\"color || null\"\n    [style.color]=\"color ? textColor : null\"\n    ><ng-content\n  /></span>\n", styles: [".badge{display:inline-flex;align-items:center;padding:var(--space-1) var(--space-3);font-size:var(--fs-xs);font-weight:var(--fw-semibold);line-height:1.4;border-radius:var(--radius-pill);white-space:nowrap}.badge--neutral{background:var(--color-surface-sunken);color:var(--color-text-muted)}.badge--primary{background:var(--color-primary-subtle);color:var(--color-primary)}.badge--success{background:var(--color-success-subtle);color:var(--color-success)}.badge--warning{background:var(--color-warning-subtle);color:var(--color-warning)}.badge--danger{background:var(--color-danger-subtle);color:var(--color-danger)}.badge--info{background:var(--color-info-subtle);color:var(--color-info)}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], color: [{
                type: Input
            }] } });
/**
 * Liefert `#1a1a1a` (dunkel) oder `#ffffff` (weiß) je nach wahrgenommener
 * Helligkeit der gegebenen Hex-Farbe. Gibt `null` bei ungültiger Eingabe.
 */
function readableTextColor(hex) {
    if (!hex)
        return null;
    let h = hex.trim().replace(/^#/, '');
    if (h.length === 3) {
        h = h
            .split('')
            .map((c) => c + c)
            .join('');
    }
    if (!/^[0-9a-fA-F]{6}$/.test(h))
        return null;
    const r = parseInt(h.slice(0, 2), 16);
    const g = parseInt(h.slice(2, 4), 16);
    const b = parseInt(h.slice(4, 6), 16);
    // Relative Luminanz (sRGB, schnelle Variante).
    const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
    return luminance > 0.6 ? '#1a1a1a' : '#ffffff';
}

/**
 * Feld-Diff-Renderer (added/removed/changed) — z. B. für Antrags-Historie
 * (Submission-Versionen) oder Config-Versionen (Forms/Flow/Branding). Reine
 * Präsentation: nimmt einen aufgelösten {@link ConfigDiffData} (Arrays) und rendert
 * je Eintrag ein Severity-Badge + Feld-Key + Alt→Neu-Werte.
 */
class ConfigDiffComponent {
    constructor() {
        /** Aufgelöster Diff (`null`/leer ⇒ »keine Änderungen«). */
        this.diff = input(null, ...(ngDevMode ? [{ debugName: "diff" }] : []));
    }
    isEmpty(d) {
        return !d || (d.added.length === 0 && d.removed.length === 0 && d.changed.length === 0);
    }
    /** Wert lesbar machen (Objekte als JSON; null/undefined als »—«). */
    fmt(value) {
        if (value === null || value === undefined)
            return '—';
        return typeof value === 'object' ? JSON.stringify(value) : String(value);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ConfigDiffComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: ConfigDiffComponent, isStandalone: true, selector: "app-config-diff", inputs: { diff: { classPropertyName: "diff", publicName: "diff", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "@if (isEmpty(diff())) {\n  <p class=\"text-muted cfg-diff__none\">{{ 'diff.none' | uiKitT }}</p>\n} @else {\n  <ul class=\"cfg-diff\">\n    @for (change of diff()!.changed; track change.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--changed\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"warning\">{{ 'diff.changed' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ change.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <del class=\"cfg-diff__val\">{{ fmt(change.old) }}</del>\n          <ins class=\"cfg-diff__val\">{{ fmt(change.new) }}</ins>\n        </div>\n      </li>\n    }\n    @for (added of diff()!.added; track added.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--added\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"success\">{{ 'diff.added' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ added.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <ins class=\"cfg-diff__val\">{{ fmt(added.value) }}</ins>\n        </div>\n      </li>\n    }\n    @for (removed of diff()!.removed; track removed.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--removed\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"danger\">{{ 'diff.removed' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ removed.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <del class=\"cfg-diff__val\">{{ fmt(removed.value) }}</del>\n        </div>\n      </li>\n    }\n  </ul>\n}\n", styles: [".cfg-diff{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-2, .5rem)}.cfg-diff__item{display:flex;flex-direction:column;gap:var(--space-1, .35rem);padding:var(--space-2, .5rem) var(--space-3, .75rem);border:var(--border-width, 1px) solid var(--color-border, #e5e7eb);border-left-width:3px;border-radius:var(--radius-sm, 6px);background:var(--color-surface-sunken, #f7f7f8)}.cfg-diff__item--changed{border-left-color:var(--color-warning, #b58100)}.cfg-diff__item--added{border-left-color:var(--color-success, #1b5e20)}.cfg-diff__item--removed{border-left-color:var(--color-danger, #b00020)}.cfg-diff__head{display:flex;align-items:center;gap:var(--space-2, .5rem);flex-wrap:wrap}.cfg-diff__key{font-family:var(--font-mono, monospace);font-size:var(--fs-sm, .875rem);font-weight:600;overflow-wrap:anywhere}.cfg-diff__vals{display:flex;flex-direction:column;gap:var(--space-1, .35rem)}.cfg-diff__val{font-family:var(--font-mono, monospace);font-size:var(--fs-xs, .78rem);line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere;text-decoration:none}del.cfg-diff__val{color:var(--color-danger, #b00020);text-decoration:line-through}ins.cfg-diff__val{color:var(--color-success, #1b5e20)}.cfg-diff__none{font-size:var(--fs-sm, .875rem)}\n"], dependencies: [{ kind: "component", type: BadgeComponent, selector: "app-badge", inputs: ["variant", "color"] }, { kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ConfigDiffComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-config-diff', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe, BadgeComponent], template: "@if (isEmpty(diff())) {\n  <p class=\"text-muted cfg-diff__none\">{{ 'diff.none' | uiKitT }}</p>\n} @else {\n  <ul class=\"cfg-diff\">\n    @for (change of diff()!.changed; track change.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--changed\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"warning\">{{ 'diff.changed' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ change.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <del class=\"cfg-diff__val\">{{ fmt(change.old) }}</del>\n          <ins class=\"cfg-diff__val\">{{ fmt(change.new) }}</ins>\n        </div>\n      </li>\n    }\n    @for (added of diff()!.added; track added.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--added\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"success\">{{ 'diff.added' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ added.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <ins class=\"cfg-diff__val\">{{ fmt(added.value) }}</ins>\n        </div>\n      </li>\n    }\n    @for (removed of diff()!.removed; track removed.key) {\n      <li class=\"cfg-diff__item cfg-diff__item--removed\">\n        <div class=\"cfg-diff__head\">\n          <app-badge variant=\"danger\">{{ 'diff.removed' | uiKitT }}</app-badge>\n          <code class=\"cfg-diff__key\">{{ removed.key }}</code>\n        </div>\n        <div class=\"cfg-diff__vals\">\n          <del class=\"cfg-diff__val\">{{ fmt(removed.value) }}</del>\n        </div>\n      </li>\n    }\n  </ul>\n}\n", styles: [".cfg-diff{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:var(--space-2, .5rem)}.cfg-diff__item{display:flex;flex-direction:column;gap:var(--space-1, .35rem);padding:var(--space-2, .5rem) var(--space-3, .75rem);border:var(--border-width, 1px) solid var(--color-border, #e5e7eb);border-left-width:3px;border-radius:var(--radius-sm, 6px);background:var(--color-surface-sunken, #f7f7f8)}.cfg-diff__item--changed{border-left-color:var(--color-warning, #b58100)}.cfg-diff__item--added{border-left-color:var(--color-success, #1b5e20)}.cfg-diff__item--removed{border-left-color:var(--color-danger, #b00020)}.cfg-diff__head{display:flex;align-items:center;gap:var(--space-2, .5rem);flex-wrap:wrap}.cfg-diff__key{font-family:var(--font-mono, monospace);font-size:var(--fs-sm, .875rem);font-weight:600;overflow-wrap:anywhere}.cfg-diff__vals{display:flex;flex-direction:column;gap:var(--space-1, .35rem)}.cfg-diff__val{font-family:var(--font-mono, monospace);font-size:var(--fs-xs, .78rem);line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere;text-decoration:none}del.cfg-diff__val{color:var(--color-danger, #b00020);text-decoration:line-through}ins.cfg-diff__val{color:var(--color-success, #1b5e20)}.cfg-diff__none{font-size:var(--fs-sm, .875rem)}\n"] }]
        }], propDecorators: { diff: [{ type: i0.Input, args: [{ isSignal: true, alias: "diff", required: false }] }] } });

/** Fortschrittsanzeige für den Antrags-Wizard (N1a Multi-Step). */
class StepperComponent {
    constructor() {
        this.steps = [];
        this.activeIndex = 0;
        this.ariaLabel = 'Fortschritt';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: StepperComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: StepperComponent, isStandalone: true, selector: "app-stepper", inputs: { steps: "steps", activeIndex: "activeIndex", ariaLabel: "ariaLabel" }, ngImport: i0, template: "<ol class=\"stepper\" [attr.aria-label]=\"ariaLabel\">\n  @for (step of steps; track step.label; let i = $index) {\n    <li\n      class=\"stepper__item\"\n      [class.is-active]=\"i === activeIndex\"\n      [class.is-done]=\"i < activeIndex\"\n      [attr.aria-current]=\"i === activeIndex ? 'step' : null\"\n    >\n      <span class=\"stepper__marker\">{{ i < activeIndex ? '\u2713' : i + 1 }}</span>\n      <span class=\"stepper__label\">{{ step.label }}</span>\n    </li>\n  }\n</ol>\n", styles: [".stepper{display:flex;flex-wrap:wrap;gap:var(--space-5);padding:0;margin:0;list-style:none}.stepper__item{display:inline-flex;align-items:center;gap:var(--space-2);color:var(--color-text-muted);font-size:var(--fs-sm)}.stepper__marker{display:inline-flex;align-items:center;justify-content:center;width:1.75rem;height:1.75rem;border-radius:var(--radius-pill);border:var(--border-width) solid var(--color-border-strong);font-weight:var(--fw-semibold);font-size:var(--fs-sm)}.stepper__item.is-active{color:var(--color-text)}.stepper__item.is-active .stepper__marker{background:var(--color-primary);border-color:var(--color-primary);color:var(--color-on-primary)}.stepper__item.is-done .stepper__marker{background:var(--color-primary-subtle);border-color:var(--color-primary);color:var(--color-primary)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: StepperComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-stepper', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<ol class=\"stepper\" [attr.aria-label]=\"ariaLabel\">\n  @for (step of steps; track step.label; let i = $index) {\n    <li\n      class=\"stepper__item\"\n      [class.is-active]=\"i === activeIndex\"\n      [class.is-done]=\"i < activeIndex\"\n      [attr.aria-current]=\"i === activeIndex ? 'step' : null\"\n    >\n      <span class=\"stepper__marker\">{{ i < activeIndex ? '\u2713' : i + 1 }}</span>\n      <span class=\"stepper__label\">{{ step.label }}</span>\n    </li>\n  }\n</ol>\n", styles: [".stepper{display:flex;flex-wrap:wrap;gap:var(--space-5);padding:0;margin:0;list-style:none}.stepper__item{display:inline-flex;align-items:center;gap:var(--space-2);color:var(--color-text-muted);font-size:var(--fs-sm)}.stepper__marker{display:inline-flex;align-items:center;justify-content:center;width:1.75rem;height:1.75rem;border-radius:var(--radius-pill);border:var(--border-width) solid var(--color-border-strong);font-weight:var(--fw-semibold);font-size:var(--fs-sm)}.stepper__item.is-active{color:var(--color-text)}.stepper__item.is-active .stepper__marker{background:var(--color-primary);border-color:var(--color-primary);color:var(--color-on-primary)}.stepper__item.is-done .stepper__marker{background:var(--color-primary-subtle);border-color:var(--color-primary);color:var(--color-primary)}\n"] }]
        }], propDecorators: { steps: [{
                type: Input
            }], activeIndex: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }] } });

let nextId$1 = 0;
/**
 * Modaler Dialog. Schließt per Backdrop-Klick, Schließen-Button oder ESC.
 *
 * a11y (T-43, WCAG 2.1.2/2.4.3): Beim Öffnen wandert der Fokus in den Dialog,
 * Tab/Shift+Tab werden im Dialog gefangen (Focus-Trap), beim Schließen kehrt der
 * Fokus auf das auslösende Element zurück. `aria-modal`/`role="dialog"` +
 * `aria-labelledby` sind gesetzt.
 */
class DialogComponent {
    constructor() {
        this.open = false;
        this.title = '';
        this.closeLabel = 'Schließen';
        /** Breite: 'md' (32rem, Default) oder 'lg' (44rem, z. B. Charts). */
        this.size = 'md';
        this.closed = new EventEmitter();
        this.titleId = `app-dialog-title-${nextId$1++}`;
        /** Element, das vor dem Öffnen den Fokus hatte — für Restore beim Schließen. */
        this.previouslyFocused = null;
        /** Body-Scroll-Sperre: gemerkter vorheriger overflow-Wert für den Restore. */
        this.prevBodyOverflow = null;
        // Drag-to-dismiss (Mobile-Sheet, #14).
        this.dragStartY = 0;
        this.dragStartT = 0;
        this.dragging = false;
        this.dragDy = 0;
    }
    ngOnChanges(changes) {
        const c = changes['open'];
        if (!c || c.firstChange) {
            if (this.open) {
                this.captureAndFocus();
                this.lockScroll();
            }
            return;
        }
        if (!c.previousValue && c.currentValue) {
            this.captureAndFocus();
            this.lockScroll();
        }
        else if (c.previousValue && !c.currentValue) {
            this.restoreFocus();
            this.unlockScroll();
        }
    }
    ngOnDestroy() {
        // Falls der Dialog im offenen Zustand zerstört wird: Scroll-Sperre lösen.
        this.unlockScroll();
    }
    onEscape() {
        if (this.open)
            this.close();
    }
    /** Tab/Shift+Tab im Dialog halten (Focus-Trap). */
    onKeydown(event) {
        if (!this.open || event.key !== 'Tab')
            return;
        const pane = this.pane?.nativeElement;
        if (!pane)
            return;
        const focusables = this.focusable(pane);
        if (focusables.length === 0) {
            event.preventDefault();
            pane.focus();
            return;
        }
        const first = focusables[0];
        const last = focusables[focusables.length - 1];
        const active = document.activeElement;
        if (event.shiftKey && (active === first || active === pane)) {
            event.preventDefault();
            last.focus();
        }
        else if (!event.shiftKey && active === last) {
            event.preventDefault();
            first.focus();
        }
    }
    onBackdrop(_event) {
        this.close();
    }
    // --- Drag-to-dismiss (Mobile-Sheet, #14) -----------------------------------
    onDragStart(event) {
        if (event.touches.length !== 1)
            return;
        this.dragging = true;
        this.dragStartY = event.touches[0].clientY;
        this.dragStartT = event.timeStamp;
        this.dragDy = 0;
        const pane = this.pane?.nativeElement;
        if (pane)
            pane.style.transition = 'none';
    }
    onDragMove(event) {
        if (!this.dragging)
            return;
        // Nur nach unten ziehen (kein „Hochziehen").
        this.dragDy = Math.max(0, event.touches[0].clientY - this.dragStartY);
        const pane = this.pane?.nativeElement;
        if (pane)
            pane.style.transform = `translateY(${this.dragDy}px)`;
    }
    onDragEnd(event) {
        if (!this.dragging)
            return;
        this.dragging = false;
        const pane = this.pane?.nativeElement;
        if (pane)
            pane.style.transition = '';
        const dt = event.timeStamp - this.dragStartT;
        const velocity = this.dragDy / Math.max(1, dt); // px/ms
        // Flick (schnelle Abwärtsbewegung) ODER deutlicher Weg → schließen.
        if (velocity > 0.5 || this.dragDy > 120) {
            this.close();
        }
        else if (pane) {
            pane.style.transform = '';
        }
    }
    close() {
        this.open = false;
        const pane = this.pane?.nativeElement;
        if (pane)
            pane.style.transform = '';
        this.restoreFocus();
        this.unlockScroll();
        this.closed.emit();
    }
    lockScroll() {
        if (this.prevBodyOverflow !== null)
            return;
        this.prevBodyOverflow = document.body.style.overflow;
        document.body.style.overflow = 'hidden';
    }
    unlockScroll() {
        if (this.prevBodyOverflow === null)
            return;
        document.body.style.overflow = this.prevBodyOverflow;
        this.prevBodyOverflow = null;
    }
    /** Vorherigen Fokus merken und Fokus in den Dialog setzen (nach Render). */
    captureAndFocus() {
        this.previouslyFocused = document.activeElement ?? null;
        queueMicrotask(() => {
            const pane = this.pane?.nativeElement;
            if (!pane)
                return;
            const focusables = this.focusable(pane);
            (focusables[0] ?? pane).focus();
        });
    }
    restoreFocus() {
        const target = this.previouslyFocused;
        this.previouslyFocused = null;
        if (target && typeof target.focus === 'function')
            target.focus();
    }
    focusable(root) {
        const selector = [
            'a[href]',
            'button:not([disabled])',
            'input:not([disabled])',
            'select:not([disabled])',
            'textarea:not([disabled])',
            '[tabindex]:not([tabindex="-1"])',
        ].join(',');
        return Array.from(root.querySelectorAll(selector));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DialogComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: DialogComponent, isStandalone: true, selector: "app-dialog", inputs: { open: "open", title: "title", closeLabel: "closeLabel", size: "size" }, outputs: { closed: "closed" }, host: { listeners: { "document:keydown.escape": "onEscape()", "document:keydown": "onKeydown($event)" } }, viewQueries: [{ propertyName: "pane", first: true, predicate: ["pane"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "@if (open) {\n  <div class=\"dialog__backdrop\" (click)=\"onBackdrop($event)\">\n    <div\n      #pane\n      class=\"dialog\"\n      [class.dialog--lg]=\"size === 'lg'\"\n      role=\"dialog\"\n      aria-modal=\"true\"\n      tabindex=\"-1\"\n      [attr.aria-labelledby]=\"titleId\"\n      (click)=\"$event.stopPropagation()\"\n    >\n      <!-- Mobile-Sheet: Greifleiste + Header sind die Drag-Zone zum\n           Herunterwischen (Flick schlie\u00DFt). Auf Desktop ausgeblendet (#14). -->\n      <div\n        class=\"dialog__drag\"\n        (touchstart)=\"onDragStart($event)\"\n        (touchmove)=\"onDragMove($event)\"\n        (touchend)=\"onDragEnd($event)\"\n      >\n        <span class=\"dialog__grabber\" aria-hidden=\"true\"></span>\n        <header class=\"dialog__header\">\n          <h2 class=\"text-xl\" [id]=\"titleId\">{{ title }}</h2>\n          <button\n            type=\"button\"\n            class=\"dialog__close\"\n            [attr.aria-label]=\"closeLabel\"\n            (click)=\"close()\"\n          >\n            \u2715\n          </button>\n        </header>\n      </div>\n      <div class=\"dialog__body\"><ng-content /></div>\n      <footer class=\"dialog__footer\"><ng-content select=\"[dialog-footer]\" /></footer>\n    </div>\n  </div>\n}\n", styles: ["@charset \"UTF-8\";.dialog__backdrop{position:fixed;inset:0;z-index:var(--z-dialog);display:flex;align-items:center;justify-content:center;padding:var(--space-5);background:#00120a8c}.dialog{width:100%;max-width:32rem;background:var(--color-bg-elevated);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);display:flex;flex-direction:column;max-height:85dvh}.dialog--lg{max-width:44rem}.dialog__grabber{display:none}.dialog__header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);padding:var(--space-5) var(--space-5) var(--space-3)}.dialog__close{background:transparent;border:0;cursor:pointer;font-size:var(--fs-lg);color:var(--color-text-muted);border-radius:var(--radius-sm);padding:var(--space-1)}.dialog__body{padding:var(--space-4) var(--space-5);overflow-y:auto;--fade: linear-gradient( to bottom, transparent, #000 var(--space-4), #000 calc(100% - var(--space-4)), transparent );-webkit-mask-image:var(--fade);mask-image:var(--fade)}.dialog__footer{display:flex;justify-content:flex-end;gap:var(--space-3);padding:var(--space-5)}.dialog__footer:empty{display:none}@media(max-width:768px){.dialog__backdrop{align-items:flex-end;padding:0}.dialog{max-width:none;max-height:92dvh;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border-bottom:0;padding-bottom:env(safe-area-inset-bottom,0px);transition:transform .22s var(--ease-standard)}.dialog__drag{touch-action:none}.dialog__grabber{display:block;width:2.25rem;height:.25rem;margin:var(--space-2) auto 0;border-radius:999px;background:var(--color-border-strong)}.dialog__header{padding:var(--space-2) var(--space-4)}.dialog__body{padding:var(--space-4) var(--space-4)}.dialog__footer{padding:var(--space-4);flex-wrap:wrap}}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DialogComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-dialog', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "@if (open) {\n  <div class=\"dialog__backdrop\" (click)=\"onBackdrop($event)\">\n    <div\n      #pane\n      class=\"dialog\"\n      [class.dialog--lg]=\"size === 'lg'\"\n      role=\"dialog\"\n      aria-modal=\"true\"\n      tabindex=\"-1\"\n      [attr.aria-labelledby]=\"titleId\"\n      (click)=\"$event.stopPropagation()\"\n    >\n      <!-- Mobile-Sheet: Greifleiste + Header sind die Drag-Zone zum\n           Herunterwischen (Flick schlie\u00DFt). Auf Desktop ausgeblendet (#14). -->\n      <div\n        class=\"dialog__drag\"\n        (touchstart)=\"onDragStart($event)\"\n        (touchmove)=\"onDragMove($event)\"\n        (touchend)=\"onDragEnd($event)\"\n      >\n        <span class=\"dialog__grabber\" aria-hidden=\"true\"></span>\n        <header class=\"dialog__header\">\n          <h2 class=\"text-xl\" [id]=\"titleId\">{{ title }}</h2>\n          <button\n            type=\"button\"\n            class=\"dialog__close\"\n            [attr.aria-label]=\"closeLabel\"\n            (click)=\"close()\"\n          >\n            \u2715\n          </button>\n        </header>\n      </div>\n      <div class=\"dialog__body\"><ng-content /></div>\n      <footer class=\"dialog__footer\"><ng-content select=\"[dialog-footer]\" /></footer>\n    </div>\n  </div>\n}\n", styles: ["@charset \"UTF-8\";.dialog__backdrop{position:fixed;inset:0;z-index:var(--z-dialog);display:flex;align-items:center;justify-content:center;padding:var(--space-5);background:#00120a8c}.dialog{width:100%;max-width:32rem;background:var(--color-bg-elevated);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg);display:flex;flex-direction:column;max-height:85dvh}.dialog--lg{max-width:44rem}.dialog__grabber{display:none}.dialog__header{display:flex;align-items:center;justify-content:space-between;gap:var(--space-4);padding:var(--space-5) var(--space-5) var(--space-3)}.dialog__close{background:transparent;border:0;cursor:pointer;font-size:var(--fs-lg);color:var(--color-text-muted);border-radius:var(--radius-sm);padding:var(--space-1)}.dialog__body{padding:var(--space-4) var(--space-5);overflow-y:auto;--fade: linear-gradient( to bottom, transparent, #000 var(--space-4), #000 calc(100% - var(--space-4)), transparent );-webkit-mask-image:var(--fade);mask-image:var(--fade)}.dialog__footer{display:flex;justify-content:flex-end;gap:var(--space-3);padding:var(--space-5)}.dialog__footer:empty{display:none}@media(max-width:768px){.dialog__backdrop{align-items:flex-end;padding:0}.dialog{max-width:none;max-height:92dvh;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border-bottom:0;padding-bottom:env(safe-area-inset-bottom,0px);transition:transform .22s var(--ease-standard)}.dialog__drag{touch-action:none}.dialog__grabber{display:block;width:2.25rem;height:.25rem;margin:var(--space-2) auto 0;border-radius:999px;background:var(--color-border-strong)}.dialog__header{padding:var(--space-2) var(--space-4)}.dialog__body{padding:var(--space-4) var(--space-4)}.dialog__footer{padding:var(--space-4);flex-wrap:wrap}}\n"] }]
        }], propDecorators: { open: [{
                type: Input
            }], title: [{
                type: Input
            }], closeLabel: [{
                type: Input
            }], size: [{
                type: Input
            }], closed: [{
                type: Output
            }], pane: [{
                type: ViewChild,
                args: ['pane']
            }], onEscape: [{
                type: HostListener,
                args: ['document:keydown.escape']
            }], onKeydown: [{
                type: HostListener,
                args: ['document:keydown', ['$event']]
            }] } });

/** Schlanke, datengetriebene Tabelle. Für komplexe Fälle später erweiterbar. */
class TableComponent {
    constructor() {
        this.columns = [];
        this.rows = [];
        this.caption = '';
        this.emptyText = 'Keine Einträge';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: TableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: TableComponent, isStandalone: true, selector: "app-table", inputs: { columns: "columns", rows: "rows", caption: "caption", emptyText: "emptyText" }, ngImport: i0, template: "<table class=\"tbl\">\n  @if (caption) {\n    <caption class=\"text-start pb-3 text-muted\">{{ caption }}</caption>\n  }\n  <thead>\n    <tr>\n      @for (col of columns; track col.key) {\n        <th scope=\"col\" [style.text-align]=\"col.align ?? 'start'\">{{ col.label }}</th>\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of rows; track $index) {\n      <tr>\n        @for (col of columns; track col.key) {\n          <td [style.text-align]=\"col.align ?? 'start'\">{{ row[col.key] }}</td>\n        }\n      </tr>\n    } @empty {\n      <tr>\n        <td class=\"text-center text-muted p-6\" [attr.colspan]=\"columns.length\">{{ emptyText }}</td>\n      </tr>\n    }\n  </tbody>\n</table>\n", styles: [".tbl{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}th,td{padding:var(--space-3) var(--space-4);border-bottom:var(--border-width) solid var(--color-border)}th{font-weight:var(--fw-semibold);color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.04em;font-size:var(--fs-xs)}tbody tr:hover{background:var(--color-surface-sunken)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: TableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-table', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<table class=\"tbl\">\n  @if (caption) {\n    <caption class=\"text-start pb-3 text-muted\">{{ caption }}</caption>\n  }\n  <thead>\n    <tr>\n      @for (col of columns; track col.key) {\n        <th scope=\"col\" [style.text-align]=\"col.align ?? 'start'\">{{ col.label }}</th>\n      }\n    </tr>\n  </thead>\n  <tbody>\n    @for (row of rows; track $index) {\n      <tr>\n        @for (col of columns; track col.key) {\n          <td [style.text-align]=\"col.align ?? 'start'\">{{ row[col.key] }}</td>\n        }\n      </tr>\n    } @empty {\n      <tr>\n        <td class=\"text-center text-muted p-6\" [attr.colspan]=\"columns.length\">{{ emptyText }}</td>\n      </tr>\n    }\n  </tbody>\n</table>\n", styles: [".tbl{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}th,td{padding:var(--space-3) var(--space-4);border-bottom:var(--border-width) solid var(--color-border)}th{font-weight:var(--fw-semibold);color:var(--color-text-muted);text-transform:uppercase;letter-spacing:.04em;font-size:var(--fs-xs)}tbody tr:hover{background:var(--color-surface-sunken)}\n"] }]
        }], propDecorators: { columns: [{
                type: Input
            }], rows: [{
                type: Input
            }], caption: [{
                type: Input
            }], emptyText: [{
                type: Input
            }] } });

/**
 * Markiert ein `<ng-template>` als Zell-Renderer einer Spalte der
 * {@link DataTableComponent}: `<ng-template appCell="status" let-row>…`.
 * Der `let-row`-Kontext ist die jeweilige Zeile.
 */
class CellDirective {
    constructor() {
        /** Spalten-Key, für den dieses Template gerendert wird. */
        this.key = '';
        this.tpl = inject(TemplateRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CellDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.25", type: CellDirective, isStandalone: true, selector: "[appCell]", inputs: { key: ["appCell", "key"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CellDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[appCell]', standalone: true }]
        }], propDecorators: { key: [{
                type: Input,
                args: ['appCell']
            }] } });

/**
 * Marks an `<ng-template>` as the FOOTER cell of one column of the
 * {@link DataTableComponent}: `<ng-template appFootCell="amount">…`.
 *
 * Per column rather than one projected `<tr>`, for the same reason `appCell` is per
 * column: a caller writing the whole row has to keep its cell count in step with the
 * column list by hand, and a mismatch is invisible until the table is on screen.
 *
 * A column with no footer template gets an empty cell, so a total can sit under the one
 * column it belongs to without the caller filling in the rest.
 */
class FootCellDirective {
    constructor() {
        /** Column key this template renders the footer cell for. */
        this.key = '';
        this.tpl = inject(TemplateRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FootCellDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.25", type: FootCellDirective, isStandalone: true, selector: "[appFootCell]", inputs: { key: ["appFootCell", "key"] }, ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FootCellDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[appFootCell]', standalone: true }]
        }], propDecorators: { key: [{
                type: Input,
                args: ['appFootCell']
            }] } });

/**
 * Markiert ein `<ng-template>` als ausklappbare Detail-Zeile der
 * {@link DataTableComponent}: `<ng-template appRowDetail let-row>…`. Wird je
 * Zeile gerendert, für die `isExpanded(row)` true ist (volle Breite darunter).
 */
class RowDetailDirective {
    constructor() {
        this.tpl = inject(TemplateRef);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: RowDetailDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive }); }
    static { this.ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "20.3.25", type: RowDetailDirective, isStandalone: true, selector: "[appRowDetail]", ngImport: i0 }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: RowDetailDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[appRowDetail]', standalone: true }]
        }] });

/** How many skeleton rows to draw while loading, when the caller gives no hint. */
const DEFAULT_SKELETON_ROWS = 5;
/** How far one press of a scroll tongue moves the table, in px. */
const SCROLL_STEP = 240;
/** How long a tongue has to be held before it starts repeating. */
const HOLD_DELAY_MS = 300;
/** How often a held tongue scrolls once it repeats. */
const HOLD_INTERVAL_MS = 90;
/**
 * Height of a tongue, for the first sync — before layout there is nothing to measure,
 * and the centring needs a half-height to clamp against. Keep it equal to the height in
 * the stylesheet.
 */
const TONGUE_HEIGHT = 54;
/** Sub-pixel slack, so rounding at an edge does not read as hidden content. */
const EDGE_SLACK = 1;
/** How long a finger must rest on a row before it starts a selection. */
const LONG_PRESS_MS = 500;
/** How far it may drift first. Beyond this the gesture is a scroll, not a press. */
const LONG_PRESS_SLACK = 10;
/**
 * Shared, data-driven table. Columns come as a {@link ColumnDef} list; a single
 * cell can be rendered freely with `<ng-template appCell="key" let-row>` (badges,
 * buttons, links). Without a template the cell shows `row[key]` as text. Boxed by
 * default, optionally with row clicks.
 *
 * This keeps every table visually consistent — one source for the header, the border,
 * the hover, the empty state, the loading state and the sort affordance — instead of
 * each page building its own `<table>`.
 *
 * **Loading:** set `loading` while data is in flight. The table keeps its header and
 * column widths and draws skeleton rows. It deliberately does NOT collapse to the empty
 * state, because "nothing here" and "not here yet" mean different things to a reader.
 */
class DataTableComponent {
    constructor() {
        this.columns = [];
        this.rows = [];
        this.emptyText = '—';
        this.boxed = true;
        /** Makes rows clickable (cursor/tab/enter) and emits `rowClick`. */
        this.clickable = false;
        this.rowClick = new EventEmitter();
        /** Draws skeleton rows instead of the body, keeping the header in place. */
        this.loading = false;
        /** How many skeleton rows to draw. Match it to the usual page size. */
        this.skeletonRowCount = DEFAULT_SKELETON_ROWS;
        /** Announced to a screen reader while `loading`, because the skeleton is hidden. */
        this.loadingText = 'Loading…';
        /**
         * Adds a leading checkbox column and makes rows selectable.
         *
         * The table owns the selection rather than the caller wiring a column of its own,
         * because a hand-built checkbox column has to agree with `rowKey`, with the header's
         * select-all, and with the skeleton — and every table that built one got at least one
         * of those subtly different.
         */
        this.selectable = false;
        /** The selected rows, as `rowKey` values. */
        this.selected = new Set();
        /** Emits the next selection. The caller holds it; the table never mutates the input. */
        this.selectedChange = new EventEmitter();
        /** Accessible name for the select-all checkbox in the header. */
        this.selectAllLabel = 'Select all';
        /** Emits the next sort state when a sortable header is clicked. */
        this.sortChange = new EventEmitter();
        this.zone = inject(NgZone);
        this.cellMap = signal(new Map(), ...(ngDevMode ? [{ debugName: "cellMap" }] : []));
        this.footMap = signal(new Map(), ...(ngDevMode ? [{ debugName: "footMap" }] : []));
        /**
         * True while the scroll container still hides a column past that edge — the condition
         * for showing the tongue that scrolls that way.
         */
        this.hiddenStart = signal(false, ...(ngDevMode ? [{ debugName: "hiddenStart" }] : []));
        this.hiddenEnd = signal(false, ...(ngDevMode ? [{ debugName: "hiddenEnd" }] : []));
        /**
         * True while a tongue is hovered or focused, which lights the cut it moves towards.
         *
         * One flag per side, not one shared: a shared flag lit the far cut while the reader
         * pointed at the near tongue.
         */
        this.cutHot = signal(false, ...(ngDevMode ? [{ debugName: "cutHot" }] : []));
        this.cutHotStart = signal(false, ...(ngDevMode ? [{ debugName: "cutHotStart" }] : []));
        /** Which tongue is held down, for its pressed colour. */
        this.held = signal(0, ...(ngDevMode ? [{ debugName: "held" }] : []));
        this.teardown = [];
        this.pressOrigin = null;
        this.pressWasTouch = false;
        this.pressSelected = false;
        /**
         * Last sideways position, for a redraw that empties the table. Written only while the
         * content overflows: the clamp to 0 that comes with an empty table arrives as a scroll
         * event and would otherwise store the 0 it caused.
         */
        this.keptScrollLeft = 0;
        /** True between the rows coming back and the scroll position being put back. */
        this.restorePending = false;
        /** Whether the table was in the DOM at the previous check. */
        this.wasRendering = false;
        /** Pixel fallback applies only after the table left the DOM, never on a row change. */
        this.restoreFromPixels = false;
        /**
         * Column at the left edge and how far it is cut off, taken before a redraw.
         * `table-layout: auto` re-measures columns from the new rows, so a pixel offset lands
         * on a different column.
         */
        this.anchor = null;
    }
    /** Runs before the redraw, so the geometry is still the old layout. */
    ngOnChanges(changes) {
        if (!changes['rows'] && !changes['columns'])
            return;
        this.captureAnchor();
        this.restorePending = true;
    }
    ngAfterContentInit() {
        const build = () => {
            this.cellMap.set(new Map(this.cellDirs.map((c) => [c.key, c.tpl])));
            this.footMap.set(new Map(this.footDirs.map((c) => [c.key, c.tpl])));
        };
        build();
        this.cellDirs.changes.subscribe(build);
        this.footDirs.changes.subscribe(build);
    }
    cellFor(key) {
        return this.cellMap().get(key) ?? null;
    }
    footCellFor(key) {
        return this.footMap().get(key) ?? null;
    }
    /** True when any column contributes a footer, so `<tfoot>` stays out otherwise. */
    get hasFooter() {
        return this.footMap().size > 0;
    }
    childrenFor(row) {
        return this.childrenOf ? this.childrenOf(row) : [];
    }
    classFor(row, child) {
        return this.rowClass ? this.rowClass(row, child) : null;
    }
    // -- selection --------------------------------------------------------------
    isSelected(row, index) {
        return this.selected.has(this.trackRow(row, index));
    }
    /** True only when every row is selected. An empty table is not "all selected". */
    get allSelected() {
        return this.rows.length > 0 && this.rows.every((r, i) => this.isSelected(r, i));
    }
    /** True when some but not all are selected, for the header's indeterminate state. */
    get someSelected() {
        return !this.allSelected && this.rows.some((r, i) => this.isSelected(r, i));
    }
    toggleRow(row, index) {
        const next = new Set(this.selected);
        const key = this.trackRow(row, index);
        if (next.has(key))
            next.delete(key);
        else
            next.add(key);
        this.selectedChange.emit(next);
    }
    /** Select-all applies to the rows ON SCREEN, which is what the checkbox sits above. */
    toggleAll() {
        if (this.allSelected) {
            this.selectedChange.emit(new Set());
            return;
        }
        this.selectedChange.emit(new Set(this.rows.map((r, i) => this.trackRow(r, i))));
    }
    selectLabel(row, index) {
        return this.rowSelectLabel ? this.rowSelectLabel(row, index) : `Row ${index + 1}`;
    }
    /**
     * Total column count, for a `colspan` that has to span the whole table.
     *
     * The selection column is not in `columns`, so anything spanning the table has to add
     * it back or the detail row comes up one cell short.
     */
    get columnSpan() {
        return this.columns.length + (this.selectable ? 1 : 0);
    }
    text(row, key) {
        return row[key];
    }
    trackRow(row, index) {
        return this.rowKey ? this.rowKey(row, index) : index;
    }
    /**
     * A tap opens the row, unless a selection is under way.
     *
     * Touch only: on a pointer device the checkbox is the way in, and a click that
     * sometimes opened and sometimes selected would be unpredictable.
     */
    onRow(row, index) {
        if (this.pressSelected) {
            // The long press already acted; swallow the click it produced.
            this.pressSelected = false;
            return;
        }
        if (this.selectable && this.pressWasTouch && this.selected.size > 0) {
            this.toggleRow(row, index);
            return;
        }
        if (this.clickable)
            this.rowClick.emit(row);
    }
    /** Start the press timer. A mouse is left alone; it has the checkbox. */
    onRowPressStart(event, row, index) {
        this.pressWasTouch = event.pointerType !== 'mouse';
        this.cancelPress();
        if (!this.selectable || !this.pressWasTouch)
            return;
        this.pressOrigin = { x: event.clientX, y: event.clientY };
        this.pressTimer = setTimeout(() => {
            this.pressTimer = undefined;
            this.pressSelected = true;
            this.toggleRow(row, index);
        }, LONG_PRESS_MS);
    }
    /** A finger that travels is scrolling the list, not holding a row. */
    onRowPressMove(event) {
        if (!this.pressOrigin)
            return;
        const dx = Math.abs(event.clientX - this.pressOrigin.x);
        const dy = Math.abs(event.clientY - this.pressOrigin.y);
        if (dx > LONG_PRESS_SLACK || dy > LONG_PRESS_SLACK)
            this.cancelPress();
    }
    cancelPress() {
        if (this.pressTimer !== undefined)
            clearTimeout(this.pressTimer);
        this.pressTimer = undefined;
        this.pressOrigin = null;
    }
    /** A plain index list, so the template can repeat the skeleton row. */
    skeletonRows() {
        return Array.from({ length: Math.max(1, this.skeletonRowCount) }, (_, i) => i);
    }
    /**
     * Toggle the sort for one column.
     *
     * A new column starts at its own `initialSort`; clicking the active column flips it.
     */
    toggleSort(col) {
        if (!col.sortable)
            return;
        const first = col.initialSort ?? 'asc';
        // Clicking the active column flips it; a new column starts at its own default.
        const direction = this.sort?.key === col.key ? (this.sort.direction === 'asc' ? 'desc' : 'asc') : first;
        this.sortChange.emit({ key: col.key, direction });
    }
    /** `aria-sort` for one header, so the sort is announced and not only drawn. */
    ariaSort(col) {
        if (!col.sortable)
            return null;
        if (this.sort?.key !== col.key)
            return 'none';
        return this.sort.direction === 'asc' ? 'ascending' : 'descending';
    }
    // -- sideways scrolling -----------------------------------------------------
    /** True when a column asks to be pinned, which is what puts a cut in the table. */
    get hasSticky() {
        return this.columns.some((c) => c.sticky === 'end');
    }
    /**
     * Width of the trailing pinned column: how far the cut sits in from the edge.
     *
     * NOT rounded. A column is often a fractional width — 206.5px measured — and rounding
     * moved the cut half a pixel off the column it marks, leaving a sliver of scrolling
     * content between the two. CSS takes the fraction.
     */
    stickyWidth(scroll) {
        const th = scroll.querySelector('thead .dt__cell--stickyEnd');
        return th ? th.getBoundingClientRect().width : 0;
    }
    /** Width of the leading pinned column, if the table has one. Not rounded, as above. */
    stickyStartWidth(scroll) {
        const th = scroll.querySelector('thead .dt__cell--stickyStart');
        return th ? th.getBoundingClientRect().width : 0;
    }
    /**
     * Which edges still hide a column, measured rather than computed.
     *
     * NOT `scrollLeft < scrollWidth - clientWidth`. `.dt__scroll` sets
     * `scrollbar-gutter: stable`, so `scrollWidth - clientWidth` overshoots the maximum
     * the browser actually clamps `scrollLeft` to, by the width of the gutter: measured at
     * 612 against a real maximum of 597 on an 820px viewport, a 15px overshoot that no
     * one-pixel slack can absorb. The end cue then never switched off at full scroll.
     *
     * Geometry answers the question the cue really asks — does a column still stick out
     * past the cut? — and asks it of the same boxes the reader is looking at.
     */
    occluded(scroll, cut) {
        const rect = scroll.getBoundingClientRect();
        const startEdge = rect.left + this.stickyStartWidth(scroll);
        let firstLeft = Number.POSITIVE_INFINITY;
        let lastRight = Number.NEGATIVE_INFINITY;
        for (const cell of Array.from(scroll.querySelectorAll('thead th'))) {
            // A pinned cell never leaves the box, so it can never say something is hidden.
            if (cell.classList.contains('dt__cell--stickyEnd') ||
                cell.classList.contains('dt__cell--stickyStart')) {
                continue;
            }
            const r = cell.getBoundingClientRect();
            if (r.left < firstLeft)
                firstLeft = r.left;
            if (r.right > lastRight)
                lastRight = r.right;
        }
        return { start: firstLeft < startEdge - EDGE_SLACK, end: lastRight > cut + EDGE_SLACK };
    }
    /**
     * Height of the horizontal scrollbar, so nothing is drawn over it.
     *
     * Measured, never assumed: it is 0 on a table that fits, about 15px where a scrollbar
     * shows, and a different number again on another platform.
     */
    gutter(scroll) {
        return Math.max(0, scroll.offsetHeight - scroll.clientHeight);
    }
    /**
     * Centre of the VISIBLE slice of the scroller, in the scroller's own space.
     *
     * The middle of the box is the wrong place on a long table: it leaves the tongues off
     * screen exactly while the reader needs them. Two corrections, both about the bottom
     * edge — the area that counts is the ROWS, so the scrollbar gutter comes off before
     * anything is measured, and the result is then clamped by half a tongue, so a thin
     * visible slice can never push the tongue itself down onto the scrollbar.
     */
    visibleCentre(scroll) {
        const rect = scroll.getBoundingClientRect();
        const rowsTop = rect.top;
        const rowsBottom = rect.bottom - this.gutter(scroll);
        const rowsHeight = Math.max(0, rowsBottom - rowsTop);
        const top = Math.max(rowsTop, 0);
        const bottom = Math.min(rowsBottom, window.innerHeight || 0);
        const centre = bottom <= top ? rowsHeight / 2 : (top + bottom) / 2 - rowsTop;
        // +1 keeps the tongue's own border clear of the gutter as well as its box.
        const half = (this.endTongue?.nativeElement.offsetHeight || TONGUE_HEIGHT) / 2 + 1;
        if (rowsHeight - half < half)
            return rowsHeight / 2; // shorter than the tongue
        return Math.min(Math.max(centre, half), rowsHeight - half);
    }
    /** Recompute which edges hide content, and where the cut and the tongues belong. */
    onScroll() {
        const scroll = this.scroller?.nativeElement;
        const box = this.box?.nativeElement;
        if (!scroll || !box)
            return;
        const cueRight = this.stickyWidth(scroll);
        const edges = this.occluded(scroll, scroll.getBoundingClientRect().right - cueRight);
        this.hiddenStart.set(edges.start);
        this.hiddenEnd.set(edges.end);
        box.style.setProperty('--cue-right', `${cueRight}px`);
        box.style.setProperty('--cue-left', `${this.stickyStartWidth(scroll)}px`);
        box.style.setProperty('--cue-top', `${Math.round(this.visibleCentre(scroll))}px`);
        box.style.setProperty('--cut-bottom', `${this.gutter(scroll)}px`);
        if (scroll.scrollWidth - scroll.clientWidth > EDGE_SLACK) {
            this.keptScrollLeft = scroll.scrollLeft;
        }
    }
    /** `cut` is how much of the column has passed the edge. */
    captureAnchor() {
        const scroll = this.scroller?.nativeElement;
        if (!scroll || scroll.scrollLeft <= EDGE_SLACK) {
            this.anchor = null;
            return;
        }
        const edge = scroll.getBoundingClientRect().left + this.stickyStartWidth(scroll);
        const cells = scroll.querySelectorAll('thead th');
        for (let i = 0; i < cells.length; i++) {
            // The leading pin sits at that edge by definition; anchoring to it never moves.
            if (cells[i].classList.contains('dt__cell--stickyStart'))
                continue;
            const box = cells[i].getBoundingClientRect();
            if (box.right > edge + EDGE_SLACK) {
                this.anchor = { index: i, cut: Math.round(edge - box.left) };
                return;
            }
        }
        this.anchor = null;
    }
    /**
     * A frame later and outside Angular: widths exist only after layout, and setting the
     * cue signals from a lifecycle hook trips ExpressionChangedAfterItHasBeenChecked.
     */
    restoreScroll() {
        this.zone.runOutsideAngular(() => {
            requestAnimationFrame(() => {
                const scroll = this.scroller?.nativeElement;
                if (!scroll)
                    return;
                const max = scroll.scrollWidth - scroll.clientWidth;
                if (max > EDGE_SLACK) {
                    const cells = scroll.querySelectorAll('thead th');
                    const cell = this.anchor ? cells[this.anchor.index] : undefined;
                    if (cell && this.anchor) {
                        const edge = scroll.getBoundingClientRect().left + this.stickyStartWidth(scroll);
                        const drift = cell.getBoundingClientRect().left - (edge - this.anchor.cut);
                        const target = scroll.scrollLeft + drift;
                        scroll.scrollLeft = Math.max(0, Math.min(target, max));
                        // One redraw, one anchor: a second pass would add the drift again.
                        this.anchor = null;
                    }
                    else if (this.restoreFromPixels && this.keptScrollLeft > 0 && scroll.scrollLeft === 0) {
                        scroll.scrollLeft = Math.min(this.keptScrollLeft, max);
                    }
                }
                this.restoreFromPixels = false;
                this.onScroll();
            });
        });
    }
    /** One step sideways. Instant where the reader asked for less motion. */
    step(direction) {
        const el = this.scroller?.nativeElement;
        if (!el)
            return;
        const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;
        el.scrollBy({ left: direction * SCROLL_STEP, behavior: reduced ? 'auto' : 'smooth' });
    }
    /**
     * Press to step, hold to keep going.
     *
     * A reader who does not know shift+scroll should not have to click fifteen times to
     * cross a wide table.
     */
    onTonguePress(event, direction) {
        if (event.button !== 0)
            return;
        this.stopHold();
        this.step(direction);
        this.held.set(direction);
        this.holdTimer = setTimeout(() => {
            this.holdTick = setInterval(() => this.step(direction), HOLD_INTERVAL_MS);
        }, HOLD_DELAY_MS);
    }
    /** Release, leave or cancel: the repeat stops with the gesture that started it. */
    stopHold() {
        if (this.holdTimer !== undefined)
            clearTimeout(this.holdTimer);
        if (this.holdTick !== undefined)
            clearInterval(this.holdTick);
        this.holdTimer = undefined;
        this.holdTick = undefined;
        this.held.set(0);
    }
    /**
     * Enter and Space step once and do not repeat: the key repeat of the platform already
     * does that, and two repeats would race.
     */
    onTongueKey(event, direction) {
        if (event.key !== 'Enter' && event.key !== ' ')
            return;
        event.preventDefault(); // Space would otherwise scroll the page
        this.step(direction);
    }
    ngAfterViewInit() {
        // A table can already overflow before anyone scrolls it.
        this.onScroll();
        // Outside Angular: a page scroll fires this for every table on the page, and none of
        // that has to run change detection. The signals it sets schedule their own.
        this.zone.runOutsideAngular(() => {
            const resync = () => this.onScroll();
            window.addEventListener('scroll', resync, { passive: true });
            window.addEventListener('resize', resync);
            this.teardown.push(() => {
                window.removeEventListener('scroll', resync);
                window.removeEventListener('resize', resync);
            });
            // The width all of this depends on changes without anyone scrolling: a cell
            // template arrives, a sidebar opens, the font loads.
            if (typeof ResizeObserver !== 'undefined' && this.scroller) {
                const ro = new ResizeObserver(resync);
                ro.observe(this.scroller.nativeElement);
                this.teardown.push(() => ro.disconnect());
            }
        });
    }
    /** The template draws the table under `loading || rows.length`; watch that edge. */
    ngAfterViewChecked() {
        const rendering = this.loading || this.rows.length > 0;
        if (rendering && !this.wasRendering) {
            this.restorePending = true;
            this.restoreFromPixels = true;
        }
        this.wasRendering = rendering;
        if (this.restorePending) {
            this.restorePending = false;
            this.restoreScroll();
        }
    }
    ngOnDestroy() {
        this.stopHold();
        this.cancelPress();
        for (const off of this.teardown)
            off();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DataTableComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: DataTableComponent, isStandalone: true, selector: "app-data-table", inputs: { columns: "columns", rows: "rows", emptyText: "emptyText", boxed: "boxed", rowKey: "rowKey", clickable: "clickable", isExpanded: "isExpanded", loading: "loading", skeletonRowCount: "skeletonRowCount", loadingText: "loadingText", selectable: "selectable", selected: "selected", selectAllLabel: "selectAllLabel", rowSelectLabel: "rowSelectLabel", childrenOf: "childrenOf", rowClass: "rowClass", sort: "sort" }, outputs: { rowClick: "rowClick", selectedChange: "selectedChange", sortChange: "sortChange" }, queries: [{ propertyName: "rowDetail", first: true, predicate: RowDetailDirective, descendants: true }, { propertyName: "cellDirs", predicate: CellDirective }, { propertyName: "footDirs", predicate: FootCellDirective }], viewQueries: [{ propertyName: "scroller", first: true, predicate: ["scroller"], descendants: true }, { propertyName: "box", first: true, predicate: ["box"], descendants: true }, { propertyName: "endTongue", first: true, predicate: ["endTongue"], descendants: true }], usesOnChanges: true, ngImport: i0, template: "<!-- A wide table scrolls inside its own box instead of pushing the page sideways. The\n     cut and the tongues sit on this wrapper rather than on the scroller, so they stay\n     put while the content moves under them. -->\n<div\n  #box\n  class=\"dt\"\n  [class.dt--boxed]=\"boxed && (loading || rows.length > 0)\"\n  [class.dt--cut-start]=\"hiddenStart()\"\n  [class.dt--cut-end]=\"hiddenEnd()\"\n  [class.dt--cut-hot]=\"cutHot()\"\n  [class.dt--cut-hot-start]=\"cutHotStart()\"\n>\n  <div #scroller class=\"dt__scroll\" (scroll)=\"onScroll()\">\n    @if (loading || rows.length > 0) {\n      <table class=\"dt__table\">\n        <thead>\n          <tr>\n            @if (selectable) {\n              <th scope=\"col\" class=\"dt__selectCell dt__cell--stickyStart\">\n                <input\n                  type=\"checkbox\"\n                  class=\"dt__check\"\n                  [attr.aria-label]=\"selectAllLabel\"\n                  [checked]=\"allSelected\"\n                  [indeterminate]=\"someSelected\"\n                  [disabled]=\"loading\"\n                  (change)=\"toggleAll()\"\n                />\n              </th>\n            }\n            @for (col of columns; track col.key) {\n              <th\n                scope=\"col\"\n                [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                [style.text-align]=\"col.align ?? 'start'\"\n                [style.width]=\"col.width || null\"\n                [style.minWidth]=\"col.width || null\"\n                [attr.aria-sort]=\"ariaSort(col)\"\n              >\n                <!-- A sortable header is a button, so it is reachable by keyboard and\n                     announced as an action. A plain header stays plain text. -->\n                @if (col.sortable) {\n                  <button type=\"button\" class=\"dt__sort\" (click)=\"toggleSort(col)\">\n                    <span>{{ col.label }}</span>\n                    <span class=\"dt__sort-icon\" [class.dt__sort-icon--on]=\"sort?.key === col.key\">\n                      @if (sort?.key === col.key && sort?.direction === 'desc') {\n                        \u2193\n                      } @else if (sort?.key === col.key) {\n                        \u2191\n                      } @else {\n                        \u2195\n                      }\n                    </span>\n                  </button>\n                } @else {\n                  {{ col.label }}\n                }\n              </th>\n            }\n          </tr>\n        </thead>\n        <tbody>\n          @if (loading) {\n            <!-- Skeleton rows keep the header, the column widths and the height of the\n                 box while data loads. Without them the table collapses to its empty\n                 state and the page jumps, which reads as \"no results\" rather than\n                 \"still loading\". -->\n            @for (row of skeletonRows(); track row) {\n              <tr class=\"dt__skeleton-row\" aria-hidden=\"true\">\n                @if (selectable) {\n                  <td class=\"dt__selectCell dt__cell--stickyStart\"><span class=\"dt__skeleton\"></span></td>\n                }\n                @for (col of columns; track col.key) {\n                  <td\n                    [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                    [style.text-align]=\"col.align ?? 'start'\"\n                    [attr.data-label]=\"col.label\"\n                    [attr.data-card]=\"col.card ?? null\"\n                  >\n                    <span class=\"dt__skeleton\"></span>\n                  </td>\n                }\n              </tr>\n            }\n          } @else {\n            @for (row of rows; track trackRow(row, $index); let i = $index) {\n              <tr\n                [class]=\"classFor(row, false)\"\n                [class.dt__row--clickable]=\"clickable\"\n                [class.dt__row--selected]=\"selectable && isSelected(row, i)\"\n                (click)=\"onRow(row, i)\"\n                [attr.tabindex]=\"clickable ? 0 : null\"\n                (keydown.enter)=\"onRow(row, i)\"\n                (pointerdown)=\"onRowPressStart($event, row, i)\"\n                (pointermove)=\"onRowPressMove($event)\"\n                (pointerup)=\"cancelPress()\"\n                (pointercancel)=\"cancelPress()\"\n              >\n                @if (selectable) {\n                  <td class=\"dt__selectCell dt__cell--stickyStart\">\n                    <!-- `click.stop`: a selectable table is often also clickable, and a\n                         checkbox that also opened the row would make the two impossible\n                         to tell apart. -->\n                    <input\n                      type=\"checkbox\"\n                      class=\"dt__check\"\n                      [attr.aria-label]=\"selectLabel(row, i)\"\n                      [checked]=\"isSelected(row, i)\"\n                      (click)=\"$event.stopPropagation()\"\n                      (change)=\"toggleRow(row, i)\"\n                    />\n                  </td>\n                }\n                @for (col of columns; track col.key) {\n                  <td\n                    [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                    [style.text-align]=\"col.align ?? 'start'\"\n                    [attr.data-label]=\"col.label\"\n                    [attr.data-card]=\"col.card ?? null\"\n                  >\n                    @if (cellFor(col.key); as tpl) {\n                      <ng-container\n                        [ngTemplateOutlet]=\"tpl\"\n                        [ngTemplateOutletContext]=\"{ $implicit: row, index: i, child: false }\"\n                      />\n                    } @else {\n                      {{ text(row, col.key) }}\n                    }\n                  </td>\n                }\n              </tr>\n\n              <!-- Child rows repeat the parent's columns with the caller's own cell\n                   templates, so a sub-record lines up column for column instead of\n                   being a panel underneath. `child: true` lets one template render both. -->\n              @for (kid of childrenFor(row); track trackRow(kid, $index)) {\n                <tr class=\"dt__childRow\" [class]=\"classFor(kid, true)\">\n                  @if (selectable) {\n                    <td class=\"dt__selectCell dt__cell--stickyStart\"></td>\n                  }\n                  @for (col of columns; track col.key) {\n                    <td\n                      [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                      [style.text-align]=\"col.align ?? 'start'\"\n                      [attr.data-label]=\"col.label\"\n                      [attr.data-card]=\"col.card ?? null\"\n                    >\n                      @if (cellFor(col.key); as tpl) {\n                        <ng-container\n                          [ngTemplateOutlet]=\"tpl\"\n                          [ngTemplateOutletContext]=\"{ $implicit: kid, index: i, child: true }\"\n                        />\n                      } @else {\n                        {{ text(kid, col.key) }}\n                      }\n                    </td>\n                  }\n                </tr>\n              }\n\n              @if (rowDetail && isExpanded && isExpanded(row)) {\n                <tr class=\"dt__detail-row\">\n                  <td [attr.colspan]=\"columnSpan\">\n                    <ng-container\n                      [ngTemplateOutlet]=\"rowDetail.tpl\"\n                      [ngTemplateOutletContext]=\"{ $implicit: row }\"\n                    />\n                  </td>\n                </tr>\n              }\n            }\n          }\n        </tbody>\n\n        <!-- A totals row belongs to the table, not below it: it has to keep the column\n             widths, or a sum stops sitting under the column it sums. -->\n        @if (hasFooter && !loading && rows.length > 0) {\n          <tfoot>\n            <tr>\n              @if (selectable) {\n                <td class=\"dt__selectCell dt__cell--stickyStart\"></td>\n              }\n              @for (col of columns; track col.key) {\n                <td\n                  [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                  [style.text-align]=\"col.align ?? 'start'\"\n                  [attr.data-label]=\"col.label\"\n                  [attr.data-card]=\"col.card ?? null\"\n                >\n                  @if (footCellFor(col.key); as tpl) {\n                    <ng-container [ngTemplateOutlet]=\"tpl\" />\n                  }\n                </td>\n              }\n            </tr>\n          </tfoot>\n        }\n      </table>\n    } @else {\n      <div class=\"empty-state\">{{ emptyText }}</div>\n    }\n  </div>\n\n  <!-- The cuts: where the scrolling content passes beneath a pinned column. A rule with\n       a short shadow thrown away from the pin, stopping above the scrollbar. Only a\n       pinned column makes a cut \u2014 at the table's own outer edge the box border is\n       already the boundary, and a second rule there would be noise. -->\n  @if (hasSticky) {\n    <div class=\"dt__cutline\" aria-hidden=\"true\"></div>\n  }\n  @if (selectable) {\n    <div class=\"dt__cutline dt__cutline--start\" aria-hidden=\"true\"></div>\n  }\n\n  <!-- The tongues: the sideways scroll control for a reader with a plain mouse. Shift+\n       scroll is invisible knowledge and a wheel alone moves nothing sideways, so without\n       these the hidden columns cannot be reached at all.\n\n       Both stay in the DOM and are disabled while their edge hides nothing, so the\n       opacity can carry the change and neither takes a tab stop while invisible. -->\n  <button\n    type=\"button\"\n    class=\"dt__tongue dt__tongue--start\"\n    [class.dt__tongue--held]=\"held() === -1\"\n    [disabled]=\"!hiddenStart()\"\n    [attr.aria-hidden]=\"hiddenStart() ? null : 'true'\"\n    [attr.aria-label]=\"'table.scrollStart' | uiKitT\"\n    (pointerdown)=\"onTonguePress($event, -1)\"\n    (pointerup)=\"stopHold()\"\n    (mouseenter)=\"cutHotStart.set(true)\"\n    (mouseleave)=\"cutHotStart.set(false)\"\n    (pointerleave)=\"stopHold()\"\n    (pointercancel)=\"stopHold()\"\n    (focus)=\"cutHotStart.set(true)\"\n    (blur)=\"cutHotStart.set(false)\"\n    (keydown)=\"onTongueKey($event, -1)\"\n  >\n    <svg viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\n      <path\n        d=\"M10 3L5 8l5 5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n\n  <button\n    #endTongue\n    type=\"button\"\n    class=\"dt__tongue dt__tongue--end\"\n    [class.dt__tongue--held]=\"held() === 1\"\n    [disabled]=\"!hiddenEnd()\"\n    [attr.aria-hidden]=\"hiddenEnd() ? null : 'true'\"\n    [attr.aria-label]=\"'table.scrollEnd' | uiKitT\"\n    (pointerdown)=\"onTonguePress($event, 1)\"\n    (pointerup)=\"stopHold()\"\n    (pointercancel)=\"stopHold()\"\n    (mouseenter)=\"cutHot.set(true)\"\n    (mouseleave)=\"cutHot.set(false)\"\n    (pointerleave)=\"stopHold()\"\n    (focus)=\"cutHot.set(true)\"\n    (blur)=\"cutHot.set(false)\"\n    (keydown)=\"onTongueKey($event, 1)\"\n  >\n    <svg viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\n      <path\n        d=\"M6 3l5 5-5 5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n</div>\n\n<!-- Announced separately, because the skeleton rows are aria-hidden: a screen reader\n     otherwise hears nothing at all while the table loads. -->\n@if (loading) {\n  <span class=\"dt__sr-only\" role=\"status\">{{ loadingText }}</span>\n}\n", styles: ["@charset \"UTF-8\";.dt{position:relative;--pin-overhang: 2px;--pin-line: var(--color-border)}.dt__scroll{overflow-x:auto;overflow-y:hidden;scrollbar-gutter:stable}.dt__cutline{position:absolute;top:0;bottom:var(--cut-bottom, 0px);right:var(--cue-right, 0px);width:1px;background:var(--color-border);box-shadow:var(--shadow-cut);opacity:0;pointer-events:none;z-index:3;transition:opacity var(--motion-base, .2s) var(--ease-standard, ease),background var(--motion-fast, .12s) var(--ease-standard, ease),box-shadow var(--motion-fast, .12s) var(--ease-standard, ease)}.dt__cutline--start{right:auto;left:var(--cue-left, 0px);background:transparent;box-shadow:var(--shadow-cut-start)}.dt--cut-end .dt__cutline:not(.dt__cutline--start),.dt--cut-start .dt__cutline--start{opacity:1}.dt--cut-hot .dt__cutline:not(.dt__cutline--start){background:var(--color-primary);box-shadow:var(--shadow-cut-strong)}.dt--cut-hot-start .dt__cutline--start{box-shadow:var(--shadow-cut-start-strong)}.dt--cut-hot-start{--pin-line: var(--color-primary)}.dt__tongue{position:absolute;top:var(--cue-top, 50%);transform:translateY(-50%);width:18px;height:54px;z-index:4;display:grid;place-items:center;padding:0;cursor:pointer;background:var(--color-surface-sunken);color:var(--color-text-muted);border:var(--border-width) solid var(--color-border);box-shadow:var(--shadow-sm);opacity:0;pointer-events:none;transition:opacity var(--motion-base, .2s) var(--ease-standard, ease),background var(--motion-fast, .12s) var(--ease-standard, ease),color var(--motion-fast, .12s) var(--ease-standard, ease),border-color var(--motion-fast, .12s) var(--ease-standard, ease)}.dt__tongue:hover,.dt__tongue--held{background:var(--color-primary);color:var(--color-on-primary);border-color:var(--color-primary)}.dt__tongue:focus-visible{outline:2px solid var(--color-focus-ring, var(--color-primary));outline-offset:2px}.dt__tongue svg{width:13px;height:13px;display:block}.dt__tongue--end{right:var(--cue-right, 0px);border-right:0;border-radius:var(--radius-md) 0 0 var(--radius-md)}.dt__tongue--start{left:var(--cue-left, 0px);border-left:0;border-radius:0 var(--radius-md) var(--radius-md) 0}.dt--cut-end .dt__tongue--end,.dt--cut-start .dt__tongue--start{opacity:1;pointer-events:auto}@media(max-width:768px){.dt__cutline,.dt__tongue{display:none}}@media(prefers-reduced-motion:reduce){.dt__cutline,.dt__tongue,.dt__table .dt__cell--stickyStart{transition:none}}.dt__sort{display:inline-flex;align-items:center;gap:var(--space-2);padding:0;border:0;background:none;font:inherit;color:inherit;text-transform:inherit;letter-spacing:inherit;cursor:pointer}.dt__sort:hover .dt__sort-icon,.dt__sort:focus-visible .dt__sort-icon{opacity:1}.dt__sort:focus-visible{outline:2px solid var(--color-focus-ring);outline-offset:2px}.dt__sort-icon{opacity:.35;transition:opacity var(--motion-fast, .12s) var(--ease-standard, ease)}.dt__sort-icon--on{opacity:1;color:var(--color-primary)}.dt__skeleton{display:block;height:.75rem;width:60%;border-radius:var(--radius-sm, 4px);background:var(--color-surface-sunken);animation:dt-pulse 1.4s var(--ease-standard, ease) infinite}.dt__skeleton-row td:first-child .dt__skeleton{width:80%}@keyframes dt-pulse{0%,to{opacity:.5}50%{opacity:1}}@media(prefers-reduced-motion:reduce){.dt__skeleton{animation:none}}.dt__sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.dt--boxed{background:var(--color-surface);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden}.dt__table{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}.dt__table th{text-align:start;padding:var(--space-3) var(--space-4);font-size:var(--fs-xs);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:.04em;color:var(--color-text-muted);background:var(--color-surface-sunken);border-bottom:var(--border-width) solid var(--color-border)}.dt__table tbody tr{height:3rem}.dt__table td{padding:0 var(--space-4);border-bottom:var(--border-width) solid var(--color-border);vertical-align:middle}.dt__cell--stickyEnd{position:sticky;right:0;border-inline-start:var(--border-width) solid var(--color-border)}.dt__cell--stickyStart{position:sticky;left:0;border-inline-end:var(--border-width) solid transparent}.dt__cell--stickyStart:after{content:\"\";position:absolute;top:calc(-1 * var(--border-width));bottom:calc(-1 * var(--border-width));right:calc(-1 * var(--border-width));width:var(--border-width);background:var(--pin-line);pointer-events:none;transition:background var(--motion-fast, .12s) var(--ease-standard, ease)}.dt__table td.dt__cell--stickyEnd,.dt__table td.dt__cell--stickyStart{--pin-bg: var(--color-surface);background:var(--pin-bg);z-index:1}.dt__table td.dt__cell--stickyEnd{box-shadow:calc(-1 * var(--pin-overhang)) 0 0 0 var(--pin-bg)}.dt__table th.dt__cell--stickyEnd,.dt__table th.dt__cell--stickyStart{--pin-bg: var(--color-surface-sunken);background:var(--pin-bg);z-index:2}.dt__table th.dt__cell--stickyEnd{box-shadow:calc(-1 * var(--pin-overhang)) 0 0 0 var(--pin-bg)}.dt__selectCell{width:3rem;text-align:center}.dt__check{cursor:pointer;accent-color:var(--color-primary)}.dt__table tbody tr.dt__row--selected td{background:var(--color-surface-sunken)}.dt__childRow>td{background:var(--color-surface-raised, var(--color-surface-sunken));font-size:var(--fs-xs)}.dt__childRow>td:first-child{padding-inline-start:var(--space-6)}.dt__table tfoot td{padding:var(--space-3) var(--space-4);border-top:2px solid var(--color-border-strong);font-weight:var(--fw-semibold);background:var(--color-surface)}.dt__table tfoot td.dt__cell--stickyEnd,.dt__table tfoot td.dt__cell--stickyStart{--pin-bg: var(--color-surface)}.dt__row--clickable{cursor:pointer}.dt__table tbody tr:hover td,.dt__row--clickable:focus-visible td,.dt__row--clickable:active td{background:var(--color-surface-sunken)}.dt__table tbody tr:hover td.dt__cell--stickyEnd,.dt__table tbody tr:hover td.dt__cell--stickyStart,.dt__row--clickable:focus-visible td.dt__cell--stickyEnd,.dt__row--clickable:focus-visible td.dt__cell--stickyStart,.dt__row--clickable:active td.dt__cell--stickyEnd,.dt__row--clickable:active td.dt__cell--stickyStart{--pin-bg: var(--color-surface-sunken)}.dt__detail-row>td{padding:0;background:var(--color-surface-raised, var(--color-surface-sunken))}.dt__empty{text-align:center;color:var(--color-text-muted);padding:var(--space-6)!important}@media(max-width:768px){.dt__table,.dt__table tbody{display:block;width:100%}.dt__table thead{display:none}.dt__table tbody tr{display:flex;flex-direction:column;height:auto;padding:var(--space-3) var(--space-4);border-bottom:var(--border-width) solid var(--color-border)}.dt__table tbody tr:last-child{border-bottom:0}.dt__table td{display:flex;align-items:baseline;justify-content:space-between;gap:var(--space-4);padding:var(--space-1) 0;border-bottom:0;text-align:end!important;min-width:0;overflow-wrap:anywhere}.dt__table td[data-label]:before{content:attr(data-label);flex:none;font-size:var(--fs-xs);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:.04em;color:var(--color-text-muted)}.dt__table td[data-label=\"\"]:before{content:none}.dt__table td[data-card=hidden]{display:none}.dt__table td[data-card=title],.dt__table tbody tr:not(:has(td[data-card=title])) td:first-child:not(.dt__selectCell),.dt__table tbody tr:not(:has(td[data-card=title])) .dt__selectCell+td{flex-direction:column;align-items:flex-start;gap:var(--space-1);text-align:start!important}.dt__table td[data-card=title]{order:-1;padding-block-end:var(--space-2);font-weight:var(--fw-semibold)}.dt__table td[data-card=title]:before{content:none}.dt__table tbody tr:has(.dt__selectCell){position:relative}.dt__table .dt__selectCell{position:absolute;inset-block-start:var(--space-3);inset-inline-end:var(--space-4);padding:0}.dt__table tbody tr:has(.dt__selectCell) td[data-card=title],.dt__table tbody tr:has(.dt__selectCell):not(:has(td[data-card=title])) .dt__selectCell+td{padding-inline-end:var(--space-6)}.dt__table td>*{min-width:0;max-width:100%}.dt__detail-row,.dt__detail-row>td,.dt__empty{display:block}.dt__detail-row,.dt__detail-row>td{text-align:start!important}.dt__empty{text-align:center!important}.dt__table tbody tr:hover,.dt__row--clickable:focus-visible,.dt__row--clickable:active{background:var(--color-surface-sunken)}.dt__table tbody tr:hover td,.dt__row--clickable:focus-visible td,.dt__row--clickable:active td{background:transparent}.dt__detail-row{padding:0}.dt__cell--stickyEnd{position:static}.dt__table td.dt__cell--stickyEnd,.dt__table td.dt__cell--stickyStart,.dt__cell--stickyEnd,.dt__cell--stickyStart{background:none;box-shadow:none;z-index:auto;border-inline-start:0;border-inline-end:0}.dt__selectCell{width:auto;flex-direction:row;justify-content:flex-start;padding-block-end:var(--space-2)}.dt__selectCell:before{content:none}.dt__selectCell:empty{display:none}.dt__childRow{margin-inline-start:var(--space-4)}.dt__childRow>td:first-child{padding-inline-start:0}}.dt__table tbody tr{-webkit-touch-callout:none}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: DataTableComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-data-table', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [NgTemplateOutlet, UiKitTranslatePipe], template: "<!-- A wide table scrolls inside its own box instead of pushing the page sideways. The\n     cut and the tongues sit on this wrapper rather than on the scroller, so they stay\n     put while the content moves under them. -->\n<div\n  #box\n  class=\"dt\"\n  [class.dt--boxed]=\"boxed && (loading || rows.length > 0)\"\n  [class.dt--cut-start]=\"hiddenStart()\"\n  [class.dt--cut-end]=\"hiddenEnd()\"\n  [class.dt--cut-hot]=\"cutHot()\"\n  [class.dt--cut-hot-start]=\"cutHotStart()\"\n>\n  <div #scroller class=\"dt__scroll\" (scroll)=\"onScroll()\">\n    @if (loading || rows.length > 0) {\n      <table class=\"dt__table\">\n        <thead>\n          <tr>\n            @if (selectable) {\n              <th scope=\"col\" class=\"dt__selectCell dt__cell--stickyStart\">\n                <input\n                  type=\"checkbox\"\n                  class=\"dt__check\"\n                  [attr.aria-label]=\"selectAllLabel\"\n                  [checked]=\"allSelected\"\n                  [indeterminate]=\"someSelected\"\n                  [disabled]=\"loading\"\n                  (change)=\"toggleAll()\"\n                />\n              </th>\n            }\n            @for (col of columns; track col.key) {\n              <th\n                scope=\"col\"\n                [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                [style.text-align]=\"col.align ?? 'start'\"\n                [style.width]=\"col.width || null\"\n                [style.minWidth]=\"col.width || null\"\n                [attr.aria-sort]=\"ariaSort(col)\"\n              >\n                <!-- A sortable header is a button, so it is reachable by keyboard and\n                     announced as an action. A plain header stays plain text. -->\n                @if (col.sortable) {\n                  <button type=\"button\" class=\"dt__sort\" (click)=\"toggleSort(col)\">\n                    <span>{{ col.label }}</span>\n                    <span class=\"dt__sort-icon\" [class.dt__sort-icon--on]=\"sort?.key === col.key\">\n                      @if (sort?.key === col.key && sort?.direction === 'desc') {\n                        \u2193\n                      } @else if (sort?.key === col.key) {\n                        \u2191\n                      } @else {\n                        \u2195\n                      }\n                    </span>\n                  </button>\n                } @else {\n                  {{ col.label }}\n                }\n              </th>\n            }\n          </tr>\n        </thead>\n        <tbody>\n          @if (loading) {\n            <!-- Skeleton rows keep the header, the column widths and the height of the\n                 box while data loads. Without them the table collapses to its empty\n                 state and the page jumps, which reads as \"no results\" rather than\n                 \"still loading\". -->\n            @for (row of skeletonRows(); track row) {\n              <tr class=\"dt__skeleton-row\" aria-hidden=\"true\">\n                @if (selectable) {\n                  <td class=\"dt__selectCell dt__cell--stickyStart\"><span class=\"dt__skeleton\"></span></td>\n                }\n                @for (col of columns; track col.key) {\n                  <td\n                    [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                    [style.text-align]=\"col.align ?? 'start'\"\n                    [attr.data-label]=\"col.label\"\n                    [attr.data-card]=\"col.card ?? null\"\n                  >\n                    <span class=\"dt__skeleton\"></span>\n                  </td>\n                }\n              </tr>\n            }\n          } @else {\n            @for (row of rows; track trackRow(row, $index); let i = $index) {\n              <tr\n                [class]=\"classFor(row, false)\"\n                [class.dt__row--clickable]=\"clickable\"\n                [class.dt__row--selected]=\"selectable && isSelected(row, i)\"\n                (click)=\"onRow(row, i)\"\n                [attr.tabindex]=\"clickable ? 0 : null\"\n                (keydown.enter)=\"onRow(row, i)\"\n                (pointerdown)=\"onRowPressStart($event, row, i)\"\n                (pointermove)=\"onRowPressMove($event)\"\n                (pointerup)=\"cancelPress()\"\n                (pointercancel)=\"cancelPress()\"\n              >\n                @if (selectable) {\n                  <td class=\"dt__selectCell dt__cell--stickyStart\">\n                    <!-- `click.stop`: a selectable table is often also clickable, and a\n                         checkbox that also opened the row would make the two impossible\n                         to tell apart. -->\n                    <input\n                      type=\"checkbox\"\n                      class=\"dt__check\"\n                      [attr.aria-label]=\"selectLabel(row, i)\"\n                      [checked]=\"isSelected(row, i)\"\n                      (click)=\"$event.stopPropagation()\"\n                      (change)=\"toggleRow(row, i)\"\n                    />\n                  </td>\n                }\n                @for (col of columns; track col.key) {\n                  <td\n                    [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                    [style.text-align]=\"col.align ?? 'start'\"\n                    [attr.data-label]=\"col.label\"\n                    [attr.data-card]=\"col.card ?? null\"\n                  >\n                    @if (cellFor(col.key); as tpl) {\n                      <ng-container\n                        [ngTemplateOutlet]=\"tpl\"\n                        [ngTemplateOutletContext]=\"{ $implicit: row, index: i, child: false }\"\n                      />\n                    } @else {\n                      {{ text(row, col.key) }}\n                    }\n                  </td>\n                }\n              </tr>\n\n              <!-- Child rows repeat the parent's columns with the caller's own cell\n                   templates, so a sub-record lines up column for column instead of\n                   being a panel underneath. `child: true` lets one template render both. -->\n              @for (kid of childrenFor(row); track trackRow(kid, $index)) {\n                <tr class=\"dt__childRow\" [class]=\"classFor(kid, true)\">\n                  @if (selectable) {\n                    <td class=\"dt__selectCell dt__cell--stickyStart\"></td>\n                  }\n                  @for (col of columns; track col.key) {\n                    <td\n                      [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                      [style.text-align]=\"col.align ?? 'start'\"\n                      [attr.data-label]=\"col.label\"\n                      [attr.data-card]=\"col.card ?? null\"\n                    >\n                      @if (cellFor(col.key); as tpl) {\n                        <ng-container\n                          [ngTemplateOutlet]=\"tpl\"\n                          [ngTemplateOutletContext]=\"{ $implicit: kid, index: i, child: true }\"\n                        />\n                      } @else {\n                        {{ text(kid, col.key) }}\n                      }\n                    </td>\n                  }\n                </tr>\n              }\n\n              @if (rowDetail && isExpanded && isExpanded(row)) {\n                <tr class=\"dt__detail-row\">\n                  <td [attr.colspan]=\"columnSpan\">\n                    <ng-container\n                      [ngTemplateOutlet]=\"rowDetail.tpl\"\n                      [ngTemplateOutletContext]=\"{ $implicit: row }\"\n                    />\n                  </td>\n                </tr>\n              }\n            }\n          }\n        </tbody>\n\n        <!-- A totals row belongs to the table, not below it: it has to keep the column\n             widths, or a sum stops sitting under the column it sums. -->\n        @if (hasFooter && !loading && rows.length > 0) {\n          <tfoot>\n            <tr>\n              @if (selectable) {\n                <td class=\"dt__selectCell dt__cell--stickyStart\"></td>\n              }\n              @for (col of columns; track col.key) {\n                <td\n                  [class.dt__cell--stickyEnd]=\"col.sticky === 'end'\"\n                  [style.text-align]=\"col.align ?? 'start'\"\n                  [attr.data-label]=\"col.label\"\n                  [attr.data-card]=\"col.card ?? null\"\n                >\n                  @if (footCellFor(col.key); as tpl) {\n                    <ng-container [ngTemplateOutlet]=\"tpl\" />\n                  }\n                </td>\n              }\n            </tr>\n          </tfoot>\n        }\n      </table>\n    } @else {\n      <div class=\"empty-state\">{{ emptyText }}</div>\n    }\n  </div>\n\n  <!-- The cuts: where the scrolling content passes beneath a pinned column. A rule with\n       a short shadow thrown away from the pin, stopping above the scrollbar. Only a\n       pinned column makes a cut \u2014 at the table's own outer edge the box border is\n       already the boundary, and a second rule there would be noise. -->\n  @if (hasSticky) {\n    <div class=\"dt__cutline\" aria-hidden=\"true\"></div>\n  }\n  @if (selectable) {\n    <div class=\"dt__cutline dt__cutline--start\" aria-hidden=\"true\"></div>\n  }\n\n  <!-- The tongues: the sideways scroll control for a reader with a plain mouse. Shift+\n       scroll is invisible knowledge and a wheel alone moves nothing sideways, so without\n       these the hidden columns cannot be reached at all.\n\n       Both stay in the DOM and are disabled while their edge hides nothing, so the\n       opacity can carry the change and neither takes a tab stop while invisible. -->\n  <button\n    type=\"button\"\n    class=\"dt__tongue dt__tongue--start\"\n    [class.dt__tongue--held]=\"held() === -1\"\n    [disabled]=\"!hiddenStart()\"\n    [attr.aria-hidden]=\"hiddenStart() ? null : 'true'\"\n    [attr.aria-label]=\"'table.scrollStart' | uiKitT\"\n    (pointerdown)=\"onTonguePress($event, -1)\"\n    (pointerup)=\"stopHold()\"\n    (mouseenter)=\"cutHotStart.set(true)\"\n    (mouseleave)=\"cutHotStart.set(false)\"\n    (pointerleave)=\"stopHold()\"\n    (pointercancel)=\"stopHold()\"\n    (focus)=\"cutHotStart.set(true)\"\n    (blur)=\"cutHotStart.set(false)\"\n    (keydown)=\"onTongueKey($event, -1)\"\n  >\n    <svg viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\n      <path\n        d=\"M10 3L5 8l5 5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n\n  <button\n    #endTongue\n    type=\"button\"\n    class=\"dt__tongue dt__tongue--end\"\n    [class.dt__tongue--held]=\"held() === 1\"\n    [disabled]=\"!hiddenEnd()\"\n    [attr.aria-hidden]=\"hiddenEnd() ? null : 'true'\"\n    [attr.aria-label]=\"'table.scrollEnd' | uiKitT\"\n    (pointerdown)=\"onTonguePress($event, 1)\"\n    (pointerup)=\"stopHold()\"\n    (pointercancel)=\"stopHold()\"\n    (mouseenter)=\"cutHot.set(true)\"\n    (mouseleave)=\"cutHot.set(false)\"\n    (pointerleave)=\"stopHold()\"\n    (focus)=\"cutHot.set(true)\"\n    (blur)=\"cutHot.set(false)\"\n    (keydown)=\"onTongueKey($event, 1)\"\n  >\n    <svg viewBox=\"0 0 16 16\" fill=\"none\" aria-hidden=\"true\">\n      <path\n        d=\"M6 3l5 5-5 5\"\n        stroke=\"currentColor\"\n        stroke-width=\"2\"\n        stroke-linecap=\"round\"\n        stroke-linejoin=\"round\"\n      />\n    </svg>\n  </button>\n</div>\n\n<!-- Announced separately, because the skeleton rows are aria-hidden: a screen reader\n     otherwise hears nothing at all while the table loads. -->\n@if (loading) {\n  <span class=\"dt__sr-only\" role=\"status\">{{ loadingText }}</span>\n}\n", styles: ["@charset \"UTF-8\";.dt{position:relative;--pin-overhang: 2px;--pin-line: var(--color-border)}.dt__scroll{overflow-x:auto;overflow-y:hidden;scrollbar-gutter:stable}.dt__cutline{position:absolute;top:0;bottom:var(--cut-bottom, 0px);right:var(--cue-right, 0px);width:1px;background:var(--color-border);box-shadow:var(--shadow-cut);opacity:0;pointer-events:none;z-index:3;transition:opacity var(--motion-base, .2s) var(--ease-standard, ease),background var(--motion-fast, .12s) var(--ease-standard, ease),box-shadow var(--motion-fast, .12s) var(--ease-standard, ease)}.dt__cutline--start{right:auto;left:var(--cue-left, 0px);background:transparent;box-shadow:var(--shadow-cut-start)}.dt--cut-end .dt__cutline:not(.dt__cutline--start),.dt--cut-start .dt__cutline--start{opacity:1}.dt--cut-hot .dt__cutline:not(.dt__cutline--start){background:var(--color-primary);box-shadow:var(--shadow-cut-strong)}.dt--cut-hot-start .dt__cutline--start{box-shadow:var(--shadow-cut-start-strong)}.dt--cut-hot-start{--pin-line: var(--color-primary)}.dt__tongue{position:absolute;top:var(--cue-top, 50%);transform:translateY(-50%);width:18px;height:54px;z-index:4;display:grid;place-items:center;padding:0;cursor:pointer;background:var(--color-surface-sunken);color:var(--color-text-muted);border:var(--border-width) solid var(--color-border);box-shadow:var(--shadow-sm);opacity:0;pointer-events:none;transition:opacity var(--motion-base, .2s) var(--ease-standard, ease),background var(--motion-fast, .12s) var(--ease-standard, ease),color var(--motion-fast, .12s) var(--ease-standard, ease),border-color var(--motion-fast, .12s) var(--ease-standard, ease)}.dt__tongue:hover,.dt__tongue--held{background:var(--color-primary);color:var(--color-on-primary);border-color:var(--color-primary)}.dt__tongue:focus-visible{outline:2px solid var(--color-focus-ring, var(--color-primary));outline-offset:2px}.dt__tongue svg{width:13px;height:13px;display:block}.dt__tongue--end{right:var(--cue-right, 0px);border-right:0;border-radius:var(--radius-md) 0 0 var(--radius-md)}.dt__tongue--start{left:var(--cue-left, 0px);border-left:0;border-radius:0 var(--radius-md) var(--radius-md) 0}.dt--cut-end .dt__tongue--end,.dt--cut-start .dt__tongue--start{opacity:1;pointer-events:auto}@media(max-width:768px){.dt__cutline,.dt__tongue{display:none}}@media(prefers-reduced-motion:reduce){.dt__cutline,.dt__tongue,.dt__table .dt__cell--stickyStart{transition:none}}.dt__sort{display:inline-flex;align-items:center;gap:var(--space-2);padding:0;border:0;background:none;font:inherit;color:inherit;text-transform:inherit;letter-spacing:inherit;cursor:pointer}.dt__sort:hover .dt__sort-icon,.dt__sort:focus-visible .dt__sort-icon{opacity:1}.dt__sort:focus-visible{outline:2px solid var(--color-focus-ring);outline-offset:2px}.dt__sort-icon{opacity:.35;transition:opacity var(--motion-fast, .12s) var(--ease-standard, ease)}.dt__sort-icon--on{opacity:1;color:var(--color-primary)}.dt__skeleton{display:block;height:.75rem;width:60%;border-radius:var(--radius-sm, 4px);background:var(--color-surface-sunken);animation:dt-pulse 1.4s var(--ease-standard, ease) infinite}.dt__skeleton-row td:first-child .dt__skeleton{width:80%}@keyframes dt-pulse{0%,to{opacity:.5}50%{opacity:1}}@media(prefers-reduced-motion:reduce){.dt__skeleton{animation:none}}.dt__sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0}.dt--boxed{background:var(--color-surface);border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);overflow:hidden}.dt__table{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}.dt__table th{text-align:start;padding:var(--space-3) var(--space-4);font-size:var(--fs-xs);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:.04em;color:var(--color-text-muted);background:var(--color-surface-sunken);border-bottom:var(--border-width) solid var(--color-border)}.dt__table tbody tr{height:3rem}.dt__table td{padding:0 var(--space-4);border-bottom:var(--border-width) solid var(--color-border);vertical-align:middle}.dt__cell--stickyEnd{position:sticky;right:0;border-inline-start:var(--border-width) solid var(--color-border)}.dt__cell--stickyStart{position:sticky;left:0;border-inline-end:var(--border-width) solid transparent}.dt__cell--stickyStart:after{content:\"\";position:absolute;top:calc(-1 * var(--border-width));bottom:calc(-1 * var(--border-width));right:calc(-1 * var(--border-width));width:var(--border-width);background:var(--pin-line);pointer-events:none;transition:background var(--motion-fast, .12s) var(--ease-standard, ease)}.dt__table td.dt__cell--stickyEnd,.dt__table td.dt__cell--stickyStart{--pin-bg: var(--color-surface);background:var(--pin-bg);z-index:1}.dt__table td.dt__cell--stickyEnd{box-shadow:calc(-1 * var(--pin-overhang)) 0 0 0 var(--pin-bg)}.dt__table th.dt__cell--stickyEnd,.dt__table th.dt__cell--stickyStart{--pin-bg: var(--color-surface-sunken);background:var(--pin-bg);z-index:2}.dt__table th.dt__cell--stickyEnd{box-shadow:calc(-1 * var(--pin-overhang)) 0 0 0 var(--pin-bg)}.dt__selectCell{width:3rem;text-align:center}.dt__check{cursor:pointer;accent-color:var(--color-primary)}.dt__table tbody tr.dt__row--selected td{background:var(--color-surface-sunken)}.dt__childRow>td{background:var(--color-surface-raised, var(--color-surface-sunken));font-size:var(--fs-xs)}.dt__childRow>td:first-child{padding-inline-start:var(--space-6)}.dt__table tfoot td{padding:var(--space-3) var(--space-4);border-top:2px solid var(--color-border-strong);font-weight:var(--fw-semibold);background:var(--color-surface)}.dt__table tfoot td.dt__cell--stickyEnd,.dt__table tfoot td.dt__cell--stickyStart{--pin-bg: var(--color-surface)}.dt__row--clickable{cursor:pointer}.dt__table tbody tr:hover td,.dt__row--clickable:focus-visible td,.dt__row--clickable:active td{background:var(--color-surface-sunken)}.dt__table tbody tr:hover td.dt__cell--stickyEnd,.dt__table tbody tr:hover td.dt__cell--stickyStart,.dt__row--clickable:focus-visible td.dt__cell--stickyEnd,.dt__row--clickable:focus-visible td.dt__cell--stickyStart,.dt__row--clickable:active td.dt__cell--stickyEnd,.dt__row--clickable:active td.dt__cell--stickyStart{--pin-bg: var(--color-surface-sunken)}.dt__detail-row>td{padding:0;background:var(--color-surface-raised, var(--color-surface-sunken))}.dt__empty{text-align:center;color:var(--color-text-muted);padding:var(--space-6)!important}@media(max-width:768px){.dt__table,.dt__table tbody{display:block;width:100%}.dt__table thead{display:none}.dt__table tbody tr{display:flex;flex-direction:column;height:auto;padding:var(--space-3) var(--space-4);border-bottom:var(--border-width) solid var(--color-border)}.dt__table tbody tr:last-child{border-bottom:0}.dt__table td{display:flex;align-items:baseline;justify-content:space-between;gap:var(--space-4);padding:var(--space-1) 0;border-bottom:0;text-align:end!important;min-width:0;overflow-wrap:anywhere}.dt__table td[data-label]:before{content:attr(data-label);flex:none;font-size:var(--fs-xs);font-weight:var(--fw-semibold);text-transform:uppercase;letter-spacing:.04em;color:var(--color-text-muted)}.dt__table td[data-label=\"\"]:before{content:none}.dt__table td[data-card=hidden]{display:none}.dt__table td[data-card=title],.dt__table tbody tr:not(:has(td[data-card=title])) td:first-child:not(.dt__selectCell),.dt__table tbody tr:not(:has(td[data-card=title])) .dt__selectCell+td{flex-direction:column;align-items:flex-start;gap:var(--space-1);text-align:start!important}.dt__table td[data-card=title]{order:-1;padding-block-end:var(--space-2);font-weight:var(--fw-semibold)}.dt__table td[data-card=title]:before{content:none}.dt__table tbody tr:has(.dt__selectCell){position:relative}.dt__table .dt__selectCell{position:absolute;inset-block-start:var(--space-3);inset-inline-end:var(--space-4);padding:0}.dt__table tbody tr:has(.dt__selectCell) td[data-card=title],.dt__table tbody tr:has(.dt__selectCell):not(:has(td[data-card=title])) .dt__selectCell+td{padding-inline-end:var(--space-6)}.dt__table td>*{min-width:0;max-width:100%}.dt__detail-row,.dt__detail-row>td,.dt__empty{display:block}.dt__detail-row,.dt__detail-row>td{text-align:start!important}.dt__empty{text-align:center!important}.dt__table tbody tr:hover,.dt__row--clickable:focus-visible,.dt__row--clickable:active{background:var(--color-surface-sunken)}.dt__table tbody tr:hover td,.dt__row--clickable:focus-visible td,.dt__row--clickable:active td{background:transparent}.dt__detail-row{padding:0}.dt__cell--stickyEnd{position:static}.dt__table td.dt__cell--stickyEnd,.dt__table td.dt__cell--stickyStart,.dt__cell--stickyEnd,.dt__cell--stickyStart{background:none;box-shadow:none;z-index:auto;border-inline-start:0;border-inline-end:0}.dt__selectCell{width:auto;flex-direction:row;justify-content:flex-start;padding-block-end:var(--space-2)}.dt__selectCell:before{content:none}.dt__selectCell:empty{display:none}.dt__childRow{margin-inline-start:var(--space-4)}.dt__childRow>td:first-child{padding-inline-start:0}}.dt__table tbody tr{-webkit-touch-callout:none}\n"] }]
        }], propDecorators: { columns: [{
                type: Input
            }], rows: [{
                type: Input
            }], emptyText: [{
                type: Input
            }], boxed: [{
                type: Input
            }], rowKey: [{
                type: Input
            }], clickable: [{
                type: Input
            }], rowClick: [{
                type: Output
            }], isExpanded: [{
                type: Input
            }], loading: [{
                type: Input
            }], skeletonRowCount: [{
                type: Input
            }], loadingText: [{
                type: Input
            }], selectable: [{
                type: Input
            }], selected: [{
                type: Input
            }], selectedChange: [{
                type: Output
            }], selectAllLabel: [{
                type: Input
            }], rowSelectLabel: [{
                type: Input
            }], childrenOf: [{
                type: Input
            }], rowClass: [{
                type: Input
            }], sort: [{
                type: Input
            }], sortChange: [{
                type: Output
            }], cellDirs: [{
                type: ContentChildren,
                args: [CellDirective]
            }], footDirs: [{
                type: ContentChildren,
                args: [FootCellDirective]
            }], rowDetail: [{
                type: ContentChild,
                args: [RowDetailDirective]
            }], scroller: [{
                type: ViewChild,
                args: ['scroller']
            }], box: [{
                type: ViewChild,
                args: ['box']
            }], endTongue: [{
                type: ViewChild,
                args: ['endTongue']
            }] } });

/**
 * Einheitliches Währungs-Eingabefeld. Überall gleiche Optik:
 * rechtsbündig, Tausender-Gruppierung + 2 Nachkommastellen, „€"-Suffix.
 *
 * `ControlValueAccessor` → per `[(ngModel)]` nutzbar. Das **Modell** ist stets ein
 * kanonischer Dezimal-String mit Punkt (`"1234.56"`, parsebar fürs Backend) bzw.
 * `''` für leer. Die **Anzeige** ist lokalisiert (de `1.234,56`, en `1,234.56`):
 * beim Fokus editierbar (ohne Gruppierung), beim Verlassen formatiert.
 */
class CurrencyInputComponent {
    constructor() {
        this.intl = inject(UI_KIT_INTL);
        this.placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
        this.ariaLabel = input('', ...(ngDevMode ? [{ debugName: "ariaLabel" }] : []));
        this.name = input('', ...(ngDevMode ? [{ debugName: "name" }] : []));
        /** Optionales Feld-Label; gesetzt → volle Feld-Optik (Label/Hint/Error),
         *  leer → blankes Control (für eigene Label-Wrapper, z. B. Filter/Dialoge). */
        this.label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
        this.hint = input('', ...(ngDevMode ? [{ debugName: "hint" }] : []));
        this.error = input('', ...(ngDevMode ? [{ debugName: "error" }] : []));
        this.required = input(false, ...(ngDevMode ? [{ debugName: "required" }] : []));
        /** Sichtbarer Text (formatiert oder beim Tippen roh). */
        this.text = signal('', ...(ngDevMode ? [{ debugName: "text" }] : []));
        this.disabled = signal(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        /** Kanonischer Wert (Punkt-Dezimal, ohne Gruppierung) — das Modell. */
        this.canonical = '';
        this.focused = false;
        this.onChange = () => { };
        this.onTouched = () => { };
    }
    // --- ControlValueAccessor ---------------------------------------------------
    writeValue(value) {
        this.canonical = this.toCanonical(value == null ? '' : String(value));
        this.text.set(this.focused ? this.toEditable(this.canonical) : this.format(this.canonical));
    }
    registerOnChange(fn) {
        this.onChange = fn;
    }
    registerOnTouched(fn) {
        this.onTouched = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled.set(isDisabled);
    }
    // --- Interaktion ------------------------------------------------------------
    onFocus() {
        this.focused = true;
        this.text.set(this.toEditable(this.canonical));
    }
    onInput(raw) {
        this.text.set(raw); // roh stehen lassen (kein Cursor-Springen)
        this.canonical = this.parse(raw);
        this.onChange(this.canonical);
    }
    onBlur() {
        this.focused = false;
        this.text.set(this.format(this.canonical));
        this.onTouched();
    }
    // --- Parsen / Formatieren ---------------------------------------------------
    get decimalSep() {
        return this.intl.lang() === 'en' ? '.' : ',';
    }
    /** Roh-Eingabe → kanonischer Punkt-Dezimal-String (oder ''). */
    parse(raw) {
        const trimmed = (raw ?? '').trim();
        if (!trimmed)
            return '';
        // Alles außer Ziffern und Separatoren entfernen; letzter Separator = Dezimaltrenner.
        let s = trimmed.replace(/[^\d.,-]/g, '');
        const neg = s.startsWith('-');
        s = s.replace(/-/g, '');
        const lastSep = Math.max(s.lastIndexOf(','), s.lastIndexOf('.'));
        let intPart;
        let fracPart;
        if (lastSep === -1) {
            intPart = s;
            fracPart = '';
        }
        else {
            intPart = s.slice(0, lastSep).replace(/[.,]/g, '');
            fracPart = s.slice(lastSep + 1).replace(/[.,]/g, '');
        }
        intPart = intPart.replace(/^0+(?=\d)/, '');
        if (!intPart && !fracPart)
            return '';
        const canonical = fracPart ? `${intPart || '0'}.${fracPart}` : intPart || '0';
        return neg ? `-${canonical}` : canonical;
    }
    /** Beliebigen Wert (Backend-Punkt oder lokal) → kanonisch. */
    toCanonical(value) {
        return this.parse(value);
    }
    /** Kanonisch → editierbarer Text (lokaler Dezimaltrenner, keine Gruppierung). */
    toEditable(canonical) {
        if (!canonical)
            return '';
        return this.decimalSep === ',' ? canonical.replace('.', ',') : canonical;
    }
    /** Kanonisch → lokalisiert formatiert (1.234,56) mit 2 Nachkommastellen. */
    format(canonical) {
        if (!canonical)
            return '';
        const n = Number(canonical);
        if (Number.isNaN(n))
            return '';
        const locale = this.intl.lang() === 'en' ? 'en-US' : 'de-DE';
        return new Intl.NumberFormat(locale, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        }).format(n);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CurrencyInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: CurrencyInputComponent, isStandalone: true, selector: "app-currency-input", inputs: { placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, ariaLabel: { classPropertyName: "ariaLabel", publicName: "ariaLabel", isSignal: true, isRequired: false, transformFunction: null }, name: { classPropertyName: "name", publicName: "name", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null }, error: { classPropertyName: "error", publicName: "error", isSignal: true, isRequired: false, transformFunction: null }, required: { classPropertyName: "required", publicName: "required", isSignal: true, isRequired: false, transformFunction: null } }, providers: [
            { provide: NG_VALUE_ACCESSOR, useExisting: CurrencyInputComponent, multi: true },
        ], ngImport: i0, template: "<div class=\"flex flex-col gap-1\">\n  @if (label()) {\n    <label class=\"text-sm font-medium text-muted\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"text-danger ms-[2px]\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <span class=\"cur\" [class.cur--disabled]=\"disabled()\">\n    <input\n      class=\"cur__input\"\n      type=\"text\"\n      inputmode=\"decimal\"\n      [value]=\"text()\"\n      [disabled]=\"disabled()\"\n      [attr.placeholder]=\"placeholder()\"\n      [attr.aria-label]=\"ariaLabel() || label() || null\"\n      [attr.aria-invalid]=\"error() ? 'true' : null\"\n      [attr.name]=\"name() || null\"\n      (focus)=\"onFocus()\"\n      (input)=\"onInput($any($event.target).value)\"\n      (blur)=\"onBlur()\"\n    />\n    <span class=\"cur__symbol\" aria-hidden=\"true\">\u20AC</span>\n  </span>\n  @if (hint() && !error()) {\n    <p class=\"text-xs text-muted m-0\">{{ hint() }}</p>\n  }\n  @if (error()) {\n    <p class=\"text-xs text-danger m-0\" role=\"alert\">{{ error() }}</p>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.cur{display:inline-flex;align-items:center;gap:var(--space-1);width:100%;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg, var(--color-surface));border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md)}.cur:focus-within{outline:2px solid var(--color-primary);outline-offset:1px}.cur--disabled{opacity:.6}.cur__input{flex:1 1 auto;min-width:0;height:100%;border:0;background:transparent;color:var(--color-text);font:inherit;font-variant-numeric:tabular-nums;text-align:end;padding:0}.cur__input:focus{outline:none}.cur__symbol{flex:0 0 auto;color:var(--color-text-muted)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: CurrencyInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-currency-input', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, providers: [
                        { provide: NG_VALUE_ACCESSOR, useExisting: CurrencyInputComponent, multi: true },
                    ], template: "<div class=\"flex flex-col gap-1\">\n  @if (label()) {\n    <label class=\"text-sm font-medium text-muted\">\n      {{ label() }}\n      @if (required()) {\n        <span class=\"text-danger ms-[2px]\" aria-hidden=\"true\">*</span>\n      }\n    </label>\n  }\n  <span class=\"cur\" [class.cur--disabled]=\"disabled()\">\n    <input\n      class=\"cur__input\"\n      type=\"text\"\n      inputmode=\"decimal\"\n      [value]=\"text()\"\n      [disabled]=\"disabled()\"\n      [attr.placeholder]=\"placeholder()\"\n      [attr.aria-label]=\"ariaLabel() || label() || null\"\n      [attr.aria-invalid]=\"error() ? 'true' : null\"\n      [attr.name]=\"name() || null\"\n      (focus)=\"onFocus()\"\n      (input)=\"onInput($any($event.target).value)\"\n      (blur)=\"onBlur()\"\n    />\n    <span class=\"cur__symbol\" aria-hidden=\"true\">\u20AC</span>\n  </span>\n  @if (hint() && !error()) {\n    <p class=\"text-xs text-muted m-0\">{{ hint() }}</p>\n  }\n  @if (error()) {\n    <p class=\"text-xs text-danger m-0\" role=\"alert\">{{ error() }}</p>\n  }\n</div>\n", styles: [":host{display:block;width:100%}.cur{display:inline-flex;align-items:center;gap:var(--space-1);width:100%;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg, var(--color-surface));border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md)}.cur:focus-within{outline:2px solid var(--color-primary);outline-offset:1px}.cur--disabled{opacity:.6}.cur__input{flex:1 1 auto;min-width:0;height:100%;border:0;background:transparent;color:var(--color-text);font:inherit;font-variant-numeric:tabular-nums;text-align:end;padding:0}.cur__input:focus{outline:none}.cur__symbol{flex:0 0 auto;color:var(--color-text-muted)}\n"] }]
        }], propDecorators: { placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], ariaLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "ariaLabel", required: false }] }], name: [{ type: i0.Input, args: [{ isSignal: true, alias: "name", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], error: [{ type: i0.Input, args: [{ isSignal: true, alias: "error", required: false }] }], required: [{ type: i0.Input, args: [{ isSignal: true, alias: "required", required: false }] }] } });

/**
 * Globaler Ladebildschirm: halbtransparenter Overlay über dem Inhaltsbereich
 * (unterhalb des Headers) mit zentriertem Spinner, gesteuert über den
 * {@link UI_KIT_LOADING}-Token (vom Host an seinen Lade-Service gebunden).
 * Header/Navigation bleiben bedienbar. Liegt unter Dialogen/Toasts (z-index),
 * damit diese darüber sichtbar bleiben.
 */
class LoadingOverlayComponent {
    constructor() {
        this.loading = inject(UI_KIT_LOADING);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: LoadingOverlayComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: LoadingOverlayComponent, isStandalone: true, selector: "app-loading-overlay", ngImport: i0, template: "@if (loading.visible()) {\n  <div class=\"lo\" role=\"status\" aria-live=\"polite\">\n    <div class=\"flex flex-col items-center gap-3 py-5 px-6 rounded-lg bg-surface border border-solid border-line shadow-lg\">\n      <span class=\"lo__spinner\" aria-hidden=\"true\"></span>\n      <span class=\"text-sm text-muted\">{{ 'loading' | uiKitT }}</span>\n    </div>\n  </div>\n}\n", styles: [".lo{position:fixed;top:var(--layout-header-height);inset-inline:0;bottom:0;z-index:1100;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--color-bg, #000) 55%,transparent);-webkit-backdrop-filter:blur(1px);backdrop-filter:blur(1px);animation:lo-fade .12s ease-out}.lo__spinner{width:2.25rem;height:2.25rem;border-radius:999px;border:3px solid var(--color-border-strong, currentColor);border-top-color:var(--color-primary);animation:lo-spin .7s linear infinite}@keyframes lo-spin{to{transform:rotate(360deg)}}@keyframes lo-fade{0%{opacity:0}}@media(prefers-reduced-motion:reduce){.lo{animation:none}.lo__spinner{animation-duration:1.5s}}\n"], dependencies: [{ kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: LoadingOverlayComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-loading-overlay', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe], template: "@if (loading.visible()) {\n  <div class=\"lo\" role=\"status\" aria-live=\"polite\">\n    <div class=\"flex flex-col items-center gap-3 py-5 px-6 rounded-lg bg-surface border border-solid border-line shadow-lg\">\n      <span class=\"lo__spinner\" aria-hidden=\"true\"></span>\n      <span class=\"text-sm text-muted\">{{ 'loading' | uiKitT }}</span>\n    </div>\n  </div>\n}\n", styles: [".lo{position:fixed;top:var(--layout-header-height);inset-inline:0;bottom:0;z-index:1100;display:flex;align-items:center;justify-content:center;background:color-mix(in srgb,var(--color-bg, #000) 55%,transparent);-webkit-backdrop-filter:blur(1px);backdrop-filter:blur(1px);animation:lo-fade .12s ease-out}.lo__spinner{width:2.25rem;height:2.25rem;border-radius:999px;border:3px solid var(--color-border-strong, currentColor);border-top-color:var(--color-primary);animation:lo-spin .7s linear infinite}@keyframes lo-spin{to{transform:rotate(360deg)}}@keyframes lo-fade{0%{opacity:0}}@media(prefers-reduced-motion:reduce){.lo{animation:none}.lo__spinner{animation-duration:1.5s}}\n"] }]
        }] });

/**
 * Einheitlicher Filter-Balken für Listen. Ein sekundärer Button
 * (Trichter-Icon + Label + Aktiv-Zähler) öffnet ein rechtsbündiges Popover; die
 * eigentlichen Filter-Felder werden projiziert (`<app-filter-field>` /
 * `<app-filter-range>`). Schließt bei Klick außerhalb und Escape.
 *
 * Zwei Modi:
 * - **Apply** (Default): Popover zeigt „Anwenden" + „Zurücksetzen"; der Konsument
 *   übernimmt die Werte erst bei `(apply)`.
 * - **Live** (`[live]="true"`): keine Anwenden-Taste — Felder wirken sofort (der
 *   Konsument bindet direkt). Nur „Zurücksetzen" erscheint bei aktiven Filtern.
 */
class FilterBarComponent {
    constructor() {
        this.host = inject((ElementRef));
        /** Anzahl aktiver Filter (Badge); 0 blendet den Zähler aus. */
        this.activeCount = input(0, ...(ngDevMode ? [{ debugName: "activeCount" }] : []));
        /** Button-Label; leer = i18n-Default „Filter". */
        this.label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
        /** Live-Modus: keine „Anwenden"-Taste (Felder wirken sofort). */
        this.live = input(false, ...(ngDevMode ? [{ debugName: "live" }] : []));
        this.applyLabel = input('', ...(ngDevMode ? [{ debugName: "applyLabel" }] : []));
        this.resetLabel = input('', ...(ngDevMode ? [{ debugName: "resetLabel" }] : []));
        /** „Anwenden" geklickt (Apply-Modus). Schließt das Popover. */
        this.apply = output();
        /** „Zurücksetzen" geklickt. */
        this.reset = output();
        /** Offen-Zustand geändert (z. B. zum Re-Fokus). */
        this.openChange = output();
        this.open = signal(false, ...(ngDevMode ? [{ debugName: "open" }] : []));
        /** True, wenn das Popover geöffnet ist (für Konsumenten via Template-Ref). */
        this.isOpen = computed(() => this.open(), ...(ngDevMode ? [{ debugName: "isOpen" }] : []));
    }
    toggle() {
        this.setOpen(!this.open());
    }
    close() {
        if (this.open())
            this.setOpen(false);
    }
    emitApply() {
        this.apply.emit();
        this.setOpen(false);
    }
    emitReset() {
        this.reset.emit();
    }
    setOpen(value) {
        this.open.set(value);
        this.openChange.emit(value);
    }
    onDocumentClick(event) {
        if (!this.open())
            return;
        if (!this.host.nativeElement.contains(event.target))
            this.setOpen(false);
    }
    onEscape() {
        this.close();
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterBarComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: FilterBarComponent, isStandalone: true, selector: "app-filter-bar", inputs: { activeCount: { classPropertyName: "activeCount", publicName: "activeCount", isSignal: true, isRequired: false, transformFunction: null }, label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, live: { classPropertyName: "live", publicName: "live", isSignal: true, isRequired: false, transformFunction: null }, applyLabel: { classPropertyName: "applyLabel", publicName: "applyLabel", isSignal: true, isRequired: false, transformFunction: null }, resetLabel: { classPropertyName: "resetLabel", publicName: "resetLabel", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { apply: "apply", reset: "reset", openChange: "openChange" }, host: { listeners: { "document:click": "onDocumentClick($event)", "document:keydown.escape": "onEscape()" } }, ngImport: i0, template: "<div class=\"relative\">\n  <app-button\n    variant=\"secondary\"\n    size=\"sm\"\n    [attr.aria-expanded]=\"open()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"inline-flex items-center gap-2\">\n      <app-icon name=\"filter\" [size]=\"16\" />\n      {{ label() || ('filter.button' | uiKitT) }}\n      @if (activeCount() > 0) {\n        <span class=\"filter__count\" aria-hidden=\"true\">{{ activeCount() }}</span>\n      }\n    </span>\n  </app-button>\n\n  @if (open()) {\n    <div class=\"filter__panel\" role=\"dialog\" [attr.aria-label]=\"label() || ('filter.button' | uiKitT)\">\n      <div class=\"flex flex-col gap-4\">\n        <ng-content />\n      </div>\n      <div class=\"filter__actions\">\n        @if (!live()) {\n          <app-button size=\"sm\" (click)=\"emitApply()\">\n            {{ applyLabel() || ('filter.apply' | uiKitT) }}\n          </app-button>\n        }\n        @if (live() ? activeCount() > 0 : true) {\n          <app-button variant=\"ghost\" size=\"sm\" (click)=\"emitReset()\">\n            {{ resetLabel() || ('filter.reset' | uiKitT) }}\n          </app-button>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";.filter__count{display:inline-flex;align-items:center;justify-content:center;min-width:1.25rem;height:1.25rem;padding:0 var(--space-1);margin-left:var(--space-1);border-radius:999px;background:var(--color-primary);color:var(--color-on-primary, #fff);font-size:var(--fs-xs);font-weight:var(--fw-bold)}.filter__panel{position:absolute;right:0;z-index:var(--z-dropdown, 50);margin-top:var(--space-2);width:min(22rem,90vw);max-height:80vh;overflow-y:auto;display:flex;flex-direction:column;gap:var(--space-4);padding:var(--space-4);background:var(--color-bg-elevated, var(--color-surface));border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg)}.filter__actions{display:flex;gap:var(--space-2)}@media(max-width:768px){.filter__panel{position:fixed;inset:auto 0 0;margin-top:0;width:auto;max-height:80dvh;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border-bottom:0;z-index:var(--z-dialog)}.filter__actions app-button{flex:1 1 auto;display:flex}}\n"], dependencies: [{ kind: "component", type: ButtonComponent, selector: "app-button", inputs: ["variant", "color", "size", "type", "disabled", "loading", "iconOnly", "block", "ariaLabel", "ariaPressed", "title"] }, { kind: "component", type: IconComponent, selector: "app-icon", inputs: ["name", "size"] }, { kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterBarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-filter-bar', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe, ButtonComponent, IconComponent], template: "<div class=\"relative\">\n  <app-button\n    variant=\"secondary\"\n    size=\"sm\"\n    [attr.aria-expanded]=\"open()\"\n    (click)=\"toggle()\"\n  >\n    <span class=\"inline-flex items-center gap-2\">\n      <app-icon name=\"filter\" [size]=\"16\" />\n      {{ label() || ('filter.button' | uiKitT) }}\n      @if (activeCount() > 0) {\n        <span class=\"filter__count\" aria-hidden=\"true\">{{ activeCount() }}</span>\n      }\n    </span>\n  </app-button>\n\n  @if (open()) {\n    <div class=\"filter__panel\" role=\"dialog\" [attr.aria-label]=\"label() || ('filter.button' | uiKitT)\">\n      <div class=\"flex flex-col gap-4\">\n        <ng-content />\n      </div>\n      <div class=\"filter__actions\">\n        @if (!live()) {\n          <app-button size=\"sm\" (click)=\"emitApply()\">\n            {{ applyLabel() || ('filter.apply' | uiKitT) }}\n          </app-button>\n        }\n        @if (live() ? activeCount() > 0 : true) {\n          <app-button variant=\"ghost\" size=\"sm\" (click)=\"emitReset()\">\n            {{ resetLabel() || ('filter.reset' | uiKitT) }}\n          </app-button>\n        }\n      </div>\n    </div>\n  }\n</div>\n", styles: ["@charset \"UTF-8\";.filter__count{display:inline-flex;align-items:center;justify-content:center;min-width:1.25rem;height:1.25rem;padding:0 var(--space-1);margin-left:var(--space-1);border-radius:999px;background:var(--color-primary);color:var(--color-on-primary, #fff);font-size:var(--fs-xs);font-weight:var(--fw-bold)}.filter__panel{position:absolute;right:0;z-index:var(--z-dropdown, 50);margin-top:var(--space-2);width:min(22rem,90vw);max-height:80vh;overflow-y:auto;display:flex;flex-direction:column;gap:var(--space-4);padding:var(--space-4);background:var(--color-bg-elevated, var(--color-surface));border:var(--border-width) solid var(--color-border);border-radius:var(--radius-lg);box-shadow:var(--shadow-lg)}.filter__actions{display:flex;gap:var(--space-2)}@media(max-width:768px){.filter__panel{position:fixed;inset:auto 0 0;margin-top:0;width:auto;max-height:80dvh;border-radius:var(--radius-lg) var(--radius-lg) 0 0;border-bottom:0;z-index:var(--z-dialog)}.filter__actions app-button{flex:1 1 auto;display:flex}}\n"] }]
        }], propDecorators: { activeCount: [{ type: i0.Input, args: [{ isSignal: true, alias: "activeCount", required: false }] }], label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], live: [{ type: i0.Input, args: [{ isSignal: true, alias: "live", required: false }] }], applyLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "applyLabel", required: false }] }], resetLabel: [{ type: i0.Input, args: [{ isSignal: true, alias: "resetLabel", required: false }] }], apply: [{ type: i0.Output, args: ["apply"] }], reset: [{ type: i0.Output, args: ["reset"] }], openChange: [{ type: i0.Output, args: ["openChange"] }], onDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }], onEscape: [{
                type: HostListener,
                args: ['document:keydown.escape']
            }] } });

/**
 * Ein Filter-Feld im {@link FilterBarComponent}-Popover: Label + projizierte
 * Steuerung (native input/select oder `<app-select>`). Einheitliche Optik für
 * alle Listen. Controls erben `.filter-field__control`-Styling über `::ng-deep`,
 * sodass Konsumenten nur ihr Control projizieren müssen.
 */
class FilterFieldComponent {
    constructor() {
        /** Sichtbares Label über dem Control. */
        this.label = input('', ...(ngDevMode ? [{ debugName: "label" }] : []));
        /**
         * Der Inhalt ist eine GRUPPE von Controls statt eines einzelnen.
         *
         * Ein `<label>` verbindet sich mit dem ersten Control darin. Bei einem Segment-Filter
         * heißt der erste Knopf dann wie das Feld statt wie er selbst — gemessen kam eine
         * Gruppe als "Archiv Nur archivierte Alle" heraus, der eigene Name des ersten Knopfs
         * fehlte. Mit `group` wird das Set über `role="group"` benannt.
         */
        this.group = input(false, ...(ngDevMode ? [{ debugName: "group" }] : []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterFieldComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: FilterFieldComponent, isStandalone: true, selector: "app-filter-field", inputs: { label: { classPropertyName: "label", publicName: "label", isSignal: true, isRequired: false, transformFunction: null }, group: { classPropertyName: "group", publicName: "group", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<ng-template #body>\n  <span class=\"text-sm font-medium text-muted\">{{ label() }}</span>\n  <ng-content />\n</ng-template>\n\n@if (group()) {\n  <!-- Eine Gruppe von Controls, nicht eines: ein <label> w\u00FCrde sich mit dem ERSTEN\n       davon verbinden, und dessen eigener Name ginge verloren. `role=\"group\"` benennt\n       das Set, ohne ein Mitglied zu verschlucken. -->\n  <div class=\"flex flex-col gap-1 min-w-0\" role=\"group\" [attr.aria-label]=\"label()\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </div>\n} @else {\n  <label class=\"flex flex-col gap-1 min-w-0\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </label>\n}\n", styles: ["@charset \"UTF-8\";:host ::ng-deep input:not([type=checkbox]):not([type=radio]):not(.cur__input),:host ::ng-deep select{width:100%;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg);color:var(--color-text);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);font:inherit;font-size:var(--fs-md)}:host ::ng-deep input[type=date]{min-width:0}\n"], dependencies: [{ kind: "directive", type: NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterFieldComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-filter-field', standalone: true, imports: [NgTemplateOutlet], changeDetection: ChangeDetectionStrategy.OnPush, template: "<ng-template #body>\n  <span class=\"text-sm font-medium text-muted\">{{ label() }}</span>\n  <ng-content />\n</ng-template>\n\n@if (group()) {\n  <!-- Eine Gruppe von Controls, nicht eines: ein <label> w\u00FCrde sich mit dem ERSTEN\n       davon verbinden, und dessen eigener Name ginge verloren. `role=\"group\"` benennt\n       das Set, ohne ein Mitglied zu verschlucken. -->\n  <div class=\"flex flex-col gap-1 min-w-0\" role=\"group\" [attr.aria-label]=\"label()\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </div>\n} @else {\n  <label class=\"flex flex-col gap-1 min-w-0\">\n    <ng-container [ngTemplateOutlet]=\"body\" />\n  </label>\n}\n", styles: ["@charset \"UTF-8\";:host ::ng-deep input:not([type=checkbox]):not([type=radio]):not(.cur__input),:host ::ng-deep select{width:100%;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg);color:var(--color-text);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);font:inherit;font-size:var(--fs-md)}:host ::ng-deep input[type=date]{min-width:0}\n"] }]
        }], propDecorators: { label: [{ type: i0.Input, args: [{ isSignal: true, alias: "label", required: false }] }], group: [{ type: i0.Input, args: [{ isSignal: true, alias: "group", required: false }] }] } });

/**
 * Min/Max- bzw. Von/Bis-Bereich im Filter-Popover: zwei projizierte Controls mit
 * einem Trenner dazwischen. Slots: `[start]` und `[end]`.
 *
 * ```html
 * <app-filter-range>
 *   <input start type="date" … />
 *   <input end type="date" … />
 * </app-filter-range>
 * ```
 */
class FilterRangeComponent {
    constructor() {
        /** Trennzeichen zwischen den beiden Controls. */
        this.separator = input('–', ...(ngDevMode ? [{ debugName: "separator" }] : []));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterRangeComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.1.0", version: "20.3.25", type: FilterRangeComponent, isStandalone: true, selector: "app-filter-range", inputs: { separator: { classPropertyName: "separator", publicName: "separator", isSignal: true, isRequired: false, transformFunction: null } }, ngImport: i0, template: "<div class=\"flex items-center gap-2 min-w-0\">\n  <ng-content select=\"[start]\" />\n  <span class=\"text-muted flex-none\" aria-hidden=\"true\">{{ separator() }}</span>\n  <ng-content select=\"[end]\" />\n</div>\n", styles: ["@charset \"UTF-8\";:host ::ng-deep app-currency-input{flex:1 1 0;min-width:0}:host ::ng-deep input:not(.cur__input),:host ::ng-deep select{width:100%;min-width:0;flex:1 1 0;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg);color:var(--color-text);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);font:inherit;font-size:var(--fs-md)}:host ::ng-deep input[type=number]{-moz-appearance:textfield;appearance:textfield}:host ::ng-deep input[type=number]::-webkit-outer-spin-button,:host ::ng-deep input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: FilterRangeComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-filter-range', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div class=\"flex items-center gap-2 min-w-0\">\n  <ng-content select=\"[start]\" />\n  <span class=\"text-muted flex-none\" aria-hidden=\"true\">{{ separator() }}</span>\n  <ng-content select=\"[end]\" />\n</div>\n", styles: ["@charset \"UTF-8\";:host ::ng-deep app-currency-input{flex:1 1 0;min-width:0}:host ::ng-deep input:not(.cur__input),:host ::ng-deep select{width:100%;min-width:0;flex:1 1 0;height:var(--control-height);padding:0 var(--space-3);background:var(--color-bg);color:var(--color-text);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);font:inherit;font-size:var(--fs-md)}:host ::ng-deep input[type=number]{-moz-appearance:textfield;appearance:textfield}:host ::ng-deep input[type=number]::-webkit-outer-spin-button,:host ::ng-deep input[type=number]::-webkit-inner-spin-button{-webkit-appearance:none;margin:0}\n"] }]
        }], propDecorators: { separator: [{ type: i0.Input, args: [{ isSignal: true, alias: "separator", required: false }] }] } });

let nextId = 0;
/** Globaler Toast-Hub. Komponenten rufen `show()`, der Container rendert. */
class ToastService {
    constructor() {
        this._toasts = signal([], ...(ngDevMode ? [{ debugName: "_toasts" }] : []));
        this.toasts = this._toasts.asReadonly();
    }
    /** Zeigt einen Toast; `timeout=0` deaktiviert das automatische Schließen. */
    show(message, variant = 'info', timeout = 4000) {
        const id = nextId++;
        this._toasts.update((list) => [...list, { id, message, variant }]);
        if (timeout > 0)
            setTimeout(() => this.dismiss(id), timeout);
        return id;
    }
    success(message) {
        return this.show(message, 'success');
    }
    error(message) {
        return this.show(message, 'danger');
    }
    dismiss(id) {
        this._toasts.update((list) => list.filter((t) => t.id !== id));
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastService, deps: [], target: i0.ɵɵFactoryTarget.Injectable }); }
    static { this.ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastService, providedIn: 'root' }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastService, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

/** Toast-Container — einmal im Shell-Layout platziert. ARIA-Live-Region. */
class ToastComponent {
    constructor() {
        this.toastService = inject(ToastService);
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "20.3.25", type: ToastComponent, isStandalone: true, selector: "app-toast", ngImport: i0, template: "<div class=\"toasts\" aria-live=\"polite\" aria-atomic=\"false\">\n  @for (toast of toastService.toasts(); track toast.id) {\n    <div class=\"toast\" [class]=\"'toast--' + toast.variant\" role=\"status\">\n      <span class=\"toast__msg\">{{ toast.message }}</span>\n      <button\n        type=\"button\"\n        class=\"toast__close\"\n        [attr.aria-label]=\"'dialog.close' | uiKitT\"\n        (click)=\"toastService.dismiss(toast.id)\"\n      >\n        \u2715\n      </button>\n    </div>\n  }\n</div>\n", styles: [".toasts{position:fixed;inset-block-end:var(--space-5);inset-inline-end:var(--space-5);z-index:var(--z-toast);display:flex;flex-direction:column;gap:var(--space-3);max-width:min(92vw,24rem)}.toast{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border-radius:var(--radius-md);box-shadow:var(--shadow-md);border-inline-start:3px solid currentColor;background:var(--color-bg-elevated);color:var(--color-text)}.toast--success{border-color:var(--color-success)}.toast--warning{border-color:var(--color-warning)}.toast--danger{border-color:var(--color-danger)}.toast--info{border-color:var(--color-info)}.toast__msg{flex:1;font-size:var(--fs-sm)}.toast__close{background:transparent;border:0;cursor:pointer;color:var(--color-text-muted)}\n"], dependencies: [{ kind: "pipe", type: UiKitTranslatePipe, name: "uiKitT" }], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: ToastComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-toast', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, imports: [UiKitTranslatePipe], template: "<div class=\"toasts\" aria-live=\"polite\" aria-atomic=\"false\">\n  @for (toast of toastService.toasts(); track toast.id) {\n    <div class=\"toast\" [class]=\"'toast--' + toast.variant\" role=\"status\">\n      <span class=\"toast__msg\">{{ toast.message }}</span>\n      <button\n        type=\"button\"\n        class=\"toast__close\"\n        [attr.aria-label]=\"'dialog.close' | uiKitT\"\n        (click)=\"toastService.dismiss(toast.id)\"\n      >\n        \u2715\n      </button>\n    </div>\n  }\n</div>\n", styles: [".toasts{position:fixed;inset-block-end:var(--space-5);inset-inline-end:var(--space-5);z-index:var(--z-toast);display:flex;flex-direction:column;gap:var(--space-3);max-width:min(92vw,24rem)}.toast{display:flex;align-items:center;gap:var(--space-3);padding:var(--space-3) var(--space-4);border-radius:var(--radius-md);box-shadow:var(--shadow-md);border-inline-start:3px solid currentColor;background:var(--color-bg-elevated);color:var(--color-text)}.toast--success{border-color:var(--color-success)}.toast--warning{border-color:var(--color-warning)}.toast--danger{border-color:var(--color-danger)}.toast--info{border-color:var(--color-info)}.toast__msg{flex:1;font-size:var(--fs-sm)}.toast__close{background:transparent;border:0;cursor:pointer;color:var(--color-text-muted)}\n"] }]
        }] });

/*
 * Public API of @stupa-makers/ui-kit.
 *
 * The MarkdownEditorComponent is deliberately NOT re-exported here — it pulls Tiptap
 * (hundreds of kB). Import it from the secondary entry point instead, so it stays in the
 * consumer's lazy chunk:  import { MarkdownEditorComponent } from '@stupa-makers/ui-kit/markdown-editor';
 */
// --- i18n decoupling (token + built-in DE/EN defaults + pipe) ---------------

/**
 * Generated bundle index. Do not edit.
 */

export { BadgeComponent, ButtonComponent, CardComponent, CellDirective, CheckboxComponent, ConfigDiffComponent, CurrencyInputComponent, DataTableComponent, DateRangeComponent, DatepickerComponent, DefaultUiKitIntl, DialogComponent, FilterBarComponent, FilterFieldComponent, FilterRangeComponent, FootCellDirective, IconComponent, InputComponent, LoadingOverlayComponent, RowDetailDirective, SelectComponent, StepperComponent, TableComponent, TimeInputComponent, ToastComponent, ToastService, UI_KIT_DEFAULT_MESSAGES, UI_KIT_INTL, UI_KIT_LOADING, UiKitTranslatePipe, provideUiKit, uiKitIntlFromLang };
//# sourceMappingURL=stupa-makers-ui-kit.mjs.map
