import * as i0 from '@angular/core';
import { input, output, viewChild, effect, ViewEncapsulation, ChangeDetectionStrategy, Component } from '@angular/core';
import { InputRule, Node, mergeAttributes, Editor } from '@tiptap/core';
import { Placeholder } from '@tiptap/extensions';
import StarterKit from '@tiptap/starter-kit';
import { Markdown } from 'tiptap-markdown';
import { InlineMath, BlockMath } from '@tiptap/extension-mathematics';

const DOLLAR = 0x24;
/**
 * `$…$` on one line. The opening `$` is not followed by white space, the closing
 * `$` is not preceded by white space and not followed by a digit, so that
 * "$5 und $6" stays a price and never a formula. A `\$` inside the formula is a
 * dollar sign and does not close it. The first other `$` must close the formula:
 * a lone dollar in a sentence stays text instead of swallowing the rest of it.
 */
function inlineMathRule(state, silent) {
    const src = state.src;
    const start = state.pos;
    if (src.charCodeAt(start) !== DOLLAR || src.charCodeAt(start + 1) === DOLLAR)
        return false;
    const first = src[start + 1];
    if (first === undefined || /\s/.test(first))
        return false;
    let end = start + 1;
    for (;;) {
        end = src.indexOf('$', end);
        if (end === -1 || end >= state.posMax)
            return false;
        const before = src[end - 1];
        if (before === '\\') {
            end++;
            continue;
        }
        if (before === undefined || /\s/.test(before))
            return false;
        break;
    }
    const latex = src.slice(start + 1, end);
    if (!latex.trim() || latex.includes('\n'))
        return false;
    const after = src[end + 1];
    if (after !== undefined && /\d/.test(after))
        return false;
    if (!silent) {
        const token = state.push('math_inline', 'span', 0);
        token.content = latex;
    }
    state.pos = end + 1;
    return true;
}
function lineOf$1(state, line) {
    return state.src.slice(state.bMarks[line] + state.tShift[line], state.eMarks[line]);
}
/** `$$ … $$` on one line, or `$$` opening a block that a line ending in `$$` closes. */
function blockMathRule(state, startLine, endLine, silent) {
    const first = lineOf$1(state, startLine).trim();
    if (!first.startsWith('$$'))
        return false;
    let latex;
    let next = startLine + 1;
    if (first.length > 4 && first.endsWith('$$')) {
        latex = first.slice(2, -2).trim();
    }
    else {
        const parts = [first.slice(2)];
        let closed = false;
        while (next < endLine) {
            const line = lineOf$1(state, next).trim();
            next++;
            if (line.endsWith('$$')) {
                parts.push(line.slice(0, -2));
                closed = true;
                break;
            }
            parts.push(line);
        }
        if (!closed)
            return false;
        latex = parts.join('\n').trim();
    }
    if (!latex)
        return false;
    if (silent)
        return true;
    const token = state.push('math_block', 'div', 0);
    token.content = latex;
    token.map = [startLine, next];
    state.line = next;
    return true;
}
function mathPlugin(md) {
    md.inline.ruler.after('escape', 'math_inline', inlineMathRule);
    md.block.ruler.before('fence', 'math_block', blockMathRule, {
        alt: ['paragraph', 'reference', 'blockquote', 'list'],
    });
    md.renderer.rules['math_inline'] = (tokens, idx) => `<span data-type="inline-math" data-latex="${md.utils.escapeHtml(tokens[idx].content)}"></span>`;
    md.renderer.rules['math_block'] = (tokens, idx) => `<div data-type="block-math" data-latex="${md.utils.escapeHtml(tokens[idx].content)}"></div>\n`;
}
/** Inline math with the Markdown dollar syntax. */
const InlineMathMarkdown = InlineMath.extend({
    addInputRules() {
        return [
            new InputRule({
                find: /(?<!\$)\$([^\s$](?:[^$\n]*[^\s$])?)\$$/,
                handler: ({ state, range, match }) => {
                    state.tr.replaceWith(range.from, range.to, this.type.create({ latex: match[1] }));
                },
            }),
        ];
    },
    addStorage() {
        return {
            markdown: {
                serialize(state, node) {
                    state.write(`$${node.attrs.latex}$`);
                },
                parse: {
                    setup(md) {
                        mathPlugin(md);
                    },
                },
            },
        };
    },
});
/** Block math with the Markdown double-dollar syntax. The inline node registers the rules. */
const BlockMathMarkdown = BlockMath.extend({
    addInputRules() {
        return [
            new InputRule({
                find: /^\$\$([^$\n]+)\$\$$/,
                handler: ({ state, range, match }) => {
                    const { tr } = state;
                    const from = state.doc.resolve(range.from);
                    const whole = from.depth > 0 &&
                        from.parent.isTextblock &&
                        range.from === from.start() &&
                        range.to === from.end() &&
                        from.node(-1).canReplaceWith(from.index(-1), from.indexAfter(-1), this.type);
                    const target = whole ? { from: from.before(), to: from.after() } : range;
                    tr.replaceWith(target.from, target.to, this.type.create({ latex: match[1].trim() }));
                },
            }),
        ];
    },
    addStorage() {
        return {
            markdown: {
                serialize(state, node) {
                    state.write(`$$\n${node.attrs.latex}\n$$`);
                    state.closeBlock(node);
                },
            },
        };
    },
});

/**
 * The pytex vote callout as one card.
 *
 * The protocol writes a vote as
 *
 *     > [!abstimmung] **Frage**
 *     > ja: 3, nein: 1, enthaltung: 0
 *
 * pytex reads the counts from the tally line and renders its tally box. The editor
 * shows the same block as a card and writes it back line for line, so the Markdown
 * that leaves the editor is the Markdown that came in. The card is one atom: it is
 * selected and deleted as a whole, its text is not edited in place.
 */
const MARKER = /^\[!(abstimmung|vote)\]\s*/i;
const TALLY = {
    yes: /(?:ja|yes)\s*[:=]?\s*(\d+)/i,
    no: /(?:nein|no)\s*[:=]?\s*(\d+)/i,
    abstain: /(?:enthaltung|enth\.?|abstain)\s*[:=]?\s*(\d+)/i,
};
const TALLY_LABEL = {
    yes: 'Ja',
    no: 'Nein',
    abstain: 'Enthaltung',
};
/** A line carries the counts when at least two of the three appear, as in pytex. */
function isTallyLine(line) {
    return Object.values(TALLY).filter((rx) => rx.test(line)).length >= 2;
}
function count(line, key) {
    const match = TALLY[key].exec(line);
    return match ? Number(match[1]) : 0;
}
/** Inline emphasis and code markers drop for the card text; the source keeps them. */
function plainText(markdown) {
    return markdown.replace(/\*\*|__|`/g, '').trim();
}
/** Read the card from the raw callout lines, the marker line first. */
function parseVoteCallout(raw) {
    const lines = raw.split('\n');
    const first = lines[0] ?? '';
    const marker = MARKER.exec(first);
    const kind = marker ? marker[1].toLowerCase() : 'abstimmung';
    const question = plainText(first.replace(MARKER, ''));
    const rest = lines.slice(1).map((l) => l.trim()).filter((l) => l.length > 0);
    const tallyLine = rest.find(isTallyLine);
    const tally = tallyLine
        ? { yes: count(tallyLine, 'yes'), no: count(tallyLine, 'no'), abstain: count(tallyLine, 'abstain') }
        : null;
    const body = rest.filter((l) => l !== tallyLine).map(plainText);
    const result = !tally
        ? 'none'
        : tally.yes > tally.no
            ? 'passed'
            : tally.yes < tally.no
                ? 'rejected'
                : 'tie';
    return { kind, question, tally, body, result };
}
function renderCard(raw) {
    const card = parseVoteCallout(raw);
    const root = document.createElement('div');
    root.className = 'mde__vote';
    root.dataset['result'] = card.result;
    const head = document.createElement('div');
    head.className = 'mde__voteHead';
    const kind = document.createElement('span');
    kind.className = 'mde__voteKind';
    kind.textContent = card.kind.charAt(0).toUpperCase() + card.kind.slice(1);
    head.appendChild(kind);
    if (card.tally) {
        const tally = document.createElement('span');
        tally.className = 'mde__voteTally';
        tally.textContent = Object.keys(TALLY)
            .map((key) => `${TALLY_LABEL[key]} ${card.tally[key]}`)
            .join(' · ');
        head.appendChild(tally);
    }
    root.appendChild(head);
    if (card.question) {
        const question = document.createElement('div');
        question.className = 'mde__voteQ';
        question.textContent = card.question;
        root.appendChild(question);
    }
    for (const line of card.body) {
        const p = document.createElement('div');
        p.className = 'mde__voteBody';
        p.textContent = line;
        root.appendChild(p);
    }
    return root;
}
function lineOf(state, line) {
    return state.src.slice(state.bMarks[line] + state.tShift[line], state.eMarks[line]);
}
/** `> [!abstimmung] …` and the quote lines that follow become one `vote_callout` token. */
function voteCalloutRule(state, startLine, endLine, silent) {
    const first = lineOf(state, startLine);
    if (!/^>\s?\[!(abstimmung|vote)\]/i.test(first))
        return false;
    if (silent)
        return true;
    let next = startLine;
    const lines = [];
    while (next < endLine) {
        const line = lineOf(state, next);
        if (!line.startsWith('>'))
            break;
        lines.push(line.replace(/^>\s?/, ''));
        next++;
    }
    const token = state.push('vote_callout', 'div', 0);
    token.content = lines.join('\n');
    token.map = [startLine, next];
    state.line = next;
    return true;
}
function voteCalloutPlugin(md) {
    md.block.ruler.before('blockquote', 'vote_callout', voteCalloutRule, {
        alt: ['paragraph', 'reference', 'blockquote', 'list'],
    });
    md.renderer.rules['vote_callout'] = (tokens, idx) => `<div data-vote-callout="" data-raw="${md.utils.escapeHtml(tokens[idx].content)}"></div>\n`;
}
const VoteCallout = Node.create({
    name: 'voteCallout',
    group: 'block',
    atom: true,
    selectable: true,
    draggable: false,
    addAttributes() {
        return { raw: { default: '' } };
    },
    parseHTML() {
        return [
            {
                tag: 'div[data-vote-callout]',
                getAttrs: (element) => ({ raw: element.getAttribute('data-raw') ?? '' }),
            },
        ];
    },
    renderHTML({ HTMLAttributes }) {
        return ['div', mergeAttributes({ 'data-vote-callout': '', 'data-raw': HTMLAttributes['raw'] })];
    },
    addNodeView() {
        return ({ node }) => ({
            dom: renderCard(node.attrs['raw']),
            update: () => false,
        });
    },
    addStorage() {
        return {
            markdown: {
                serialize(state, node) {
                    const lines = node.attrs.raw.split('\n');
                    state.write(lines.map((line) => (line ? `> ${line}` : '>')).join('\n'));
                    state.closeBlock(node);
                },
                parse: {
                    setup(md) {
                        voteCalloutPlugin(md);
                    },
                },
            },
        };
    },
});

// A formula with an error shows the source in red instead of failing the render.
const KATEX_OPTIONS = { throwOnError: false };
/**
 * WYSIWYG-Markdown-Editor (Tiptap) im Stil von Nextcloud Collectives: man tippt
 * Markdown-Kürzel (`# `, `- `, `**fett**`) und sieht **sofort** das gerenderte
 * Ergebnis — kein separater Vorschau-Bereich. Ein- und Ausgabe sind Markdown.
 *
 * Imperativ angebunden: Tiptap mountet in das Host-`div`. ``docKey`` identifiziert
 * das aktuell editierte Dokument (z. B. ein TOP); ändert es sich, wird der Inhalt
 * neu geladen, ohne die Eingabe während des Tippens zu überschreiben.
 */
class MarkdownEditorComponent {
    constructor() {
        /** Anfangs-/Soll-Markdown des aktuellen Dokuments. */
        this.value = input('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        /** Dokument-Schlüssel: ändert er sich, wird ``value`` neu in den Editor geladen. */
        this.docKey = input('', ...(ngDevMode ? [{ debugName: "docKey" }] : []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        /** Text of the empty document. */
        this.placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
        /**
         * Text of the empty last line of a document that has content. It shows where the
         * writing continues, the way Nextcloud Collectives does it. Empty means no hint.
         */
        this.hint = input('', ...(ngDevMode ? [{ debugName: "hint" }] : []));
        /** Emittiert das serialisierte Markdown bei jeder Änderung. */
        this.valueChange = output();
        this.host = viewChild.required('host');
        this.editor = null;
        this.loadedKey = null;
        this.emitting = false;
        // Editor lazy aufbauen, sobald das Host-Element existiert, und auf
        // docKey/disabled reagieren.
        effect(() => {
            const el = this.host().nativeElement;
            const key = this.docKey();
            const disabled = this.disabled();
            if (!this.editor) {
                this.editor = new Editor({
                    element: el,
                    extensions: [
                        StarterKit,
                        Markdown.configure({ html: false }),
                        // Every empty paragraph gets the text as `data-placeholder`. The styles
                        // show it on the first line of an empty document and on the last line
                        // of a document with content, and only while the editor is editable.
                        Placeholder.configure({
                            showOnlyCurrent: false,
                            placeholder: ({ editor }) => (editor.isEmpty ? this.placeholder() : this.hint()),
                        }),
                        VoteCallout,
                        InlineMathMarkdown.configure({ katexOptions: KATEX_OPTIONS }),
                        BlockMathMarkdown.configure({ katexOptions: KATEX_OPTIONS }),
                    ],
                    content: this.value(),
                    editable: !disabled,
                    onUpdate: ({ editor }) => {
                        if (this.emitting)
                            return;
                        this.valueChange.emit(this.toMarkdown(editor));
                    },
                });
                this.loadedKey = key;
                this.ensureTrailingLine();
                return;
            }
            this.editor.setEditable(!disabled);
            // Dokument gewechselt → Inhalt neu laden (ohne valueChange auszulösen).
            if (key !== this.loadedKey) {
                this.loadedKey = key;
                this.emitting = true;
                this.editor.commands.setContent(this.value());
                this.emitting = false;
                this.ensureTrailingLine();
            }
        });
    }
    /**
     * End the document with an empty paragraph. `TrailingNode` adds it on the first
     * edit only, so a freshly loaded document would show no line to continue on.
     */
    ensureTrailingLine() {
        const editor = this.editor;
        if (!editor)
            return;
        const last = editor.state.doc.lastChild;
        if (last?.type.name === 'paragraph' && last.content.size === 0)
            return;
        const paragraph = editor.schema.nodes['paragraph'].create();
        this.emitting = true;
        editor.view.dispatch(editor.state.tr.insert(editor.state.doc.content.size, paragraph));
        this.emitting = false;
    }
    ngOnDestroy() {
        this.editor?.destroy();
        this.editor = null;
    }
    /** Markdown aus dem Tiptap-Markdown-Storage holen (untypisiert in Tiptap). */
    toMarkdown(editor) {
        const storage = editor.storage;
        return storage['markdown']?.getMarkdown?.() ?? '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: MarkdownEditorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "20.3.25", type: MarkdownEditorComponent, isStandalone: true, selector: "app-markdown-editor", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, docKey: { classPropertyName: "docKey", publicName: "docKey", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, hint: { classPropertyName: "hint", publicName: "hint", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, viewQueries: [{ propertyName: "host", first: true, predicate: ["host"], descendants: true, isSignal: true }], ngImport: i0, template: "<div #host class=\"mde__host\" [class.mde__host--disabled]=\"disabled()\"></div>\n", styles: ["app-markdown-editor{display:block}.mde__host{min-height:16rem;padding:var(--space-3) var(--space-4);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);overflow-wrap:anywhere}.mde__host--disabled{opacity:.7}.mde__host :first-child{margin-top:0}.mde__host .ProseMirror{outline:none;min-height:14rem;line-height:1.55}.mde__host .ProseMirror h1{font-size:var(--fs-xl)}.mde__host .ProseMirror h2{font-size:var(--fs-lg)}.mde__host .ProseMirror h3{font-size:var(--fs-md);font-weight:var(--fw-semibold)}.mde__host .ProseMirror ul,.mde__host .ProseMirror ol{padding-left:var(--space-5);margin:var(--space-2) 0}.mde__host .ProseMirror blockquote{margin:var(--space-2) 0;padding-left:var(--space-3);border-left:3px solid var(--color-border-strong);color:var(--color-text-muted)}.mde__host .ProseMirror code{background:var(--color-bg);padding:0 var(--space-1);border-radius:var(--radius-sm);font-size:.9em}.mde__host .ProseMirror pre{background:var(--color-bg);padding:var(--space-3);border-radius:var(--radius-md);overflow-x:auto}.mde__host .ProseMirror hr{border:0;border-top:var(--border-width) solid var(--color-border);margin:var(--space-3) 0}.mde__host .ProseMirror p.is-editor-empty:first-child:before,.mde__host .ProseMirror p.is-empty:last-child:not(:first-child):before{content:attr(data-placeholder);color:var(--color-text-muted);float:left;height:0;pointer-events:none}.mde__host .ProseMirror p.is-empty:last-child:not(:first-child):before{font-style:italic}.mde__host .ProseMirror .tiptap-mathematics-render{cursor:pointer;border-radius:var(--radius-sm);padding:0 var(--space-1)}.mde__host .ProseMirror .tiptap-mathematics-render:hover,.mde__host .ProseMirror .ProseMirror-selectednode.tiptap-mathematics-render{background:var(--color-primary-subtle)}.mde__host .ProseMirror div.tiptap-mathematics-render{display:block;text-align:center;margin:var(--space-3) 0;padding:var(--space-2) 0}.mde__host .ProseMirror .mde__vote{margin:var(--space-3) 0;padding:var(--space-3) var(--space-4);border-left:3px solid var(--color-primary);border-radius:var(--radius-md);background:var(--color-surface-sunken);display:flex;flex-direction:column;gap:var(--space-2)}.mde__host .ProseMirror .ProseMirror-selectednode.mde__vote,.mde__host .ProseMirror .ProseMirror-selectednode>.mde__vote{outline:2px solid var(--color-primary);outline-offset:2px}.mde__host .ProseMirror .mde__vote[data-result=rejected]{border-left-color:var(--color-danger)}.mde__host .ProseMirror .mde__vote[data-result=tie],.mde__host .ProseMirror .mde__vote[data-result=none]{border-left-color:var(--color-border-strong)}.mde__host .ProseMirror .mde__voteHead{display:flex;align-items:center;gap:var(--space-3);flex-wrap:wrap}.mde__host .ProseMirror .mde__voteKind{font-size:var(--fs-xs);font-weight:var(--fw-bold);letter-spacing:.08em;text-transform:uppercase;color:var(--color-text-muted)}.mde__host .ProseMirror .mde__voteTally{margin-left:auto;font-size:var(--fs-sm);font-variant-numeric:tabular-nums;color:var(--color-primary);font-weight:var(--fw-semibold)}.mde__host .ProseMirror .mde__vote[data-result=rejected] .mde__voteTally{color:var(--color-danger)}.mde__host .ProseMirror .mde__vote[data-result=tie] .mde__voteTally{color:var(--color-text)}.mde__host .ProseMirror .mde__voteQ{font-weight:var(--fw-semibold)}.mde__host .ProseMirror .mde__voteBody{color:var(--color-text-muted);font-size:var(--fs-sm)}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: MarkdownEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-markdown-editor', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, encapsulation: ViewEncapsulation.None, template: "<div #host class=\"mde__host\" [class.mde__host--disabled]=\"disabled()\"></div>\n", styles: ["app-markdown-editor{display:block}.mde__host{min-height:16rem;padding:var(--space-3) var(--space-4);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);overflow-wrap:anywhere}.mde__host--disabled{opacity:.7}.mde__host :first-child{margin-top:0}.mde__host .ProseMirror{outline:none;min-height:14rem;line-height:1.55}.mde__host .ProseMirror h1{font-size:var(--fs-xl)}.mde__host .ProseMirror h2{font-size:var(--fs-lg)}.mde__host .ProseMirror h3{font-size:var(--fs-md);font-weight:var(--fw-semibold)}.mde__host .ProseMirror ul,.mde__host .ProseMirror ol{padding-left:var(--space-5);margin:var(--space-2) 0}.mde__host .ProseMirror blockquote{margin:var(--space-2) 0;padding-left:var(--space-3);border-left:3px solid var(--color-border-strong);color:var(--color-text-muted)}.mde__host .ProseMirror code{background:var(--color-bg);padding:0 var(--space-1);border-radius:var(--radius-sm);font-size:.9em}.mde__host .ProseMirror pre{background:var(--color-bg);padding:var(--space-3);border-radius:var(--radius-md);overflow-x:auto}.mde__host .ProseMirror hr{border:0;border-top:var(--border-width) solid var(--color-border);margin:var(--space-3) 0}.mde__host .ProseMirror p.is-editor-empty:first-child:before,.mde__host .ProseMirror p.is-empty:last-child:not(:first-child):before{content:attr(data-placeholder);color:var(--color-text-muted);float:left;height:0;pointer-events:none}.mde__host .ProseMirror p.is-empty:last-child:not(:first-child):before{font-style:italic}.mde__host .ProseMirror .tiptap-mathematics-render{cursor:pointer;border-radius:var(--radius-sm);padding:0 var(--space-1)}.mde__host .ProseMirror .tiptap-mathematics-render:hover,.mde__host .ProseMirror .ProseMirror-selectednode.tiptap-mathematics-render{background:var(--color-primary-subtle)}.mde__host .ProseMirror div.tiptap-mathematics-render{display:block;text-align:center;margin:var(--space-3) 0;padding:var(--space-2) 0}.mde__host .ProseMirror .mde__vote{margin:var(--space-3) 0;padding:var(--space-3) var(--space-4);border-left:3px solid var(--color-primary);border-radius:var(--radius-md);background:var(--color-surface-sunken);display:flex;flex-direction:column;gap:var(--space-2)}.mde__host .ProseMirror .ProseMirror-selectednode.mde__vote,.mde__host .ProseMirror .ProseMirror-selectednode>.mde__vote{outline:2px solid var(--color-primary);outline-offset:2px}.mde__host .ProseMirror .mde__vote[data-result=rejected]{border-left-color:var(--color-danger)}.mde__host .ProseMirror .mde__vote[data-result=tie],.mde__host .ProseMirror .mde__vote[data-result=none]{border-left-color:var(--color-border-strong)}.mde__host .ProseMirror .mde__voteHead{display:flex;align-items:center;gap:var(--space-3);flex-wrap:wrap}.mde__host .ProseMirror .mde__voteKind{font-size:var(--fs-xs);font-weight:var(--fw-bold);letter-spacing:.08em;text-transform:uppercase;color:var(--color-text-muted)}.mde__host .ProseMirror .mde__voteTally{margin-left:auto;font-size:var(--fs-sm);font-variant-numeric:tabular-nums;color:var(--color-primary);font-weight:var(--fw-semibold)}.mde__host .ProseMirror .mde__vote[data-result=rejected] .mde__voteTally{color:var(--color-danger)}.mde__host .ProseMirror .mde__vote[data-result=tie] .mde__voteTally{color:var(--color-text)}.mde__host .ProseMirror .mde__voteQ{font-weight:var(--fw-semibold)}.mde__host .ProseMirror .mde__voteBody{color:var(--color-text-muted);font-size:var(--fs-sm)}\n"] }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], docKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "docKey", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], hint: [{ type: i0.Input, args: [{ isSignal: true, alias: "hint", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], host: [{ type: i0.ViewChild, args: ['host', { isSignal: true }] }] } });

/*
 * Secondary entry point '@stupa-makers/ui-kit/markdown-editor'.
 * Isolated so the Tiptap dependency stays out of the primary entry's bundle and lands in
 * the consumer's lazy chunk only where the editor is actually used.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MarkdownEditorComponent };
//# sourceMappingURL=stupa-makers-ui-kit-markdown-editor.mjs.map
